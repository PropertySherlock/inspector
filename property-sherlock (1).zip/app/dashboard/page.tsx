import { MaintenanceScore } from "@/components/dashboard/maintenance-score"
import { HomeScanCTA } from "@/components/dashboard/home-scan-cta"
import { MaintenanceTasks } from "@/components/dashboard/maintenance-tasks"
import { Navigation } from "@/components/dashboard/navigation"
import { MaintenanceProvider } from "@/context/maintenance-context"

export default function DashboardPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <MaintenanceProvider>
        <MaintenanceScore />

        <main className="flex-1 py-5 container max-w-5xl mx-auto px-3">
          <HomeScanCTA />
          <MaintenanceTasks />
        </main>
      </MaintenanceProvider>

      <Navigation />
    </div>
  )
}

