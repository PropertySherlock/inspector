"use client"
import { Navigation } from "@/components/dashboard/navigation"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { PropertySelector } from "@/components/dashboard/property-selector"

const featuredOffers = [
  {
    id: "simplisafe",
    image: "/placeholder.svg?height=300&width=500",
    title: "SimpliSafe Home Security System",
    promotion: "Get 60% off + 10 health pts",
    description:
      "Save hundreds on an award winning home security system from SimpliSafe. No contracts, easy DIY installation, and 24/7 professional monitoring.",
  },
  {
    id: "nest",
    image: "/placeholder.svg?height=300&width=500",
    title: "Nest Learning Thermostat",
    promotion: "Save $50 + 15 health pts",
    description:
      "The Nest Learning Thermostat learns what temperature you like and builds a schedule around yours. Since 2011, it's saved billions of kWh of energy.",
  },
  {
    id: "ring",
    image: "/placeholder.svg?height=300&width=500",
    title: "Ring Video Doorbell Pro",
    promotion: "Get 30% off + 8 health pts",
    description:
      "Advanced security for your front door with 1080p HD video, two-way talk, and customizable motion detection zones.",
  },
  {
    id: "american-home-shield",
    image: "/placeholder.svg?height=300&width=500",
    title: "American Home Shield Warranty",
    promotion: "First month free + 20 health pts",
    description:
      "Protect your budget from unexpected repair or replacement costs when covered items break down due to normal wear and tear.",
  },
  {
    id: "flume",
    image: "/placeholder.svg?height=300&width=500",
    title: "Flume Smart Water Monitor",
    promotion: "Save $30 + 12 health pts",
    description:
      "Detect leaks in real-time, monitor water usage, and save money on your water bill with this easy-to-install smart water monitor.",
  },
  {
    id: "ecobee",
    image: "/placeholder.svg?height=300&width=500",
    title: "ecobee Smart Thermostat",
    promotion: "Get 25% off + 15 health pts",
    description:
      "Save up to 26% annually on heating and cooling costs with this ENERGY STAR certified smart thermostat with voice control.",
  },
  {
    id: "arlo",
    image: "/placeholder.svg?height=300&width=500",
    title: "Arlo Pro 4 Security Camera",
    promotion: "Save $80 + 10 health pts",
    description:
      "Wire-free 2K HDR security camera with color night vision, 160° viewing angle, and built-in spotlight for enhanced security.",
  },
  {
    id: "radon-test",
    image: "/placeholder.svg?height=300&width=500",
    title: "Airthings Radon Detector",
    promotion: "Get 20% off + 8 health pts",
    description:
      "Continuous radon monitoring with this battery-operated digital radon detector. Protect your family from this invisible threat.",
  },
  {
    id: "water-filter",
    image: "/placeholder.svg?height=300&width=500",
    title: "Whole House Water Filtration System",
    promotion: "Save $100 + 15 health pts",
    description:
      "Remove contaminants, sediment, and chlorine from your entire home's water supply with this comprehensive filtration system.",
  },
  {
    id: "smart-lock",
    image: "/placeholder.svg?height=300&width=500",
    title: "Yale Assure Smart Lock",
    promotion: "Get 15% off + 8 health pts",
    description:
      "Keyless entry smart lock with auto-lock feature, virtual keys for guests, and compatibility with major smart home platforms.",
  },
]

export default function OffersPage() {
  const router = useRouter()

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 container max-w-5xl mx-auto px-4 py-6 mb-20">
        <div className="mb-8">
          <PropertySelector />
        </div>

        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Recommended for your home</h1>
          <p className="text-gray-600 mb-6">
            We've curated these offers based on your home's profile and inspection results.
          </p>

          <div className="space-y-6">
            {featuredOffers.map((offer) => (
              <Card key={offer.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="sm:flex">
                  <div className="sm:w-1/3 relative">
                    <Image
                      src={offer.image || "/placeholder.svg"}
                      alt={offer.title}
                      width={500}
                      height={300}
                      className="w-full h-48 sm:h-full object-cover"
                    />
                  </div>
                  <div className="p-6 sm:w-2/3">
                    <h3 className="text-xl font-bold mb-2">{offer.title}</h3>
                    <p className="text-primary font-semibold mb-2">{offer.promotion}</p>
                    <p className="text-gray-600 mb-4">{offer.description}</p>
                    <Button
                      variant="outline"
                      className="text-primary border-primary hover:bg-primary/5 flex items-center"
                    >
                      View Deal
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <p className="text-xs text-gray-500 mt-6 text-center">
          * As an affiliate partner, we may earn a commission from qualifying purchases.
        </p>
      </main>

      <Navigation />
    </div>
  )
}

