import type { ReactNode } from "react"

export default function OffersLayout({ children }: { children: ReactNode }) {
  return children
}

