import { Navigation } from "@/components/dashboard/navigation"
import { Card } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function CategoryPage({ params }: { params: { category: string } }) {
  const categoryTitle = params.category
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 container max-w-5xl mx-auto px-4 py-6 mb-20">
        <div className="mb-6">
          <Link href="/offers" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Offers
          </Link>
        </div>

        <h1 className="text-2xl font-bold mb-6">{categoryTitle}</h1>

        <div className="grid gap-6">
          <Card className="p-6">
            <p className="text-gray-600">No offers available in this category yet.</p>
          </Card>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

