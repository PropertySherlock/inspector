"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, Star, CheckCircle, MapPin, Phone, Mail, Home } from "lucide-react"
import { Logo } from "@/components/logo"

export default function HomePage() {
  // Consistent orange color throughout
  const BRAND_ORANGE = "#E86C3A"

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#1C1C1C] min-h-[90vh] flex items-center">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1C1C1C] via-[#1C1C1C]/90 to-transparent z-0" />
        <div className="container max-w-7xl relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1 className="text-white text-5xl md:text-7xl font-bold leading-tight">
                LEVEL UP YOUR <span className="block text-[#E86C3A]">HOME PROTECTION</span>
              </h1>
              <p className="text-gray-300 text-xl">
                Join 50,000+ homeowners who trust Property Sherlock to proactively maintain & protect their home.
              </p>
              <div className="space-y-6">
                <Link
                  href="/onboarding/name"
                  className="inline-block px-8 py-4 text-xl font-medium bg-[#E86C3A] hover:bg-[#D55B29] text-white transition-colors duration-200"
                >
                  Get Started Free
                </Link>
                <div className="flex items-center gap-2">
                  <div className="flex text-[#E86C3A]">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <span className="text-gray-400">4.8 stars on Google Reviews</span>
                </div>
              </div>
            </div>
            <div className="relative h-[600px] w-full">
              <Image
                src="/placeholder.svg?height=1200&width=800"
                alt="Property Sherlock Mobile App"
                fill
                className="object-contain"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Make Home Maintenance <span className="text-[#E86C3A]">Simple</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              We've got the tools and experts to help you understand your home's condition and prevent costly repairs.
            </p>
            <Button
              className="w-full md:w-auto px-8 py-3 text-lg font-medium bg-[#E86C3A] hover:bg-[#D55B29] text-white rounded-md shadow-md"
              asChild
            >
              <Link href="/onboarding/name">Get Started</Link>
            </Button>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="relative h-[400px] w-full">
                <Image
                  src="/placeholder.svg?height=800&width=800"
                  alt="Home inspection process"
                  fill
                  className="object-cover rounded-lg shadow-lg"
                />
              </div>
            </div>
            <div className="space-y-6">
              <h3 className="text-2xl font-bold">Track and Improve Your Home's Condition</h3>
              <p className="text-gray-600">
                Our comprehensive inspection process helps you understand your home's current state and what needs
                attention. Get detailed reports with:
              </p>
              <ul className="space-y-4">
                {[
                  "Professional assessment of all major systems",
                  "High-resolution photos and documentation",
                  "Prioritized maintenance recommendations",
                  "Cost estimates for repairs and upgrades",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-[#E86C3A]" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button
                className="w-full md:w-auto px-8 py-3 text-lg font-medium bg-[#E86C3A] hover:bg-[#D55B29] text-white rounded-md shadow-md"
                asChild
              >
                <Link href="/onboarding/name">Schedule an Inspection</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Services</h2>
            <p className="text-xl text-gray-600">Comprehensive solutions for your home maintenance needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Home Inspections",
                description: "Thorough assessment of your property's condition with detailed reports.",
                icon: <Home className="h-8 w-8 text-[#E86C3A]" />,
              },
              {
                title: "Maintenance Plans",
                description: "Customized schedules to keep your home in perfect condition year-round.",
                icon: <CheckCircle className="h-8 w-8 text-[#E86C3A]" />,
              },
              {
                title: "Protection Services",
                description: "Proactive monitoring to prevent costly repairs and maintain home value.",
                icon: <Shield className="h-8 w-8 text-[#E86C3A]" />,
              },
            ].map((service, i) => (
              <Card key={i} className="bg-white shadow-md hover:shadow-lg transition-shadow border-0">
                <CardContent className="p-8">
                  <div className="mb-4">{service.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <Button
                    className="w-full px-6 py-3 bg-[#E86C3A] hover:bg-[#D55B29] text-white rounded-md shadow-md"
                    asChild
                  >
                    <Link href="/onboarding/name">Get Started</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">What Our Customers Say</h2>
            <p className="text-xl text-gray-600 mb-8">
              Join thousands of satisfied homeowners who trust Property Sherlock
            </p>
            <Button
              className="w-full md:w-auto px-8 py-3 text-lg font-medium bg-[#E86C3A] hover:bg-[#D55B29] text-white rounded-md shadow-md"
              asChild
            >
              <Link href="/onboarding/name">Join Our Customers</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Johnson",
                location: "San Francisco, CA",
                quote:
                  "Property Sherlock saved us thousands in potential repairs. The inspector found issues we would have never noticed until it was too late.",
                rating: 5,
              },
              {
                name: "Michael Rodriguez",
                location: "Austin, TX",
                quote:
                  "The maintenance dashboard is a game-changer. I now know exactly what needs to be done and when to keep my home in top condition.",
                rating: 5,
              },
              {
                name: "Jennifer Chen",
                location: "Seattle, WA",
                quote:
                  "The inspector was thorough, professional, and took the time to explain everything. The report was detailed and easy to understand.",
                rating: 5,
              },
            ].map((review, i) => (
              <Card key={i} className="bg-white shadow-md hover:shadow-lg transition-shadow border-0">
                <CardContent className="p-8">
                  <div className="flex text-[#E86C3A] mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <blockquote className="mb-6">
                    <p className="text-gray-700 italic">"{review.quote}"</p>
                  </blockquote>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                    <div>
                      <p className="font-semibold">{review.name}</p>
                      <p className="text-sm text-gray-500">{review.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="container max-w-7xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: "50,000+", label: "Happy Customers" },
              { number: "98%", label: "Satisfaction Rate" },
              { number: "24/7", label: "Customer Support" },
              { number: "$2,500", label: "Avg. Savings" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-[#E86C3A]">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl">
          <div className="bg-[#E86C3A] rounded-lg shadow-xl p-8 md:p-12">
            <div className="text-center text-white max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to protect your home?</h2>
              <p className="text-xl mb-8">
                Get started with a comprehensive home inspection and personalized maintenance plan.
              </p>
              <Button
                className="w-full md:w-auto px-8 py-3 text-lg font-medium bg-white text-[#E86C3A] hover:bg-gray-100 rounded-md shadow-md"
                asChild
              >
                <Link href="/onboarding/name">Get Started Today</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1C1C1C] text-white py-12">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Link href="/" className="flex items-center gap-2">
                  <Logo className="h-8 w-8 text-[#E86C3A]" />
                  <span className="text-xl font-bold text-white">Property Sherlock</span>
                </Link>
              </div>
              <p className="text-gray-400">
                Your home's personal detective, helping you maintain and protect your investment.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-3">
                {["Home Inspections", "Maintenance Plans", "Repair Recommendations", "HomeScan Technology"].map(
                  (item, i) => (
                    <li key={i}>
                      <Link href="#" className="text-gray-400 hover:text-[#E86C3A] transition-colors">
                        {item}
                      </Link>
                    </li>
                  ),
                )}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-3">
                {["About Us", "Our Team", "Careers", "Contact Us"].map((item, i) => (
                  <li key={i}>
                    <Link href="#" className="text-gray-400 hover:text-[#E86C3A] transition-colors">
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#E86C3A] flex-shrink-0 mt-1" />
                  <span className="text-gray-400">1234 Inspection Ave, Suite 500, San Francisco, CA 94107</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[#E86C3A]" />
                  <span className="text-gray-400">(555) 123-4567</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#E86C3A]" />
                  <Link
                    href="mailto:info@propertysherlock.com"
                    className="text-gray-400 hover:text-[#E86C3A] transition-colors"
                  >
                    info@propertysherlock.com
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-10 pt-8">
            <p className="text-gray-400 text-center">
              &copy; {new Date().getFullYear()} Property Sherlock. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

