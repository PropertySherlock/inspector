"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowLeft, ArrowRight } from "lucide-react"
import { SectionCard } from "@/components/homescan/section-card"
import { QuestionGroup } from "@/components/homescan/question-group"
import { ConditionSelector } from "@/components/homescan/condition-selector"
import { PhotoUploader } from "@/components/homescan/photo-uploader"
import type { ConditionRating } from "@/types/homescan"

export default function InteriorPage() {
  const router = useRouter()
  const [livingRoomCondition, setLivingRoomCondition] = useState<ConditionRating>("good")
  const [kitchenCondition, setKitchenCondition] = useState<ConditionRating>("good")
  const [floorType, setFloorType] = useState("")
  const [interiorNotes, setInteriorNotes] = useState("")

  return (
    <div>
      <SectionCard title="Living Areas">
        <QuestionGroup title="What is the overall condition of your living room?">
          <ConditionSelector value={livingRoomCondition} onChange={setLivingRoomCondition} />
        </QuestionGroup>

        <QuestionGroup title="What type of flooring do you have?">
          <Input
            placeholder="e.g., hardwood, carpet, tile, laminate"
            value={floorType}
            onChange={(e) => setFloorType(e.target.value)}
          />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your living areas">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <SectionCard title="Kitchen">
        <QuestionGroup title="What is the overall condition of your kitchen?">
          <ConditionSelector value={kitchenCondition} onChange={setKitchenCondition} />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your kitchen">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <SectionCard title="Additional Information">
        <QuestionGroup title="Additional notes about your interior">
          <Textarea
            placeholder="Enter any additional information about your home's interior..."
            value={interiorNotes}
            onChange={(e) => setInteriorNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </QuestionGroup>
      </SectionCard>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={() => router.push("/homescan/exterior")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back: Exterior
        </Button>
        <Button onClick={() => router.push("/homescan/systems")}>
          Next: Systems
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

