"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Check } from "lucide-react"
import { SectionCard } from "@/components/homescan/section-card"
import { QuestionGroup } from "@/components/homescan/question-group"
import { ConditionSelector } from "@/components/homescan/condition-selector"
import { PhotoUploader } from "@/components/homescan/photo-uploader"
import type { ConditionRating } from "@/types/homescan"

export default function SystemsPage() {
  const router = useRouter()
  const [hvacCondition, setHvacCondition] = useState<ConditionRating>("good")
  const [hvacType, setHvacType] = useState("")
  const [hvacAge, setHvacAge] = useState("")
  const [hasPlumbingLeaks, setHasPlumbingLeaks] = useState<boolean | null>(null)
  const [waterHeaterAge, setWaterHeaterAge] = useState("")
  const [systemsNotes, setSystemsNotes] = useState("")

  const handleComplete = () => {
    // In a real app, you would save the data here
    router.push("/dashboard")
  }

  return (
    <div>
      <SectionCard title="HVAC System">
        <QuestionGroup title="What type of HVAC system do you have?">
          <Input
            placeholder="e.g., central air, heat pump, furnace"
            value={hvacType}
            onChange={(e) => setHvacType(e.target.value)}
          />
        </QuestionGroup>

        <QuestionGroup title="How old is your HVAC system?">
          <Input placeholder="e.g., 5 years" value={hvacAge} onChange={(e) => setHvacAge(e.target.value)} />
        </QuestionGroup>

        <QuestionGroup title="What is the overall condition of your HVAC system?">
          <ConditionSelector value={hvacCondition} onChange={setHvacCondition} />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your HVAC system">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <SectionCard title="Plumbing System">
        <QuestionGroup title="Have you noticed any leaks in your plumbing?">
          <div className="flex gap-4">
            <label className="flex items-center">
              <input
                type="radio"
                name="plumbing-leaks"
                checked={hasPlumbingLeaks === true}
                onChange={() => setHasPlumbingLeaks(true)}
                className="mr-2"
              />
              Yes
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="plumbing-leaks"
                checked={hasPlumbingLeaks === false}
                onChange={() => setHasPlumbingLeaks(false)}
                className="mr-2"
              />
              No
            </label>
          </div>
        </QuestionGroup>

        <QuestionGroup title="How old is your water heater?">
          <Input
            placeholder="e.g., 3 years"
            value={waterHeaterAge}
            onChange={(e) => setWaterHeaterAge(e.target.value)}
          />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your plumbing system or water heater">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <SectionCard title="Additional Information">
        <QuestionGroup title="Additional notes about your home systems">
          <Textarea
            placeholder="Enter any additional information about your home systems..."
            value={systemsNotes}
            onChange={(e) => setSystemsNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </QuestionGroup>
      </SectionCard>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={() => router.push("/homescan/interior")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back: Interior
        </Button>
        <Button onClick={handleComplete}>
          <Check className="mr-2 h-4 w-4" />
          Complete HomeScan
        </Button>
      </div>
    </div>
  )
}

