"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { getHomeScanData, saveHomeScanProgress } from "@/lib/api"
import type { HomeScanData } from "@/types/homescan"
import Link from "next/link"
import { HireInspectorCTA } from "@/components/homescan/hire-inspector-cta"
import { toast } from "@/components/ui/use-toast"

export default function HomeScanLayout({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<HomeScanData | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [completing, setCompleting] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    async function fetchData() {
      try {
        const homeScanData = await getHomeScanData()
        setData(homeScanData)
      } catch (error) {
        console.error("Failed to fetch HomeScan data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleSaveProgress = async () => {
    if (!data) return

    setSaving(true)
    try {
      // Get the current section ID from the pathname
      const currentSection = pathname.split("/").pop() || ""

      // Save progress for the current section
      await saveHomeScanProgress({
        sectionId: currentSection,
        action: "save",
        // In a real app, you would collect and send the form data here
        formData: {},
      })

      // Show success message
      toast({
        title: "Progress saved",
        description: "Your HomeScan progress has been saved successfully.",
      })

      // Refresh the data to get updated progress
      const updatedData = await getHomeScanData()
      setData(updatedData)
    } catch (error) {
      console.error("Failed to save progress:", error)
      toast({
        title: "Error saving progress",
        description: "There was a problem saving your progress. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleCompleteHomeScan = async () => {
    if (!data) return

    setCompleting(true)
    try {
      // Save progress with completion flag
      await saveHomeScanProgress({
        action: "complete",
        // In a real app, you would collect and send all form data here
        formData: {},
      })

      // Show success message
      toast({
        title: "HomeScan completed",
        description: "Your HomeScan has been completed successfully.",
      })

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      console.error("Failed to complete HomeScan:", error)
      toast({
        title: "Error completing HomeScan",
        description: "There was a problem completing your HomeScan. Please try again.",
        variant: "destructive",
      })
    } finally {
      setCompleting(false)
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (!data) {
    return <div className="min-h-screen flex items-center justify-center">Failed to load HomeScan data</div>
  }

  const currentSection = pathname.split("/").pop() || ""
  const currentIndex = data.sections.findIndex((section) => section.id === currentSection)
  const nextSection = currentIndex < data.sections.length - 1 ? data.sections[currentIndex + 1] : null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Progress Bar */}
      <div className="sticky top-16 z-10 bg-white border-b">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <div className="text-gray-600 mr-2">Progress: {data.progress}%</div>
              <div className="w-32 h-2 bg-gray-200 rounded-full">
                <div className="h-2 bg-primary rounded-full" style={{ width: `${data.progress}%` }}></div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleSaveProgress} disabled={saving}>
                {saving ? "Saving..." : "Save Progress"}
              </Button>
              <Button onClick={handleCompleteHomeScan} disabled={completing}>
                {completing ? "Completing..." : "Complete HomeScan"}
              </Button>
            </div>
          </div>
        </div>

        {/* Section Navigation */}
        <div className="border-t">
          <div className="container max-w-5xl mx-auto px-4">
            <div className="flex">
              {data.sections.map((section) => (
                <Link
                  key={section.id}
                  href={`/homescan/${section.id}`}
                  className={`px-6 py-4 text-center flex-1 transition-colors ${
                    currentSection === section.id
                      ? "bg-primary/10 text-primary border-b-2 border-primary"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {section.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {children}

      {/* Hire Inspector CTA */}
      <HireInspectorCTA />
    </div>
  )
}

