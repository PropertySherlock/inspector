import { redirect } from "next/navigation"

export default function HomeScanPage() {
  redirect("/homescan/exterior")
}

