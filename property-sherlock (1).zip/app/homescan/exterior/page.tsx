"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowRight } from "lucide-react"
import { SectionCard } from "@/components/homescan/section-card"
import { QuestionGroup } from "@/components/homescan/question-group"
import { ConditionSelector } from "@/components/homescan/condition-selector"
import { PhotoUploader } from "@/components/homescan/photo-uploader"
import type { ConditionRating } from "@/types/homescan"

export default function ExteriorPage() {
  const router = useRouter()
  const [roofCondition, setRoofCondition] = useState<ConditionRating>("good")
  const [roofNotes, setRoofNotes] = useState("")
  const [wallMaterial, setWallMaterial] = useState("")
  const [wallNotes, setWallNotes] = useState("")
  const [hasLeaks, setHasLeaks] = useState<boolean | null>(null)

  return (
    <div>
      <SectionCard title="Roof Condition">
        <QuestionGroup title="What is the overall condition of your roof?">
          <ConditionSelector value={roofCondition} onChange={setRoofCondition} />
        </QuestionGroup>

        <QuestionGroup title="Have you noticed any leaks or water damage?">
          <div className="flex gap-4">
            <label className="flex items-center">
              <input
                type="radio"
                name="roof-leaks"
                checked={hasLeaks === true}
                onChange={() => setHasLeaks(true)}
                className="mr-2"
              />
              Yes
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="roof-leaks"
                checked={hasLeaks === false}
                onChange={() => setHasLeaks(false)}
                className="mr-2"
              />
              No
            </label>
          </div>
        </QuestionGroup>

        <QuestionGroup title="Additional notes about your roof">
          <Textarea
            placeholder="Enter any additional information about your roof..."
            value={roofNotes}
            onChange={(e) => setRoofNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your roof">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <SectionCard title="Siding & Exterior Walls">
        <QuestionGroup title="What material is your siding made of?">
          <Input
            placeholder="e.g., vinyl, wood, brick, stucco"
            value={wallMaterial}
            onChange={(e) => setWallMaterial(e.target.value)}
          />
        </QuestionGroup>

        <QuestionGroup title="Additional notes about your exterior walls">
          <Textarea
            placeholder="Enter any additional information about your exterior walls..."
            value={wallNotes}
            onChange={(e) => setWallNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </QuestionGroup>

        <QuestionGroup title="Upload photos of your exterior walls">
          <PhotoUploader />
        </QuestionGroup>
      </SectionCard>

      <div className="flex justify-end mt-8">
        <Button onClick={() => router.push("/homescan/interior")}>
          Next: Interior
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

