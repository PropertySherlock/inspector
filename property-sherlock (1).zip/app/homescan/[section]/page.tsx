"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Camera } from "lucide-react"
import { ConditionSelector } from "@/components/home-scan/condition-selector"
import { getHomeScanData, saveHomeScanProgress } from "@/lib/api"
import { toast } from "@/components/ui/use-toast"
import type { HomeScanSection } from "@/types/homescan"

export default function HomeScanSection({ params }: { params: { section: string } }) {
  const [sectionData, setSectionData] = useState<HomeScanSection | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [photos, setPhotos] = useState<Record<string, File[]>>({})
  const router = useRouter()

  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getHomeScanData()
        const section = data.sections.find((s) => s.id === params.section)
        if (section) {
          setSectionData(section)

          // Initialize form data
          const initialData: Record<string, any> = {}
          section.questions.forEach((q) => {
            initialData[q.id] = q.type === "photo" ? [] : ""
          })
          setFormData(initialData)
        } else {
          router.push("/homescan/exterior")
        }
      } catch (error) {
        console.error("Failed to fetch section data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [params.section, router])

  const handleInputChange = (questionId: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [questionId]: value,
    }))
  }

  const handlePhotoUpload = (questionId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newPhotos = Array.from(e.target.files)
      setPhotos((prev) => ({
        ...prev,
        [questionId]: [...(prev[questionId] || []), ...newPhotos],
      }))
    }
  }

  const handleSubmit = async () => {
    if (!sectionData) return

    setSubmitting(true)
    try {
      // Save section data
      await saveHomeScanProgress({
        sectionId: params.section,
        formData,
        photos,
      })

      // Find next section
      const data = await getHomeScanData()
      const currentIndex = data.sections.findIndex((s) => s.id === params.section)
      const nextSection = currentIndex < data.sections.length - 1 ? data.sections[currentIndex + 1] : null

      // Show success message
      toast({
        title: "Section completed",
        description: "Your progress has been saved.",
      })

      if (nextSection) {
        router.push(`/homescan/${nextSection.id}`)
      } else {
        // If this was the last section, show completion message
        toast({
          title: "All sections completed",
          description: "You can now complete your HomeScan.",
        })
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Failed to save progress:", error)
      toast({
        title: "Error saving progress",
        description: "There was a problem saving your progress. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return <div className="container max-w-5xl mx-auto px-4 py-8">Loading...</div>
  }

  if (!sectionData) {
    return <div className="container max-w-5xl mx-auto px-4 py-8">Section not found</div>
  }

  return (
    <main className="container max-w-5xl mx-auto px-4 py-8">
      <div className="space-y-12">
        {sectionData.questions.map((question) => (
          <section key={question.id} className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">{question.question}</h3>
              {question.description && <p className="text-gray-600">{question.description}</p>}
            </div>

            {question.type === "condition" && (
              <ConditionSelector
                options={question.options || []}
                value={formData[question.id]}
                onChange={(value) => handleInputChange(question.id, value)}
              />
            )}

            {question.type === "text" && (
              <Input
                type="text"
                placeholder={question.description}
                className="max-w-md"
                value={formData[question.id]}
                onChange={(e) => handleInputChange(question.id, e.target.value)}
              />
            )}

            {question.type === "textarea" && (
              <Textarea
                placeholder={`Enter any additional information...`}
                className="min-h-[150px]"
                value={formData[question.id]}
                onChange={(e) => handleInputChange(question.id, e.target.value)}
              />
            )}

            {question.type === "photo" && (
              <div className="border-2 border-dashed border-gray-200 rounded-lg p-8">
                <div className="flex flex-col items-center text-center">
                  <Camera className="h-8 w-8 text-gray-400 mb-2" />
                  <h4 className="font-semibold mb-1">Upload photos</h4>
                  <p className="text-sm text-gray-500 mb-4">Drag and drop or click to browse</p>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) => handlePhotoUpload(question.id, e)}
                    className="hidden"
                    id={`photo-upload-${question.id}`}
                  />
                  <label
                    htmlFor={`photo-upload-${question.id}`}
                    className="bg-white border border-gray-300 hover:border-gray-400 text-gray-700 px-4 py-2 rounded-md cursor-pointer transition-colors"
                  >
                    Choose Files
                  </label>
                </div>
                {photos[question.id]?.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {photos[question.id].map((photo, index) => (
                      <div key={index} className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={URL.createObjectURL(photo) || "/placeholder.svg"}
                          alt={`Uploaded photo ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </section>
        ))}

        {/* Navigation Buttons */}
        <div className="flex justify-end">
          <Button className="flex items-center gap-2" onClick={handleSubmit} disabled={submitting}>
            {submitting ? (
              "Saving..."
            ) : (
              <>
                <NextSectionButton sectionId={params.section} />
                <span className="text-lg">→</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </main>
  )
}

const NextSectionButton = ({ sectionId }: { sectionId: string }) => {
  const [nextSectionName, setNextSectionName] = useState<string | null>(null)

  useEffect(() => {
    const fetchNextSectionName = async () => {
      const data = await getHomeScanData()
      const currentIndex = data.sections.findIndex((s) => s.id === sectionId)
      const nextSection = currentIndex < data.sections.length - 1 ? data.sections[currentIndex + 1] : null

      setNextSectionName(nextSection?.name || null)
    }

    fetchNextSectionName()
  }, [sectionId])

  if (nextSectionName) {
    return `Next: ${nextSectionName}`
  } else {
    return "Complete HomeScan"
  }
}

