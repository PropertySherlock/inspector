"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { UpgradeForm } from "@/components/home-profile/upgrade-form"
import { getSectionById } from "@/lib/home-profile-data"

export default function AddUpgradePage() {
  const params = useParams()
  const router = useRouter()
  const [section, setSection] = useState<any>(null)

  useEffect(() => {
    const sectionId = params.sectionId as string
    const sectionData = getSectionById(sectionId)

    if (sectionData) {
      setSection(sectionData)
    } else {
      router.push("/home-profile")
    }
  }, [params.sectionId, router])

  if (!section) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return <UpgradeForm section={section} />
}

