"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"

export default function EditBasicInformationPage() {
  const router = useRouter()
  const [installationYear, setInstallationYear] = useState("")
  const [condition, setCondition] = useState("")
  const [lastMaintenance, setLastMaintenance] = useState("")

  const handleSave = () => {
    // Save logic would go here
    router.back()
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Basic Information</h1>
        </div>
      </div>

      <main className="flex-1 p-4 max-w-3xl mx-auto">
        <div className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="installation-year" className="text-sm font-medium">
              Installation year (if applicable)
            </label>
            <Input
              id="installation-year"
              placeholder="Enter year"
              value={installationYear}
              onChange={(e) => setInstallationYear(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="condition" className="text-sm font-medium">
              Condition
            </label>
            <Select value={condition} onValueChange={setCondition}>
              <SelectTrigger>
                <SelectValue placeholder="Select condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="last-maintenance" className="text-sm font-medium">
              Last maintenance (if applicable)
            </label>
            <Input
              id="last-maintenance"
              placeholder="Month and year"
              value={lastMaintenance}
              onChange={(e) => setLastMaintenance(e.target.value)}
            />
          </div>

          <Button className="w-full bg-primary hover:bg-primary-dark text-white" onClick={handleSave}>
            Save Changes
          </Button>

          <Button variant="outline" className="w-full" onClick={() => router.back()}>
            Cancel
          </Button>
        </div>
      </main>
    </div>
  )
}

