"use client"

import { useState } from "react"
import { ArrowLeft, Pencil, Plus, ChevronRight, Camera, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function BasicInformationPage() {
  const router = useRouter()
  const [basicInfo, setBasicInfo] = useState<any>(null)
  const [upgrades, setUpgrades] = useState<any[]>([])

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Detailed Information</h1>
        </div>
      </div>

      <main className="flex-1 p-0">
        <div className="flex flex-col items-center py-8 bg-white border-b">
          <div className="text-primary mb-2">
            <Home className="h-8 w-8" />
          </div>
          <h2 className="text-2xl font-bold">Basic Information</h2>
        </div>

        <div className="p-4 max-w-3xl mx-auto">
          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold">Basic Information</h3>
              <button
                onClick={() => router.push("/home-profile/basic/edit")}
                className="text-gray-500 hover:text-gray-700"
              >
                <Pencil className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4">
              {basicInfo ? (
                <div>{/* Display basic info here */}</div>
              ) : (
                <p className="text-gray-500">Click the edit button to add basic information</p>
              )}
            </div>
          </div>

          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold">Upgrades</h3>
              <button className="text-gray-500 hover:text-gray-700">
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4">
              {upgrades.length > 0 ? (
                <div>{/* Display upgrades here */}</div>
              ) : (
                <p className="text-gray-500">Document any upgrades you've made to your basic information</p>
              )}

              <Button variant="outline" className="w-full mt-4 flex items-center justify-center" onClick={() => {}}>
                <Plus className="h-4 w-4 mr-2" />
                Add Upgrade
              </Button>
            </div>
          </div>

          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold">Detailed Information</h3>
              <button
                onClick={() => router.push("/home-profile/basic/details")}
                className="text-gray-500 hover:text-gray-700"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4">
              <p className="text-gray-500 mb-4">Add notes and photos to document your basic information</p>

              <Button
                variant="outline"
                className="w-full flex items-center justify-center"
                onClick={() => router.push("/home-profile/basic/details")}
              >
                <Camera className="h-4 w-4 mr-2" />
                Add Photos
              </Button>
            </div>
          </div>

          <Button className="w-full bg-primary hover:bg-primary-dark text-white">Save Changes</Button>
        </div>
      </main>
    </div>
  )
}

