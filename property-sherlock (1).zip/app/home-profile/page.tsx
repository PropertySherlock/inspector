"use client"

import { ArrowLeft, ChevronRight, Check } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"

export default function HomeProfilePage() {
  const router = useRouter()
  const { sections, sectionData, getSectionPhotos } = useHomeProfile()

  // Calculate completion status for each section
  const getSectionCompletion = (sectionId: string) => {
    const data = sectionData[sectionId] || {}
    const photos = getSectionPhotos(sectionId)

    // If there's any data or photos, consider it started
    const hasStarted = Object.keys(data).length > 0 || photos.length > 0

    // If there's substantial data (more than 2 fields filled), consider it completed
    const isCompleted = Object.keys(data).length >= 2

    return { hasStarted, isCompleted }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">39600 Fremont Blvd, Fremont, California</h1>
        </div>
      </div>

      <main className="flex-1 p-4">
        <h2 className="text-2xl font-bold mb-4">Home Profile</h2>

        <div className="mb-20">
          {sections.map((section, index) => {
            const Icon = section.icon
            const { hasStarted, isCompleted } = getSectionCompletion(section.id)

            return (
              <Link href={`/home-profile/${section.id}`} key={section.id}>
                <div
                  className={`flex items-center p-4 bg-white ${index !== 0 ? "border-t" : "rounded-t-lg"} ${index === sections.length - 1 ? "rounded-b-lg" : ""}`}
                >
                  <div className="w-6 h-6 mr-4 flex-shrink-0 text-primary">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-medium">{section.title}</h3>
                    {hasStarted && <p className="text-xs text-gray-500">{isCompleted ? "Completed" : "In progress"}</p>}
                  </div>
                  {isCompleted ? (
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                      <Check className="w-4 h-4" />
                    </div>
                  ) : (
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  )}
                </div>
              </Link>
            )
          })}
        </div>
      </main>
    </div>
  )
}

