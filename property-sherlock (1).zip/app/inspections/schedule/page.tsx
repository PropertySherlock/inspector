"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Navigation } from "@/components/dashboard/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check, Calendar, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { PropertySelector } from "@/components/dashboard/property-selector"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"

export default function ScheduleInspectionPage() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [notes, setNotes] = useState("")
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  // Check if this is a follow-up inspection
  const isFollowUp = searchParams?.get("followUp") === "true"
  const inspectionId = searchParams?.get("inspectionId")

  // Set a default note for follow-up inspections
  useEffect(() => {
    if (isFollowUp && inspectionId) {
      setNotes(
        `Follow-up inspection for inspection #${inspectionId}. Please focus on the issues identified in the previous report.`,
      )
    }
  }, [isFollowUp, inspectionId])

  // Generate available dates (next 14 days)
  const availableDates = Array.from({ length: 14 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() + i + 1) // Start from tomorrow
    return date
  })

  // Generate available time slots
  const availableTimes = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    if (!date || !time) {
      setError("Please select a date and time for your inspection")
      setIsSubmitting(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      // In a real app, you would save this to state management or API
      console.log("Scheduling inspection:", {
        date,
        time,
        notes,
        isFollowUp,
        inspectionId: isFollowUp ? inspectionId : null,
      })

      setIsSubmitting(false)
      setIsSuccess(true)

      // Redirect after showing success message
      setTimeout(() => {
        router.push("/inspections")
      }, 2000)
    }, 1000)
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="container mx-auto px-4 pt-4">
          <div className="mb-4">
            <Link href="/inspections" className="text-gray-600 flex items-center">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Inspections
            </Link>
          </div>

          <div className="mb-8">
            <PropertySelector />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>{isFollowUp ? "Schedule a Follow-up Inspection" : "Schedule an Inspection"}</CardTitle>
              <CardDescription>
                {isFollowUp
                  ? "Select a date and time for your follow-up professional home inspection"
                  : "Select a date and time for your professional home inspection"}
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-[#E86C3A]" />
                    Select a Date
                  </label>

                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                    {availableDates.map((availableDate, index) => {
                      const dateString = availableDate.toISOString().split("T")[0]
                      const isSelected = date === dateString
                      const dayName = availableDate.toLocaleDateString("en-US", { weekday: "short" })
                      const dayNumber = availableDate.getDate()

                      return (
                        <button
                          key={index}
                          type="button"
                          className={`p-3 rounded-md border text-center transition-colors ${
                            isSelected
                              ? "bg-[#E86C3A] text-white border-[#E86C3A]"
                              : "bg-white hover:border-[#E86C3A] hover:text-[#E86C3A]"
                          }`}
                          onClick={() => {
                            setDate(dateString)
                            setError("")
                          }}
                        >
                          <div className="text-xs font-medium">{dayName}</div>
                          <div className={`text-lg ${isSelected ? "font-bold" : "font-medium"}`}>{dayNumber}</div>
                        </button>
                      )
                    })}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-[#E86C3A]" />
                    Select a Time
                  </label>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {availableTimes.map((availableTime, index) => {
                      const isSelected = time === availableTime

                      return (
                        <button
                          key={index}
                          type="button"
                          className={`p-3 rounded-md border text-center transition-colors ${
                            isSelected
                              ? "bg-[#E86C3A] text-white border-[#E86C3A]"
                              : "bg-white hover:border-[#E86C3A] hover:text-[#E86C3A]"
                          }`}
                          onClick={() => {
                            setTime(availableTime)
                            setError("")
                          }}
                        >
                          {availableTime}
                        </button>
                      )
                    })}
                  </div>
                </div>

                {date && time && (
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <h3 className="font-medium mb-1">Your selected appointment:</h3>
                    <p className="text-gray-700">
                      {formatDate(date)} at {time}
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <label htmlFor="notes" className="text-sm font-medium">
                    Additional Notes {isFollowUp ? "" : "(Optional)"}
                  </label>
                  <textarea
                    id="notes"
                    className="w-full min-h-[100px] p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#E86C3A] focus:border-transparent"
                    placeholder="Any specific areas of concern or access instructions..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>

                {error && <div className="bg-red-50 border border-red-200 text-red-600 p-3 rounded-md">{error}</div>}
              </CardContent>
              <CardFooter className="pt-4">
                <Button
                  type="submit"
                  className="w-full bg-[#E86C3A] hover:bg-[#D55B29] text-white h-11 px-6 text-base font-medium transition-colors"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Scheduling..." : isFollowUp ? "Schedule Follow-up" : "Schedule Inspection"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>

      <Navigation />

      {/* Success Modal */}
      {isSuccess && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
                <Check className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Inspection Scheduled!</h3>
              <p className="text-gray-600 mb-4">
                Your {isFollowUp ? "follow-up " : ""}inspection has been scheduled successfully. You'll receive a
                confirmation email shortly.
              </p>
              <Button
                className="bg-[#E86C3A] hover:bg-[#D55B29] text-white"
                onClick={() => router.push("/inspections")}
              >
                Return to Inspections
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

