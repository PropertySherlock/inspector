import { Navigation } from "@/components/dashboard/navigation"

export default function ScheduleInspectionLoading() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="container mx-auto px-4 pt-4">
          <div className="h-6 w-32 bg-gray-200 rounded animate-pulse mb-8"></div>

          <div className="h-10 w-full max-w-md bg-gray-200 rounded animate-pulse mb-8"></div>

          <div className="bg-white border rounded-lg p-6 animate-pulse">
            <div className="h-8 w-64 bg-gray-200 rounded mb-4"></div>
            <div className="h-4 w-full max-w-md bg-gray-200 rounded mb-8"></div>

            <div className="space-y-6">
              <div>
                <div className="h-5 w-32 bg-gray-200 rounded mb-3"></div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                  {[...Array(7)].map((_, index) => (
                    <div key={index} className="h-16 bg-gray-200 rounded"></div>
                  ))}
                </div>
              </div>

              <div>
                <div className="h-5 w-32 bg-gray-200 rounded mb-3"></div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[...Array(4)].map((_, index) => (
                    <div key={index} className="h-12 bg-gray-200 rounded"></div>
                  ))}
                </div>
              </div>

              <div className="h-24 w-full bg-gray-200 rounded"></div>

              <div className="h-10 w-full bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

