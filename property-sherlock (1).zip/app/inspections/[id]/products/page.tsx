"use client"

import { Navigation } from "@/components/dashboard/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function RecommendedProductsPage({ params }: { params: { id: string } }) {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="bg-white border-b">
          <div className="container max-w-5xl mx-auto px-4 py-6">
            <h1 className="text-2xl font-bold">8100 Sky Mountain Ln</h1>
            <p className="text-gray-600">Mountain View, California</p>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                <span className="text-green-600 font-medium">Completed</span>
              </div>
              <p className="text-sm text-gray-600">Inspection completed on March 5, 2025</p>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-2">
          <Link href="/inspections" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Inspections
          </Link>
        </div>

        <div className="container mx-auto px-4 py-4">
          {/* Header section */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Inspection Report</h2>
          </div>

          {/* Tab Navigation */}
          <div className="flex border rounded-lg overflow-hidden mb-6">
            <Link
              href={`/inspections/${params.id}`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-gray-50 text-gray-600 hover:bg-gray-100"
            >
              Findings
            </Link>
            <Link
              href={`/inspections/${params.id}/maintenance`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-gray-50 text-gray-600 hover:bg-gray-100"
            >
              Maintenance Plan
            </Link>
            <Link
              href={`/inspections/${params.id}/products`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-white border-b-2 border-[#E86C3A] font-medium text-gray-900"
            >
              Recommended Products
            </Link>
          </div>

          {/* Products Tab Content */}
          <div>
            <p className="text-gray-700 mb-6">
              Based on your inspection results, we recommend these products to improve your home.
            </p>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Product 1 */}
              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="relative">
                  <div className="aspect-square bg-gray-100 flex items-center justify-center">
                    <img
                      src="/placeholder.svg?height=200&width=200"
                      alt="SimpliSafe Home Security System"
                      className="max-h-full"
                    />
                  </div>
                  <div className="absolute top-2 right-2 bg-[#E86C3A] text-white text-xs px-2 py-1 rounded">
                    Recommended
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-1">SimpliSafe Home Security System</h3>
                  <p className="text-[#E86C3A] font-bold mb-2">$279.99</p>
                  <p className="text-sm text-gray-600 mb-4">
                    Complete wireless home security system with professional monitoring. Easy to install and no
                    long-term contracts.
                  </p>
                  <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
                    <span className="mr-1">View Deal</span>
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Product 2 */}
              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="aspect-square bg-gray-100 flex items-center justify-center">
                  <img src="/placeholder.svg?height=200&width=200" alt="Ring Video Doorbell" className="max-h-full" />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-1">Ring Video Doorbell</h3>
                  <p className="text-[#E86C3A] font-bold mb-2">$99.99</p>
                  <p className="text-sm text-gray-600 mb-4">
                    HD video doorbell with motion detection and two-way talk. See, hear, and speak to visitors from your
                    phone.
                  </p>
                  <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
                    <span className="mr-1">View Deal</span>
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Product 3 */}
              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="aspect-square bg-gray-100 flex items-center justify-center">
                  <img
                    src="/placeholder.svg?height=200&width=200"
                    alt="Yale Assure Smart Lock"
                    className="max-h-full"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-1">Yale Assure Smart Lock</h3>
                  <p className="text-[#E86C3A] font-bold mb-2">$249.99</p>
                  <p className="text-sm text-gray-600 mb-4">
                    Keyless entry smart lock that works with your smartphone. Auto-lock feature and virtual keys for
                    guests.
                  </p>
                  <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
                    <span className="mr-1">View Deal</span>
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <p className="text-xs text-gray-500 mt-6">
              * As an affiliate partner, we may earn a commission from qualifying purchases.
            </p>
          </div>
        </div>
      </main>
      <Navigation />
    </div>
  )
}

