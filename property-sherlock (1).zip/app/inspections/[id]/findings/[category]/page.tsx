"use client"

import { useState, useEffect } from "react"
import { Navigation } from "@/components/dashboard/navigation"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function CategoryFindingsPage({ params }: { params: { id: string; category: string } }) {
  const router = useRouter()
  const [activeCategory, setActiveCategory] = useState(params.category)

  // Update active category when the route params change
  useEffect(() => {
    setActiveCategory(params.category)
  }, [params.category])

  // Format the category name for display
  const formatCategoryName = (category: string) => {
    return category
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" & ")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="bg-white border-b">
          <div className="container max-w-5xl mx-auto px-4 py-6">
            <h1 className="text-2xl font-bold">8100 Sky Mountain Ln</h1>
            <p className="text-gray-600">Mountain View, California</p>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                <span className="text-green-600 font-medium">Completed</span>
              </div>
              <p className="text-sm text-gray-600">Inspection completed on March 5, 2025</p>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-2">
          <Link href="/inspections" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Inspections
          </Link>
        </div>

        <div className="container mx-auto px-4 py-4">
          {/* Header section */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Inspection Report</h2>
          </div>

          {/* Tab Navigation */}
          <div className="flex border rounded-lg overflow-hidden mb-6">
            <Link
              href={`/inspections/${params.id}`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-white border-b-2 border-[#E86C3A] font-medium text-gray-900"
            >
              Findings
            </Link>
            <Link
              href={`/inspections/${params.id}/maintenance`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-gray-50 text-gray-600 hover:bg-gray-100"
            >
              Maintenance Plan
            </Link>
            <Link
              href={`/inspections/${params.id}/products`}
              className="flex-1 py-3 px-4 text-center transition-colors bg-gray-50 text-gray-600 hover:bg-gray-100"
            >
              Recommended Products
            </Link>
          </div>

          {/* Category Content */}
          <div>
            <h3 className="text-lg font-medium mb-4">
              Detailed findings from your home inspection, organized by category.
            </h3>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-2 mb-6 overflow-x-auto pb-2">
              {[
                "hvac",
                "plumbing",
                "appliances",
                "electrical-system",
                "roofing",
                "structure-foundation",
                "exterior",
                "windows-doors",
              ].map((category) => {
                const isActive = category === activeCategory
                const displayName = category
                  .split("-")
                  .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                  .join(" & ")

                return (
                  <Link
                    key={category}
                    href={`/inspections/${params.id}/findings/${category}`}
                    className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-colors ${
                      isActive ? "bg-[#E86C3A] text-white" : "bg-white border hover:bg-gray-50"
                    }`}
                  >
                    {displayName}
                  </Link>
                )
              })}
            </div>

            {/* Category-specific content */}
            <div className="bg-white border rounded-lg mb-6 overflow-hidden">
              <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-xl font-semibold">{formatCategoryName(activeCategory)}</h3>
                {activeCategory === "roofing" && (
                  <span className="text-warning bg-warning-light px-3 py-1 rounded-md text-sm font-medium">
                    Minor Repairs
                  </span>
                )}
                {activeCategory === "plumbing" && (
                  <span className="text-success bg-success-light px-3 py-1 rounded-md text-sm font-medium">
                    Good Condition
                  </span>
                )}
                {activeCategory === "exterior" && (
                  <span className="text-warning bg-warning-light px-3 py-1 rounded-md text-sm font-medium">
                    Minor Repairs
                  </span>
                )}
              </div>
              <div className="p-4">
                {activeCategory === "roofing" && (
                  <>
                    <p className="mb-4">
                      Some shingles showing signs of wear and potential damage in the northwest corner of the roof.
                      Visual inspection revealed curling, cracking, and a few missing granules on approximately 15% of
                      the visible shingles.
                    </p>

                    {/* Image placeholders */}
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                        <img src="/placeholder.svg?height=200&width=300" alt="Roof inspection" className="max-h-full" />
                      </div>
                      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                        <img src="/placeholder.svg?height=200&width=300" alt="Roof inspection" className="max-h-full" />
                      </div>
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold mb-2">Inspector's Notes</h4>
                      <p className="text-gray-700">
                        The affected shingles are primarily on the northwest slope. While not an immediate concern for
                        leaks, these should be addressed within 3-6 months to prevent water intrusion and more extensive
                        damage. The flashing around the chimney appears to be in good condition.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Recommendations</h4>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>Replace damaged shingles within 3-6 months</li>
                        <li>Consider a full roof inspection if you notice any interior water stains</li>
                        <li>Clean gutters to ensure proper drainage</li>
                      </ul>
                    </div>
                  </>
                )}

                {activeCategory === "plumbing" && (
                  <>
                    <p className="mb-4">
                      All plumbing fixtures and pipes are functioning properly. Water pressure is within normal range at
                      all fixtures. No leaks detected in visible plumbing lines or under sinks.
                    </p>

                    {/* Image placeholder */}
                    <div className="aspect-video bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
                      <img
                        src="/placeholder.svg?height=300&width=600"
                        alt="Plumbing inspection"
                        className="max-h-full"
                      />
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold mb-2">Inspector's Notes</h4>
                      <p className="text-gray-700">
                        Water heater is approximately 5 years old and functioning properly. Main water shut-off valve is
                        accessible and operational. Drainage appears adequate with no signs of backup in any fixtures.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Recommendations</h4>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>Continue regular maintenance checks</li>
                        <li>Consider installing water leak detectors under sinks as a preventative measure</li>
                      </ul>
                    </div>
                  </>
                )}

                {activeCategory === "exterior" && (
                  <>
                    <p className="mb-4">
                      The exterior siding shows minor wear and tear, with some areas needing touch-up paint. The deck
                      has some weathered boards that should be replaced or treated to prevent further deterioration.
                    </p>

                    {/* Image placeholders */}
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                        <img src="/placeholder.svg?height=200&width=300" alt="Exterior siding" className="max-h-full" />
                      </div>
                      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                        <img src="/placeholder.svg?height=200&width=300" alt="Deck condition" className="max-h-full" />
                      </div>
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold mb-2">Inspector's Notes</h4>
                      <p className="text-gray-700">
                        The vinyl siding is in generally good condition with some fading on the south-facing side. The
                        deck is structurally sound but has cosmetic issues and early signs of weathering on several
                        boards. Gutters are properly attached but need cleaning.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Recommendations</h4>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>Touch up paint on worn areas of siding within the next year</li>
                        <li>Replace or treat weathered deck boards and consider resealing the entire deck</li>
                        <li>Clean gutters and check downspouts for proper drainage</li>
                      </ul>
                    </div>
                  </>
                )}

                {!["roofing", "plumbing", "exterior"].includes(activeCategory) && (
                  <p className="text-gray-600">
                    No significant issues were found with the {formatCategoryName(activeCategory)} during the
                    inspection. Regular maintenance is recommended.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Navigation />
    </div>
  )
}

