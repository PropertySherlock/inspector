"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Task = {
  id: string
  title: string
  dueDate: string
  difficulty: "Easy" | "Medium" | "Hard"
  duration: string
  completed: boolean
  isPastDue?: boolean
}

interface MaintenanceContextType {
  score: number
  maxScore: number
  completedTasks: number
  totalTasks: number
  tasks: Task[]
  updateTask: (taskId: string, completed: boolean) => void
}

const MaintenanceContext = createContext<MaintenanceContextType | undefined>(undefined)

export function MaintenanceProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Replace your air filter",
      dueDate: "MAR 27",
      difficulty: "Easy",
      duration: "10 minutes",
      completed: false,
    },
    {
      id: "2",
      title: "Clean your cooktop",
      dueDate: "MAR 29",
      difficulty: "Easy",
      duration: "15 minutes",
      completed: false,
    },
    {
      id: "3",
      title: "Inspect your exterior walls",
      dueDate: "MAR 30",
      difficulty: "Easy",
      duration: "10 minutes",
      completed: false,
    },
    // Past due tasks
    {
      id: "4",
      title: "Check smoke detector batteries",
      dueDate: "FEB 15",
      difficulty: "Easy",
      duration: "5 minutes",
      completed: false,
      isPastDue: true,
    },
    {
      id: "5",
      title: "Clean gutters",
      dueDate: "FEB 28",
      difficulty: "Medium",
      duration: "45 minutes",
      completed: false,
      isPastDue: true,
    },
    {
      id: "6",
      title: "Service HVAC system",
      dueDate: "JAN 30",
      difficulty: "Hard",
      duration: "Professional service",
      completed: false,
      isPastDue: true,
    },
  ])

  const [score, setScore] = useState(0)
  const maxScore = 100
  const [completedTasks, setCompletedTasks] = useState(0)

  // Calculate score and completed tasks whenever tasks change
  useEffect(() => {
    const completed = tasks.filter((task) => task.completed).length
    setCompletedTasks(completed)

    // Calculate score based on completed tasks
    // Each task is worth a certain number of points
    const pointsPerTask = maxScore / tasks.length
    const newScore = Math.round(completed * pointsPerTask)
    setScore(newScore)
  }, [tasks, maxScore])

  const updateTask = (taskId: string, completed: boolean) => {
    setTasks((prevTasks) => prevTasks.map((task) => (task.id === taskId ? { ...task, completed } : task)))
  }

  return (
    <MaintenanceContext.Provider
      value={{
        score,
        maxScore,
        completedTasks,
        totalTasks: tasks.length,
        tasks,
        updateTask,
      }}
    >
      {children}
    </MaintenanceContext.Provider>
  )
}

export function useMaintenanceContext() {
  const context = useContext(MaintenanceContext)
  if (context === undefined) {
    throw new Error("useMaintenanceContext must be used within a MaintenanceProvider")
  }
  return context
}

