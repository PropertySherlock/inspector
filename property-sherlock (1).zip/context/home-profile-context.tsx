"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { type Section, defaultSections } from "@/lib/home-profile-data"

interface HomeProfileContextType {
  sections: Section[]
  sectionData: Record<string, Record<string, any>>
  updateSectionData: (sectionId: string, data: Record<string, any>) => void
  getSectionData: (sectionId: string) => Record<string, any>
  getSectionPhotos: (sectionId: string) => File[]
  addSectionPhotos: (sectionId: string, photos: File[]) => void
}

const HomeProfileContext = createContext<HomeProfileContextType | undefined>(undefined)

export function HomeProfileProvider({ children }: { children: ReactNode }) {
  const [sections, setSections] = useState<Section[]>(defaultSections)
  const [sectionData, setSectionData] = useState<Record<string, Record<string, any>>>({})
  const [sectionPhotos, setSectionPhotos] = useState<Record<string, File[]>>({})

  // Load data from localStorage on initial render
  useEffect(() => {
    try {
      const savedSectionData = localStorage.getItem("homeProfileSectionData")
      if (savedSectionData) {
        setSectionData(JSON.parse(savedSectionData))
      }

      // Note: We can't store File objects in localStorage, so photos will be empty on reload
    } catch (error) {
      console.error("Error loading home profile data:", error)
    }
  }, [])

  // Save data to localStorage when it changes
  useEffect(() => {
    try {
      localStorage.setItem("homeProfileSectionData", JSON.stringify(sectionData))
    } catch (error) {
      console.error("Error saving section data:", error)
    }
  }, [sectionData])

  const updateSectionData = (sectionId: string, data: Record<string, any>) => {
    setSectionData((prev) => ({
      ...prev,
      [sectionId]: { ...prev[sectionId], ...data },
    }))
  }

  const getSectionData = (sectionId: string) => {
    return sectionData[sectionId] || {}
  }

  const getSectionPhotos = (sectionId: string) => {
    return sectionPhotos[sectionId] || []
  }

  const addSectionPhotos = (sectionId: string, photos: File[]) => {
    setSectionPhotos((prev) => ({
      ...prev,
      [sectionId]: [...(prev[sectionId] || []), ...photos],
    }))
  }

  return (
    <HomeProfileContext.Provider
      value={{
        sections,
        sectionData,
        updateSectionData,
        getSectionData,
        getSectionPhotos,
        addSectionPhotos,
      }}
    >
      {children}
    </HomeProfileContext.Provider>
  )
}

export function useHomeProfile() {
  const context = useContext(HomeProfileContext)
  if (context === undefined) {
    throw new Error("useHomeProfile must be used within a HomeProfileProvider")
  }
  return context
}

