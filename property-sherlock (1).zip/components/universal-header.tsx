"use client"

import { useState } from "react"
import Link from "next/link"
import { Logo } from "@/components/logo"
import { User, Bell, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function UniversalHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container max-w-5xl mx-auto px-3 flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 z-10">
          <Logo className="h-8 w-8" />
          <span className="text-xl font-bold">Property Sherlock</span>
        </Link>

        {/* Mobile menu button */}
        <button
          className="md:hidden p-2 text-gray-600 focus:outline-none z-10"
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/" className="text-foreground hover:text-primary transition-colors">
            Home
          </Link>
          <Link href="/about" className="text-foreground hover:text-primary transition-colors">
            About Us
          </Link>
          <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
            Contact Us
          </Link>
        </nav>

        {/* Mobile navigation */}
        {isMenuOpen && (
          <div className="fixed inset-0 bg-white z-0 pt-20 px-4">
            <nav className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/about"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                About Us
              </Link>
              <Link
                href="/contact"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact Us
              </Link>
              <Link
                href="/dashboard"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                Dashboard
              </Link>
              <Link
                href="/inspections"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                Inspections
              </Link>
              <Link
                href="/home-profile"
                className="text-foreground hover:text-primary transition-colors py-2 border-b"
                onClick={() => setIsMenuOpen(false)}
              >
                Home Profile
              </Link>
            </nav>
          </div>
        )}

        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
          </Button>
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard">
              <User className="h-5 w-5" />
              <span className="sr-only">Dashboard</span>
            </Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

