"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section } from "@/lib/home-profile-data"

interface DetailedInfoFormProps {
  section: Section
}

export function DetailedInfoForm({ section }: DetailedInfoFormProps) {
  const router = useRouter()
  const { getSectionData, updateSectionData, addSectionPhotos } = useHomeProfile()

  const existingData = getSectionData(section.id)
  const [notes, setNotes] = useState(existingData.notes || "")
  const [photos, setPhotos] = useState<File[]>([])

  const handleSave = () => {
    // Save notes
    updateSectionData(section.id, { notes })

    // Save photos
    if (photos.length > 0) {
      addSectionPhotos(section.id, photos)
    }

    router.back()
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Detailed Information</h1>
        </div>
      </div>

      <main className="flex-1 p-4 pb-20 max-w-3xl mx-auto">
        <div className="space-y-12">
          {/* Notes Section */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Additional notes about your {section.title.toLowerCase()}</h2>
            <Textarea
              placeholder="Enter any additional information..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="min-h-[200px] bg-white"
            />
          </div>

          {/* Photos Section */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Upload photos of your {section.title.toLowerCase()}</h2>
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-8">
              <div className="flex flex-col items-center text-center">
                <Camera className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Upload photos</h3>
                <p className="text-gray-500 mb-6">Drag and drop or click to browse</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  id="photo-upload"
                  onChange={handlePhotoUpload}
                />
                <label
                  htmlFor="photo-upload"
                  className="bg-white border border-gray-300 rounded-md px-6 py-2 cursor-pointer hover:border-gray-400 transition-colors text-base"
                >
                  Choose Files
                </label>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3 mt-8">
            <Button className="w-full bg-primary hover:bg-primary-dark text-white h-12 text-base" onClick={handleSave}>
              Save Changes
            </Button>
            <Button variant="ghost" className="w-full h-12" onClick={() => router.back()}>
              Cancel
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

