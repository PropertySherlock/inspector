"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, ThumbsUp, AlertTriangle, AlertCircle, CheckCircle2, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import { cn } from "@/lib/utils"
import type { Section } from "@/lib/home-profile-data"
import { Textarea } from "@/components/ui/textarea"

interface BasicInfoFormProps {
  section: Section
}

type Condition = "excellent" | "good" | "fair" | "poor"

interface ConditionOption {
  value: Condition
  label: string
  description: string
  icon: React.ComponentType<{ className?: string }>
  color: string
}

const conditionOptions: ConditionOption[] = [
  {
    value: "excellent",
    label: "Excellent",
    description: "Like new, no visible issues",
    icon: CheckCircle2,
    color: "bg-success-light border-success text-success",
  },
  {
    value: "good",
    label: "Good",
    description: "Minor wear, no apparent issues",
    icon: ThumbsUp,
    color: "bg-primary/10 border-primary text-primary",
  },
  {
    value: "fair",
    label: "Fair",
    description: "Some visible wear, may need attention soon",
    icon: AlertTriangle,
    color: "bg-warning-light border-warning text-warning",
  },
  {
    value: "poor",
    label: "Poor",
    description: "Significant wear or damage, needs attention",
    icon: AlertCircle,
    color: "bg-danger-light border-danger text-danger",
  },
]

export function BasicInfoForm({ section }: BasicInfoFormProps) {
  const router = useRouter()
  const { getSectionData, updateSectionData } = useHomeProfile()
  const currentYear = new Date().getFullYear()

  const existingData = getSectionData(section.id)
  const [formData, setFormData] = useState({
    installationYear: existingData.installationYear || "",
    brandModel: existingData.brandModel || "",
    condition: existingData.condition || "",
    lastMaintenance: existingData.lastMaintenance || "",
    notes: existingData.notes || "",
    photos: existingData.photos || [],
  })
  const [isSaving, setIsSaving] = useState(false)
  const [yearError, setYearError] = useState("")

  const validateYear = (year: string) => {
    const yearNum = Number.parseInt(year)
    if (year && (isNaN(yearNum) || yearNum < 1900 || yearNum > currentYear)) {
      setYearError(`Please enter a valid year between 1900 and ${currentYear}`)
      return false
    }
    setYearError("")
    return true
  }

  const handleSave = async () => {
    if (formData.installationYear && !validateYear(formData.installationYear)) {
      return
    }

    setIsSaving(true)
    try {
      await updateSectionData(section.id, formData)
      router.back()
    } catch (error) {
      console.error("Error saving data:", error)
      setIsSaving(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Basic Information</h1>
        </div>
      </div>

      <main className="flex-1 p-4 max-w-3xl mx-auto">
        <div className="bg-white rounded-lg border p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Enter {section.title.toLowerCase()} details</h2>

          <div className="space-y-6">
            {/* Installation Year */}
            <div className="space-y-2">
              <label htmlFor="installationYear" className="text-sm font-medium">
                Installation year
              </label>
              <div className="max-w-[200px]">
                <Input
                  id="installationYear"
                  placeholder={`1900 - ${currentYear}`}
                  value={formData.installationYear}
                  onChange={(e) => {
                    setFormData({ ...formData, installationYear: e.target.value })
                    validateYear(e.target.value)
                  }}
                  className={cn(yearError && "border-red-500")}
                />
                {yearError && <p className="text-sm text-red-500 mt-1">{yearError}</p>}
              </div>
            </div>

            {/* Brand/Model */}
            <div className="space-y-2">
              <label htmlFor="brandModel" className="text-sm font-medium">
                Brand & Model
              </label>
              <Input
                id="brandModel"
                placeholder="e.g., Carrier XL19i"
                value={formData.brandModel}
                onChange={(e) => setFormData({ ...formData, brandModel: e.target.value })}
              />
            </div>

            {/* Condition Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Condition</label>
              <div className="grid sm:grid-cols-2 gap-4">
                {conditionOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    className={cn(
                      "p-4 rounded-lg border-2 text-left transition-all",
                      formData.condition === option.value
                        ? option.color
                        : "border-gray-200 hover:border-gray-300 bg-white",
                    )}
                    onClick={() => setFormData({ ...formData, condition: option.value })}
                  >
                    <div className="flex items-start gap-3">
                      <option.icon
                        className={cn("h-5 w-5 mt-0.5", formData.condition === option.value ? "" : "text-gray-400")}
                      />
                      <div>
                        <div className="font-medium mb-1">{option.label}</div>
                        <div className="text-sm opacity-90">{option.description}</div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Last Maintenance */}
            <div className="space-y-2">
              <label htmlFor="lastMaintenance" className="text-sm font-medium">
                Last maintenance
              </label>
              <div className="max-w-[200px]">
                <Input
                  id="lastMaintenance"
                  type="month"
                  value={formData.lastMaintenance}
                  onChange={(e) => setFormData({ ...formData, lastMaintenance: e.target.value })}
                  max={new Date().toISOString().slice(0, 7)}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Notes Section */}
        <div className="bg-white rounded-lg border p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Notes</h3>
          <Textarea
            placeholder="Enter any additional information..."
            value={formData.notes || ""}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            className="min-h-[150px]"
          />
        </div>

        {/* Photos Section */}
        <div className="bg-white rounded-lg border p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Photos</h3>
          <div className="border-2 border-dashed border-gray-200 rounded-lg p-8">
            <div className="flex flex-col items-center text-center">
              <Upload className="h-8 w-8 text-gray-400 mb-2" />
              <p className="text-sm text-gray-500 mb-4">Drag and drop or click to browse</p>
              <input
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                id="photo-upload"
                onChange={(e) => {
                  if (e.target.files) {
                    const newPhotos = Array.from(e.target.files)
                    setFormData((prev) => ({
                      ...prev,
                      photos: [...(prev.photos || []), ...newPhotos],
                    }))
                  }
                }}
              />
              <label
                htmlFor="photo-upload"
                className="bg-white border border-gray-300 rounded-md px-4 py-2 cursor-pointer hover:border-gray-400 transition-colors"
              >
                Upload photos
              </label>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-3">
          <Button
            className="w-full bg-primary hover:bg-primary-dark text-white h-12 text-base"
            onClick={handleSave}
            disabled={isSaving}
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>

          <Button variant="ghost" className="w-full h-12" onClick={() => router.back()} disabled={isSaving}>
            Cancel
          </Button>
        </div>
      </main>
    </div>
  )
}

