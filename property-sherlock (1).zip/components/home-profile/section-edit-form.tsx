"use client"

import { useState } from "react"
import { ArrowLeft, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section, Field } from "@/lib/home-profile-data"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface SectionEditFormProps {
  section: Section
}

export function SectionEditForm({ section }: SectionEditFormProps) {
  const router = useRouter()
  const { getSectionData, updateSectionData } = useHomeProfile()

  const existingData = getSectionData(section.id)
  const [formData, setFormData] = useState<Record<string, any>>(existingData)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSaving, setIsSaving] = useState(false)

  const handleInputChange = (fieldId: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [fieldId]: value,
    }))

    // Clear error when field is updated
    if (errors[fieldId]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[fieldId]
        return newErrors
      })
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    section.fields.forEach((field) => {
      // Check required fields
      if (field.required && (!formData[field.id] || formData[field.id] === "")) {
        newErrors[field.id] = `${field.label} is required`
      }

      // Validate number fields
      if (field.type === "number" && formData[field.id] && isNaN(Number(formData[field.id]))) {
        newErrors[field.id] = `${field.label} must be a number`
      }
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSave = () => {
    if (!validateForm()) {
      return
    }

    setIsSaving(true)
    // Save the data
    updateSectionData(section.id, formData)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      router.back()
    }, 500)
  }

  const renderField = (field: Field) => {
    switch (field.type) {
      case "text":
      case "date":
        return (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
            className={errors[field.id] ? "border-red-500" : ""}
          />
        )
      case "number":
        return (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
            type="number"
            className={errors[field.id] ? "border-red-500" : ""}
          />
        )
      case "textarea":
        return (
          <Textarea
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
            className={errors[field.id] ? "border-red-500" : ""}
          />
        )
      case "select":
        return (
          <Select value={formData[field.id] || ""} onValueChange={(value) => handleInputChange(field.id, value)}>
            <SelectTrigger className={errors[field.id] ? "border-red-500" : ""}>
              <SelectValue placeholder={field.placeholder || `Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      default:
        return null
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">{section.title}</h1>
        </div>
      </div>

      <main className="flex-1 p-4 max-w-3xl mx-auto">
        <div className="bg-white rounded-lg border p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Enter {section.title.toLowerCase()} details</h2>

          <div className="space-y-6">
            {section.fields.map((field) => (
              <div key={field.id} className="space-y-2">
                <div className="flex items-center">
                  <label htmlFor={field.id} className="text-sm font-medium">
                    {field.label} {field.required && <span className="text-red-500">*</span>}
                  </label>

                  {field.description && (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <Info className="h-4 w-4" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">{field.description}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>

                {renderField(field)}

                {errors[field.id] && <p className="text-red-500 text-sm">{errors[field.id]}</p>}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            className="flex-1 bg-primary hover:bg-primary-dark text-white"
            onClick={handleSave}
            disabled={isSaving}
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>

          <Button variant="outline" className="flex-1" onClick={() => router.back()}>
            Cancel
          </Button>
        </div>
      </main>
    </div>
  )
}

