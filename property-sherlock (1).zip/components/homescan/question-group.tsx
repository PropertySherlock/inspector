import type { ReactNode } from "react"

interface QuestionGroupProps {
  title: string
  children: ReactNode
}

export function QuestionGroup({ title, children }: QuestionGroupProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  )
}

