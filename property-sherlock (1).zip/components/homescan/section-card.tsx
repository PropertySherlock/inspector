import type { ReactNode } from "react"

interface SectionCardProps {
  title: string
  children: ReactNode
}

export function SectionCard({ title, children }: SectionCardProps) {
  return (
    <section className="mb-10 last:mb-0">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="space-y-6">{children}</div>
    </section>
  )
}

