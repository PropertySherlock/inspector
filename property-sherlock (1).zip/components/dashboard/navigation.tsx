"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, Tag } from "lucide-react"
import { cn } from "@/lib/utils"

export function Navigation() {
  const pathname = usePathname()

  // Helper function to check if a path is active
  const isActive = (path: string) => {
    if (path === "/dashboard") {
      // For dashboard, only match exact path or root path
      return pathname === "/dashboard" || pathname === "/"
    }
    // For other paths, check if the pathname starts with the path
    return pathname.startsWith(path)
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2 z-10">
      <Link
        href="/dashboard"
        className={cn("flex flex-col items-center p-2", isActive("/dashboard") ? "text-primary" : "text-gray-500")}
      >
        <Home className="h-6 w-6" />
        <span className="text-xs mt-1">Maintenance</span>
      </Link>
      <Link
        href="/inspections"
        className={cn(
          "flex flex-col items-center p-2",
          isActive("/inspections") ? "text-primary" : "text-gray-500 hover:text-gray-700",
        )}
      >
        <Search className="h-6 w-6" />
        <span className="text-xs mt-1">Inspections</span>
      </Link>
      <Link
        href="/offers"
        className={cn("flex flex-col items-center p-2", isActive("/offers") ? "text-primary" : "text-gray-500")}
      >
        <Tag className="h-6 w-6" />
        <span className="text-xs mt-1">Offers</span>
      </Link>
    </nav>
  )
}

