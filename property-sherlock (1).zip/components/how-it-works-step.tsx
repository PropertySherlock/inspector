import Image from "next/image"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

interface HowItWorksStepProps {
  number: string
  title: string
  description: string
  imageSrc: string
}

export function HowItWorksStep({ number, title, description, imageSrc }: HowItWorksStepProps) {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-shadow overflow-hidden">
      <div className="relative h-48 w-full">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
        <div className="absolute top-4 left-4 bg-[#161B22] text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">
          {number}
        </div>
      </div>
      <CardHeader className="pb-2">
        <h3 className="text-xl font-semibold">{title}</h3>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  )
}

