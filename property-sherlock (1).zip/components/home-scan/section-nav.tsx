"use client"

import * as React from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface Section {
  id: string
  name: string
}

const sections: Section[] = [
  { id: "hvac", name: "HVAC" },
  { id: "plumbing", name: "Plumbing" },
  { id: "appliances", name: "Appliances" },
  { id: "electrical", name: "Electrical System" },
  { id: "roofing", name: "Roofing" },
  { id: "structure", name: "Structure & Foundation" },
  { id: "exterior", name: "Exterior" },
  { id: "windows", name: "Windows & Doors" },
]

interface SectionNavProps {
  currentSection: string
}

export function SectionNav({ currentSection }: SectionNavProps) {
  const scrollContainerRef = React.useRef<HTMLDivElement>(null)
  const [showLeftScroll, setShowLeftScroll] = React.useState(false)
  const [showRightScroll, setShowRightScroll] = React.useState(true)

  const checkScroll = () => {
    if (!scrollContainerRef.current) return
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current
    setShowLeftScroll(scrollLeft > 0)
    setShowRightScroll(scrollLeft < scrollWidth - clientWidth - 10)
  }

  React.useEffect(() => {
    const scrollContainer = scrollContainerRef.current
    if (scrollContainer) {
      scrollContainer.addEventListener("scroll", checkScroll)
      checkScroll()
      return () => scrollContainer.removeEventListener("scroll", checkScroll)
    }
  }, [])

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return
    const scrollAmount = direction === "left" ? -200 : 200
    scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" })
  }

  return (
    <div className="relative w-full bg-gray-100 py-4">
      {showLeftScroll && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 shadow-md hover:bg-white"
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      )}

      <div ref={scrollContainerRef} className="flex overflow-x-auto scrollbar-hide gap-2 px-8">
        {sections.map((section) => (
          <Link
            key={section.id}
            href={`/homescan/${section.id}`}
            className={cn(
              "px-4 py-2 rounded-full whitespace-nowrap transition-colors",
              "hover:bg-gray-200",
              section.id === currentSection ? "bg-primary text-white" : "bg-white",
            )}
          >
            {section.name}
          </Link>
        ))}
      </div>

      {showRightScroll && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 shadow-md hover:bg-white"
          onClick={() => scroll("right")}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

