import type { HomeScanData } from "@/types/homescan"

// This would be replaced with actual API calls in a real application
let homeScanProgress = 10 // Initial progress value
let homeScanCompleted = false

export async function getHomeScanData(): Promise<HomeScanData> {
  // Simulate API call
  return {
    sections: [
      {
        id: "exterior",
        name: "Exterior",
        questions: [
          {
            id: "roof-condition",
            type: "condition",
            question: "What is the overall condition of your roof?",
            options: [
              {
                value: "excellent",
                label: "Excellent",
                description: "Like new, no visible issues",
              },
              {
                value: "good",
                label: "Good",
                description: "Minor wear, no apparent issues",
              },
              {
                value: "fair",
                label: "Fair",
                description: "Some visible wear, may need attention soon",
              },
              {
                value: "poor",
                label: "Poor",
                description: "Significant wear or damage, needs attention",
              },
            ],
            required: true,
          },
          {
            id: "siding-material",
            type: "text",
            question: "What material is your siding made of?",
            description: "e.g., vinyl, wood, brick, stucco",
            required: true,
          },
          {
            id: "exterior-notes",
            type: "textarea",
            question: "Additional notes about your exterior walls",
            required: false,
          },
          {
            id: "exterior-photos",
            type: "photo",
            question: "Upload photos of your exterior walls",
            required: false,
          },
        ],
      },
      {
        id: "interior",
        name: "Interior",
        questions: [
          {
            id: "flooring-condition",
            type: "condition",
            question: "What is the overall condition of your flooring?",
            options: [
              {
                value: "excellent",
                label: "Excellent",
                description: "Like new, no visible issues",
              },
              {
                value: "good",
                label: "Good",
                description: "Minor wear, no apparent issues",
              },
              {
                value: "fair",
                label: "Fair",
                description: "Some visible wear, may need attention soon",
              },
              {
                value: "poor",
                label: "Poor",
                description: "Significant wear or damage, needs attention",
              },
            ],
            required: true,
          },
        ],
      },
      {
        id: "systems",
        name: "Systems",
        questions: [
          {
            id: "hvac-age",
            type: "text",
            question: "How old is your HVAC system?",
            description: "Approximate age in years",
            required: true,
          },
        ],
      },
    ],
    progress: homeScanProgress,
    completed: homeScanCompleted,
  }
}

export async function saveHomeScanProgress(data: any): Promise<{ success: boolean }> {
  // Simulate API call
  console.log("Saving data:", data)

  // Handle different actions
  if (data.action === "save") {
    // Increase progress when saving a section
    if (data.sectionId) {
      // In a real app, this would calculate based on actual completion
      homeScanProgress += 5
      if (homeScanProgress > 100) homeScanProgress = 100
    }
  } else if (data.action === "complete") {
    // Mark as completed and set progress to 100%
    homeScanCompleted = true
    homeScanProgress = 100
  } else if (data.sectionId) {
    // Default behavior for section completion
    homeScanProgress += 15
    if (homeScanProgress > 100) homeScanProgress = 100
  }

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  return { success: true }
}

