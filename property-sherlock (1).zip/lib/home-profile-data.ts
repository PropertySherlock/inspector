import { Home, Shield, Droplet, Fan, Tv, ExternalLink, LayoutDashboard, Zap, Hammer } from "lucide-react"

// Define types for our home profile data
export type FieldType = "text" | "select" | "number" | "textarea" | "photo" | "date"

export interface Field {
  id: string
  label: string
  type: FieldType
  placeholder?: string
  options?: { value: string; label: string }[]
  required?: boolean
  description?: string
}

export interface Section {
  id: string
  title: string
  icon: any // Lucide icon component
  description?: string
  fields: Field[]
}

// Default sections configuration
export const defaultSections: Section[] = [
  {
    id: "basic",
    title: "Basic information",
    icon: Home,
    description: "General information about your home",
    fields: [
      {
        id: "yearBuilt",
        label: "Year Built",
        type: "text",
        placeholder: "e.g., 1985",
      },
      {
        id: "squareFootage",
        label: "Square Footage",
        type: "number",
        placeholder: "e.g., 2000",
      },
      {
        id: "bedrooms",
        label: "Number of Bedrooms",
        type: "number",
        placeholder: "e.g., 3",
      },
      {
        id: "bathrooms",
        label: "Number of Bathrooms",
        type: "number",
        placeholder: "e.g., 2.5",
      },
      {
        id: "stories",
        label: "Number of Stories",
        type: "select",
        options: [
          { value: "1", label: "1 story" },
          { value: "1.5", label: "1.5 stories" },
          { value: "2", label: "2 stories" },
          { value: "2.5", label: "2.5 stories" },
          { value: "3+", label: "3+ stories" },
        ],
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your home...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your home",
      },
    ],
  },
  {
    id: "protection",
    title: "Protection",
    icon: Shield,
    description: "Security and safety features",
    fields: [
      {
        id: "securitySystem",
        label: "Security system",
        type: "select",
        options: [
          { value: "none", label: "None" },
          { value: "basic", label: "Basic alarm" },
          { value: "advanced", label: "Advanced system" },
          { value: "monitored", label: "Professionally monitored" },
        ],
      },
      {
        id: "smokeDetectors",
        label: "Smoke detectors",
        type: "select",
        options: [
          { value: "none", label: "None" },
          { value: "basic", label: "Basic" },
          { value: "smart", label: "Smart detectors" },
        ],
      },
      {
        id: "lastInspection",
        label: "Last safety inspection",
        type: "date",
        placeholder: "MM/YYYY",
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your home's protection features...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your security system, smoke detectors, etc.",
      },
    ],
  },
  {
    id: "plumbing",
    title: "Plumbing",
    icon: Droplet,
    description: "Plumbing systems and fixtures",
    fields: [
      {
        id: "waterHeaterType",
        label: "Water heater type",
        type: "select",
        options: [
          { value: "tank", label: "Tank" },
          { value: "tankless", label: "Tankless" },
          { value: "heatPump", label: "Heat pump" },
        ],
      },
      {
        id: "waterHeaterAge",
        label: "Water heater age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "pipeMaterial",
        label: "Pipe material",
        type: "select",
        options: [
          { value: "copper", label: "Copper" },
          { value: "pex", label: "PEX" },
          { value: "galvanized", label: "Galvanized" },
          { value: "pvc", label: "PVC" },
        ],
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your plumbing system...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your water heater, pipes, etc.",
      },
    ],
  },
  {
    id: "hvac",
    title: "HVAC",
    icon: Fan,
    description: "Heating, ventilation, and air conditioning",
    fields: [
      {
        id: "systemType",
        label: "System type",
        type: "select",
        options: [
          { value: "central", label: "Central AC with furnace" },
          { value: "heatPump", label: "Heat pump" },
          { value: "ductless", label: "Ductless mini-split" },
          { value: "other", label: "Other" },
        ],
      },
      {
        id: "systemAge",
        label: "System age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "lastService",
        label: "Last service date",
        type: "date",
        placeholder: "MM/YYYY",
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your HVAC system...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your HVAC system",
      },
    ],
  },
  {
    id: "appliances",
    title: "Appliances",
    icon: Tv,
    description: "Major home appliances",
    fields: [
      {
        id: "refrigerator",
        label: "Refrigerator age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "dishwasher",
        label: "Dishwasher age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "washer",
        label: "Washer age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "dryer",
        label: "Dryer age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "stove",
        label: "Stove/oven age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your appliances...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your appliances",
      },
    ],
  },
  {
    id: "exterior",
    title: "Exterior",
    icon: ExternalLink,
    description: "Exterior features and materials",
    fields: [
      {
        id: "roofType",
        label: "Roof type",
        type: "select",
        options: [
          { value: "asphalt", label: "Asphalt shingles" },
          { value: "metal", label: "Metal" },
          { value: "tile", label: "Tile" },
          { value: "slate", label: "Slate" },
          { value: "other", label: "Other" },
        ],
      },
      {
        id: "roofAge",
        label: "Roof age",
        type: "number",
        placeholder: "Years",
      },
      {
        id: "sidingType",
        label: "Siding type",
        type: "select",
        options: [
          { value: "vinyl", label: "Vinyl" },
          { value: "wood", label: "Wood" },
          { value: "brick", label: "Brick" },
          { value: "stucco", label: "Stucco" },
          { value: "other", label: "Other" },
        ],
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your home's exterior...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your roof, siding, etc.",
      },
    ],
  },
  {
    id: "interior",
    title: "Interior",
    icon: LayoutDashboard,
    description: "Interior features and materials",
    fields: [
      {
        id: "flooringType",
        label: "Primary flooring type",
        type: "select",
        options: [
          { value: "hardwood", label: "Hardwood" },
          { value: "laminate", label: "Laminate" },
          { value: "tile", label: "Tile" },
          { value: "carpet", label: "Carpet" },
          { value: "vinyl", label: "Vinyl" },
          { value: "other", label: "Other" },
        ],
      },
      {
        id: "paintAge",
        label: "Last painted",
        type: "number",
        placeholder: "Years ago",
      },
      {
        id: "notes",
        label: "Additional Notes",
        type: "textarea",
        placeholder: "Enter any additional details about your home's interior...",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your interior",
      },
    ],
  },
  {
    id: "upgrades",
    title: "Upgrades",
    icon: Zap,
    description: "Home upgrades and improvements",
    fields: [
      {
        id: "recentUpgrades",
        label: "Recent upgrades",
        type: "textarea",
        placeholder: "List major upgrades and when they were completed",
      },
      {
        id: "plannedUpgrades",
        label: "Planned upgrades",
        type: "textarea",
        placeholder: "List any upgrades you're planning to make",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your upgrades",
      },
    ],
  },
  {
    id: "remodels",
    title: "Remodels",
    icon: Hammer,
    description: "Major remodeling projects",
    fields: [
      {
        id: "recentRemodels",
        label: "Recent remodels",
        type: "textarea",
        placeholder: "List major remodels and when they were completed",
      },
      {
        id: "plannedRemodels",
        label: "Planned remodels",
        type: "textarea",
        placeholder: "List any remodels you're planning",
      },
      {
        id: "photos",
        label: "Photos",
        type: "photo",
        description: "Upload photos of your remodels",
      },
    ],
  },
]

// Function to get section by ID
export function getSectionById(id: string): Section | undefined {
  return defaultSections.find((section) => section.id === id)
}

