import type React from "react"
import "@/styles/globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { BottomNav } from "@/components/bottom-nav"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Property Sherlock",
  description: "Smart home inspection and maintenance tracking",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        {children}
        <BottomNav />
        {/* Add padding to main content to account for fixed bottom nav */}
        <div className="pb-[72px]" />
      </body>
    </html>
  )
}



import './globals.css'