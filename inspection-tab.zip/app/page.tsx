import { AddressSelector } from "@/components/address-selector"
import { Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  // Mock data - in a real app, this would come from an API
  const inspections = [
    { id: "1", address: "8100 Sky Mountain Ln", date: "March 5, 2025", status: "Completed" as const },
    { id: "2", address: "8100 Sky Mountain Ln", date: "December 10, 2024", status: "Completed" as const },
  ]

  return (
    <main>
      <div className="bg-gray-50 py-6 border-b">
        <div className="container mx-auto px-4">
          <AddressSelector />
        </div>
      </div>

      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Inspections</h2>
            <Button className="bg-orange-500 hover:bg-orange-600 text-white">
              <Calendar className="h-4 w-4 mr-2" />
              Schedule New
            </Button>
          </div>
          <div className="space-y-4">
            {inspections.map((inspection) => (
              <div
                key={inspection.id}
                className="bg-white rounded-lg border p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <h3 className="font-bold text-lg">{inspection.address}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-sm text-gray-500">Inspection on {inspection.date}</p>
                    <div className="px-2 py-0.5 rounded-full text-xs bg-green-50 text-green-700 border border-green-200">
                      {inspection.status}
                    </div>
                  </div>
                </div>
                <a
                  href={`/inspection/${inspection.id}`}
                  className="inline-flex items-center px-4 py-2 border border-orange-200 text-orange-600 rounded-md hover:bg-orange-50"
                >
                  <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M14 3V7C14 7.26522 14.1054 7.51957 14.2929 7.70711C14.4804 7.89464 14.7348 8 15 8H19"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M17 21H7C6.46957 21 5.96086 20.7893 5.58579 20.4142C5.21071 20.0391 5 19.5304 5 19V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H14L19 8V19C19 19.5304 18.7893 20.0391 18.4142 20.4142C18.0391 20.7893 17.5304 21 17 21Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  View Report
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

