import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Property Sherlock - Inspection",
  description: "View your property inspection reports and maintenance tasks",
}

export default function InspectionLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen bg-background">{children}</div>
}

