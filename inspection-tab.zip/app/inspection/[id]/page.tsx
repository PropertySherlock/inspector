"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Download, ExternalLink, Share, Users, Home, Wrench, Gift, Calendar } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function InspectionPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("findings")

  // Mock data - in a real app, this would come from an API based on the ID
  const inspectionData = {
    address: "8100 Sky Mountain Ln",
    city: "Mountain View",
    state: "California",
    date: "March 5, 2025",
    status: "Completed",
  }

  return (
    <main className="pb-16">
      <div className="bg-gray-50 py-6 border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-1">
            <h1 className="text-2xl font-bold">{inspectionData.address}</h1>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              {inspectionData.status}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-gray-500">
              {inspectionData.city}, {inspectionData.state}
            </p>
            <p className="text-gray-500">Inspection completed on {inspectionData.date}</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-6 px-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Link href="/" className="text-sm text-gray-500 hover:text-orange-600 flex items-center gap-1">
                <ChevronRight className="h-4 w-4 rotate-180" />
                Back to Inspections
              </Link>
            </div>
            <h1 className="text-2xl font-bold mt-2">Inspection Report</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button className="bg-orange-500 hover:bg-orange-600 text-white">
              <Calendar className="h-4 w-4 mr-2" />
              Schedule New
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1 text-gray-700 border-gray-300">
              <Share className="h-4 w-4" />
              Share
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1 text-gray-700 border-gray-300">
              <Download className="h-4 w-4" />
              Download
            </Button>
          </div>
        </div>

        <Tabs defaultValue="findings" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 w-full bg-gray-100 p-1 rounded-lg">
            <TabsTrigger
              value="findings"
              className={`rounded-md ${activeTab === "findings" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
            >
              Findings
            </TabsTrigger>
            <TabsTrigger
              value="maintenance"
              className={`rounded-md ${activeTab === "maintenance" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
            >
              Maintenance Plan
            </TabsTrigger>
            <TabsTrigger
              value="products"
              className={`rounded-md ${activeTab === "products" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
            >
              Recommended Products
            </TabsTrigger>
          </TabsList>

          <TabsContent value="findings" className="mt-6">
            <FindingsTab />
          </TabsContent>

          <TabsContent value="maintenance" className="mt-6">
            <MaintenanceTab />
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <ProductsTab />
          </TabsContent>
        </Tabs>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2">
        <Link href="/maintenance" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Wrench className="h-6 w-6" />
          <span className="text-xs mt-1">Maintenance</span>
        </Link>
        <Link href="/inspections" className="flex flex-col items-center p-2 text-orange-600">
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Inspections</span>
        </Link>
        <Link href="/offers" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Gift className="h-6 w-6" />
          <span className="text-xs mt-1">Offers</span>
        </Link>
      </div>
    </main>
  )
}

function FindingsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">
          Detailed findings from your home inspection, organized by category.
        </h2>
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            HVAC
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Plumbing
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Appliances
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Electrical System
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Roofing
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Structure & Foundation
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Exterior
          </Badge>
          <Badge variant="outline" className="bg-white cursor-pointer hover:bg-gray-100">
            Windows & Doors
          </Badge>
        </div>
      </div>

      <Card className="border-red-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Roof</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              Minor Repairs
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-500">
            Some shingles showing signs of wear and potential damage in the northwest corner of the roof. Visual
            inspection revealed curling, cracking, and a few missing granules on approximately 15% of the visible
            shingles.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="Damaged roof shingles"
                width={500}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="Northwest corner of roof"
                width={500}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <h4 className="font-medium text-sm mb-2">Inspector's Notes</h4>
            <p className="text-sm text-gray-500">
              The affected shingles are primarily on the northwest slope. While not an immediate concern for leaks,
              these should be addressed within 3-6 months to prevent water intrusion and more extensive damage. The
              flashing around the chimney appears to be in good condition.
            </p>
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
              <li>Replace damaged shingles within 3-6 months</li>
              <li>Consider a full roof inspection if you notice any interior water stains</li>
              <li>Clean gutters to ensure proper drainage</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="border-green-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Plumbing</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Good Condition
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-500">
            All plumbing fixtures and pipes are functioning properly. Water pressure is within normal range at all
            fixtures. No leaks detected in visible plumbing lines or under sinks.
          </p>

          <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
            <Image
              src="/placeholder.svg?height=300&width=500"
              alt="Water heater in good condition"
              width={500}
              height={300}
              className="object-cover w-full h-full"
            />
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <h4 className="font-medium text-sm mb-2">Inspector's Notes</h4>
            <p className="text-sm text-gray-500">
              Water heater is approximately 5 years old and functioning properly. Main water shut-off valve is
              accessible and operational. Drainage appears adequate with no signs of backup in any fixtures.
            </p>
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
              <li>Continue regular maintenance checks</li>
              <li>Consider installing water leak detectors under sinks as a preventative measure</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Electrical</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              Needs Attention
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-500">
            Outdated electrical panel with potential safety concerns. The main panel is a 100-amp service with fuses
            rather than circuit breakers. Several outlets in bathrooms lack GFCI protection.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="aspect-square bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Outdated electrical panel"
                width={300}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="aspect-square bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Fuse box"
                width={300}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="aspect-square bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Non-GFCI outlet in bathroom"
                width={300}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <h4 className="font-medium text-sm mb-2">Inspector's Notes</h4>
            <p className="text-sm text-gray-500">
              The electrical panel appears to be original to the home (circa 1970s) and does not meet current safety
              standards. Some outlets show signs of wear, and bathroom outlets lack required GFCI protection. No
              evidence of aluminum wiring was found.
            </p>
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
              <li>Consult with a licensed electrician for panel upgrade</li>
              <li>Install GFCI outlets in all bathrooms, kitchen, and exterior locations</li>
              <li>Consider upgrading to a 200-amp service if planning major renovations</li>
              <li>Replace worn outlets throughout the home</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>HVAC</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
              Maintenance Required
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-500">
            HVAC system is operational but showing signs of reduced efficiency. Air filter is heavily soiled and
            restricting airflow. System is approximately 8 years old with expected remaining lifespan of 7-10 years.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="HVAC system"
                width={500}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="Dirty air filter"
                width={500}
                height={300}
                className="object-cover w-full h-full"
              />
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <h4 className="font-medium text-sm mb-2">Inspector's Notes</h4>
            <p className="text-sm text-gray-500">
              The furnace and AC unit are functioning but would benefit from professional servicing. Temperature
              differential across supply and return registers is slightly below optimal range. Ductwork appears to be in
              good condition with no visible leaks or disconnections.
            </p>
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
              <li>Replace air filter immediately (size 16×20)</li>
              <li>Schedule professional HVAC maintenance service</li>
              <li>Consider duct cleaning service if not done in the past 5 years</li>
              <li>Set reminder to check filter every 30-90 days</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Note: This component is designed to be dynamic. Additional categories and findings can be added from the backend as needed. */}
    </div>
  )
}

function MaintenanceTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">To-do's</h2>
      <div className="space-y-4">
        <TaskItem
          dueDate="MAR 27"
          title="Replace your air filter"
          difficulty="Easy"
          duration="10 minutes"
          href="/inspection/task/air-filter"
        />
        <TaskItem
          dueDate="MAR 29"
          title="Clean your cooktop"
          difficulty="Easy"
          duration="15 minutes"
          href="/inspection/task/clean-cooktop"
        />
        <TaskItem
          dueDate="MAR 30"
          title="Test smoke detectors"
          difficulty="Easy"
          duration="5 minutes"
          href="/inspection/task/test-smoke-detectors"
        />
      </div>
    </div>
  )
}

function TaskItem({
  dueDate,
  title,
  difficulty,
  duration,
  href,
}: {
  dueDate: string
  title: string
  difficulty: string
  duration: string
  href: string
}) {
  const [isChecked, setIsChecked] = useState(false)

  return (
    <div className="flex items-start gap-4 p-6 bg-white rounded-lg border hover:border-orange-200 transition-colors">
      <button
        onClick={() => setIsChecked(!isChecked)}
        className={`mt-1 w-6 h-6 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
          isChecked ? "bg-orange-500 border-orange-500" : "border-gray-200 hover:border-orange-500"
        }`}
        aria-label={isChecked ? "Mark as incomplete" : "Mark as complete"}
      >
        {isChecked && (
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M11.6666 3.5L5.24992 9.91667L2.33325 7"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>
      <div className="flex-grow min-w-0">
        <div className="text-sm text-gray-500 mb-1">DUE {dueDate}</div>
        <h3 className={`text-lg font-medium mb-2.5 ${isChecked ? "line-through text-gray-400" : ""}`}>{title}</h3>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-900 font-normal">{difficulty}</span>
          <span className="px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-900 font-normal">{duration}</span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          className="h-9 px-4 text-orange-600 border-orange-200 hover:bg-orange-50 hover:text-orange-600 font-normal"
        >
          <Users className="h-4 w-4 mr-2" />
          Get Help
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-9 px-4 text-orange-600 hover:text-orange-600 font-normal"
          asChild
        >
          <Link href={href} className="flex items-center">
            Details
            <ChevronRight className="h-4 w-4 ml-1 mt-px" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

function ProductsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Recommended Products</h2>
        <p className="text-gray-500 mb-6">
          Based on your inspection results, we recommend these products to improve your home.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-0 relative">
            <Badge className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600 text-white">Recommended</Badge>
            <div className="aspect-square bg-gray-100 rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="SimpliSafe Home Security System"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">SimpliSafe Home Security System</h3>
            <p className="text-orange-600 font-medium my-1">$279.99</p>
            <p className="text-sm text-gray-500 mb-4">
              Complete wireless home security system with professional monitoring. Easy to install and no long-term
              contracts.
            </p>
            <Button
              className="w-full flex items-center gap-1 text-orange-600 border-orange-200 hover:bg-orange-50"
              variant="outline"
            >
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="aspect-square bg-gray-100 rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="Ring Video Doorbell"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">Ring Video Doorbell</h3>
            <p className="text-orange-600 font-medium my-1">$99.99</p>
            <p className="text-sm text-gray-500 mb-4">
              HD video doorbell with motion detection and two-way talk. See, hear, and speak to visitors from your
              phone.
            </p>
            <Button
              className="w-full flex items-center gap-1 text-orange-600 border-orange-200 hover:bg-orange-50"
              variant="outline"
            >
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="aspect-square bg-gray-100 rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="Yale Assure Smart Lock"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">Yale Assure Smart Lock</h3>
            <p className="text-orange-600 font-medium my-1">$249.99</p>
            <p className="text-sm text-gray-500 mb-4">
              Keyless entry smart lock that works with your smartphone. Auto-lock feature and virtual keys for guests.
            </p>
            <Button
              className="w-full flex items-center gap-1 text-orange-600 border-orange-200 hover:bg-orange-50"
              variant="outline"
            >
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>
      </div>

      <p className="text-xs text-gray-500">
        * As an affiliate partner, we may earn a commission from qualifying purchases.
      </p>
    </div>
  )
}

