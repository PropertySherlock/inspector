"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, AlertTriangle, Clock, ArrowLeft, Home, Wrench, Gift } from "lucide-react"
import Link from "next/link"

export default function TaskDetailPage() {
  // In a real app, you would fetch the task details based on the ID
  const taskDetails = {
    title: "Replace your air filter",
    dueDate: "MAR 27",
    difficulty: "Easy",
    duration: "10 minutes",
    description:
      "Regularly replacing your HVAC air filter improves air quality and system efficiency. It's a simple task that can save you money on energy bills and prevent costly repairs.",
    steps: [
      "Turn off your HVAC system",
      "Locate your air filter (usually in the return air duct or at the air handler)",
      "Note the size and direction of airflow on the existing filter",
      "Remove the old filter and dispose of it",
      "Insert the new filter with the arrows pointing in the direction of airflow",
      "Secure the filter compartment cover if applicable",
      "Turn your HVAC system back on",
    ],
    materials: ["New air filter (check size: typically 16×20, 20×25, etc.)", "Optional: vacuum cleaner for dust"],
    tips: [
      "Set a reminder to check your filter every 30-90 days",
      "Consider upgrading to a higher MERV rating for better filtration",
      "If you have pets or allergies, you may need to replace filters more frequently",
    ],
  }

  return (
    <main className="pb-16">
      <div className="bg-gray-50 py-6 border-b">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold">8100 Sky Mountain Ln</h1>
          <p className="text-gray-500">Mountain View, California</p>
        </div>
      </div>

      <div className="container mx-auto py-6 px-4">
        <Link
          href="/inspection/1"
          className="inline-flex items-center text-sm text-gray-500 hover:text-orange-600 mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Inspection Report
        </Link>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">{taskDetails.title}</h1>
            <div className="text-gray-500">Due {taskDetails.dueDate}</div>
          </div>

          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-white">
              {taskDetails.difficulty}
            </Badge>
            <div className="flex items-center gap-1 text-sm text-gray-500">
              <Clock className="h-4 w-4" />
              {taskDetails.duration}
            </div>
          </div>

          <p className="text-gray-500">{taskDetails.description}</p>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-6">
                <div className="space-y-4">
                  <h2 className="text-xl font-semibold">Steps</h2>
                  <ol className="space-y-2 ml-6 list-decimal">
                    {taskDetails.steps.map((step, index) => (
                      <li key={index} className="text-gray-500">
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Materials Needed</h2>
                <ul className="space-y-2 ml-6 list-disc">
                  {taskDetails.materials.map((material, index) => (
                    <li key={index} className="text-gray-500">
                      {material}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Pro Tips</h2>
                <ul className="space-y-2 ml-6 list-disc">
                  {taskDetails.tips.map((tip, index) => (
                    <li key={index} className="text-gray-500">
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          <div className="flex items-center gap-4 pt-4">
            <Button className="flex-1 bg-orange-500 hover:bg-orange-600 text-white">
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Complete
            </Button>
            <Button variant="outline" className="flex-1 text-orange-600 border-orange-200 hover:bg-orange-50">
              Get Professional Help
            </Button>
          </div>

          <Button variant="ghost" className="w-full text-gray-500 hover:text-gray-700">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Not relevant to your home? Remove task
          </Button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2">
        <Link href="/maintenance" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Wrench className="h-6 w-6" />
          <span className="text-xs mt-1">Maintenance</span>
        </Link>
        <Link href="/inspections" className="flex flex-col items-center p-2 text-orange-600">
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Inspections</span>
        </Link>
        <Link href="/offers" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Gift className="h-6 w-6" />
          <span className="text-xs mt-1">Offers</span>
        </Link>
      </div>
    </main>
  )
}

