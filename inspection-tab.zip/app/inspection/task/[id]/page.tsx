"use client"

import { Button } from "@/components/ui/button"
import { ChevronLeft, Clock, Home, Wrench, Gift } from "lucide-react"
import Link from "next/link"

export default function TaskDetailPage({ params }: { params: { id: string } }) {
  // In a real app, you would fetch the task details based on the ID
  const taskDetails = {
    title: "Replace your air filter",
    dueDate: "MAR 27",
    difficulty: "Easy",
    duration: "10 minutes",
    description:
      "Regularly replacing your HVAC air filter improves air quality and system efficiency. It's a simple task that can save you money on energy bills and prevent costly repairs.",
    steps: [
      "Turn off your HVAC system",
      "Locate your air filter (usually in the return air duct or at the air handler)",
      "Note the size and direction of airflow on the existing filter",
      "Remove the old filter and dispose of it",
      "Insert the new filter with the arrows pointing in the direction of airflow",
      "Secure the filter compartment cover if applicable",
      "Turn your HVAC system back on",
    ],
    materials: ["New air filter (check size: typically 16×20, 20×25, etc.)", "Optional: vacuum cleaner for dust"],
    tips: [
      "Set a reminder to check your filter every 30-90 days",
      "Consider upgrading to a higher MERV rating for better filtration",
      "If you have pets or allergies, you may need to replace filters more frequently",
    ],
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-16">
      <div className="bg-gray-50 py-6 border-b">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold">8100 Sky Mountain Ln</h1>
          <p className="text-gray-500">Mountain View, California</p>
        </div>
      </div>

      <div className="container mx-auto py-6 px-4">
        <Link
          href="/inspection/1"
          className="inline-flex items-center text-sm text-gray-600 hover:text-orange-600 mb-6"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Inspection Report
        </Link>

        <div className="bg-white rounded-lg border p-6 space-y-8">
          <div className="flex items-start justify-between">
            <h1 className="text-2xl font-semibold">{taskDetails.title}</h1>
            <div className="text-gray-600">Due {taskDetails.dueDate}</div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-sm bg-gray-100 text-gray-900">
                {taskDetails.difficulty}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-600">{taskDetails.duration}</span>
            </div>
          </div>

          <p className="text-gray-600">{taskDetails.description}</p>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Steps</h2>
            <ol className="list-decimal pl-5 space-y-2">
              {taskDetails.steps.map((step, index) => (
                <li key={index} className="text-gray-600">
                  {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Materials Needed</h2>
            <ul className="list-disc pl-5 space-y-2">
              {taskDetails.materials.map((material, index) => (
                <li key={index} className="text-gray-600">
                  {material}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Pro Tips</h2>
            <ul className="list-disc pl-5 space-y-2">
              {taskDetails.tips.map((tip, index) => (
                <li key={index} className="text-gray-600">
                  {tip}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col gap-3 pt-4">
            <Button size="lg" className="w-full bg-orange-600 hover:bg-orange-700 text-white">
              Mark as Complete
            </Button>
            <Button variant="outline" size="lg" className="w-full border-gray-200">
              Get Professional Help
            </Button>
            <Button variant="ghost" size="lg" className="w-full text-gray-600 hover:text-gray-900">
              Not relevant to your home? Remove task
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2">
        <Link href="/maintenance" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Wrench className="h-6 w-6" />
          <span className="text-xs mt-1">Maintenance</span>
        </Link>
        <Link href="/inspections" className="flex flex-col items-center p-2 text-orange-600">
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Inspections</span>
        </Link>
        <Link href="/offers" className="flex flex-col items-center p-2 text-gray-500 hover:text-orange-600">
          <Gift className="h-6 w-6" />
          <span className="text-xs mt-1">Offers</span>
        </Link>
      </div>
    </main>
  )
}

