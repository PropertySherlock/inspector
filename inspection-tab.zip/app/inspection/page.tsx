"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Clock, Download, ExternalLink, FileText, Share, PenToolIcon as Tool, Wrench } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function InspectionPage() {
  const [activeTab, setActiveTab] = useState("findings")

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Link href="/dashboard" className="text-sm text-muted-foreground hover:underline flex items-center gap-1">
              <ChevronRight className="h-4 w-4 rotate-180" />
              Back to Inspections
            </Link>
          </div>
          <h1 className="text-2xl font-bold mt-2">Inspection Report</h1>
          <p className="text-muted-foreground">8100 Sky Mountain Ln</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Share className="h-4 w-4" />
            Share
          </Button>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Download className="h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Inspection completed on March 5, 2025</CardTitle>
              <CardDescription>
                This report provides a comprehensive assessment of your property's condition, highlighting areas that
                need attention and maintenance recommendations.
              </CardDescription>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Completed
            </Badge>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="findings" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 w-full bg-muted/50">
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="findings">Findings</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance Plan</TabsTrigger>
          <TabsTrigger value="products">Recommended Products</TabsTrigger>
        </TabsList>

        <TabsContent value="summary" className="mt-6">
          <SummaryTab />
        </TabsContent>

        <TabsContent value="findings" className="mt-6">
          <FindingsTab />
        </TabsContent>

        <TabsContent value="maintenance" className="mt-6">
          <MaintenanceTab />
        </TabsContent>

        <TabsContent value="products" className="mt-6">
          <ProductsTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SummaryTab() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Inspection Overview</CardTitle>
          <CardDescription>Overall assessment of your property's condition</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col items-center justify-center p-6 bg-muted/30 rounded-lg">
              <div className="relative w-32 h-32">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-bold">72</span>
                </div>
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="#f97316"
                    strokeWidth="10"
                    strokeDasharray="282.7"
                    strokeDashoffset="79.2"
                  />
                </svg>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Property Score</p>
            </div>
            <div className="flex flex-col p-6 bg-muted/30 rounded-lg">
              <h3 className="font-medium">Issues Found</h3>
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Critical Issues</span>
                  <Badge variant="destructive">1</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Moderate Issues</span>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    2
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Minor Issues</span>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    3
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex flex-col p-6 bg-muted/30 rounded-lg">
              <h3 className="font-medium">Maintenance Tasks</h3>
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Immediate</span>
                  <Badge variant="destructive">2</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Seasonal</span>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    3
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Long-term</span>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    1
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function FindingsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">
          Detailed findings from your home inspection, organized by category.
        </h2>
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            HVAC
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Plumbing
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Appliances
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Electrical System
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Roofing
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Structure & Foundation
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Exterior
          </Badge>
          <Badge variant="outline" className="bg-background cursor-pointer hover:bg-muted">
            Windows & Doors
          </Badge>
        </div>
      </div>

      <Card className="border-red-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Roof</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              Minor Repairs
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Some shingles showing signs of wear. Recommend replacing damaged shingles within the next 3-6 months.
          </p>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Tool className="h-4 w-4" />
            Add to Maintenance Tasks
          </Button>
        </CardContent>
      </Card>

      <Card className="border-green-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Plumbing</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Good Condition
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            All plumbing fixtures and pipes are functioning properly. No leaks detected.
          </p>
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>Electrical</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              Needs Attention
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Outdated electrical panel with potential safety concerns. Recommend consulting with a licensed electrician
            for an upgrade.
          </p>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Tool className="h-4 w-4" />
            Add to Maintenance Tasks
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span>HVAC</span>
              </CardTitle>
            </div>
            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
              Maintenance Required
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Air filter needs replacement. System is functioning but efficiency could be improved with regular
            maintenance.
          </p>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Tool className="h-4 w-4" />
            Add to Maintenance Tasks
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function MaintenanceTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Suggested Maintenance Plan</h2>
        <p className="text-muted-foreground mb-4">
          Based on your inspection results, we recommend the following maintenance plan to keep your home in top
          condition.
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          <Button variant="outline" className="bg-background">
            <Clock className="h-4 w-4 mr-2" />
            Immediate
          </Button>
          <Button variant="outline" className="bg-muted/50">
            Seasonal
          </Button>
          <Button variant="outline" className="bg-muted/50">
            Long-term
          </Button>
        </div>

        <p className="text-sm text-muted-foreground mb-6">
          These items require immediate attention to address safety concerns or prevent further damage.
        </p>
      </div>

      <Card className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2 h-full bg-red-500"></div>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Repair Roof Shingles</CardTitle>
            <Badge className="bg-red-100 text-red-800 hover:bg-red-200">High Priority</Badge>
          </div>
          <CardDescription>
            Replace damaged shingles in the northwest corner of the roof to prevent water intrusion.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              View Details
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Wrench className="h-4 w-4" />
              Recommended Service Providers
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2 h-full bg-red-500"></div>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Install GFCI Outlets in Bathroom</CardTitle>
            <Badge className="bg-red-100 text-red-800 hover:bg-red-200">High Priority</Badge>
          </div>
          <CardDescription>
            Replace standard outlets with GFCI outlets in all bathrooms to improve electrical safety.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              View Details
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Wrench className="h-4 w-4" />
              Recommended Service Providers
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2 h-full bg-amber-500"></div>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Replace Air Filter</CardTitle>
            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-200">Medium Priority</Badge>
          </div>
          <CardDescription>Replace HVAC air filter to improve air quality and system efficiency.</CardDescription>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-background">
                Easy
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">10 minutes</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Due: Mar 27</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              View Details
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Wrench className="h-4 w-4" />
              Get Help
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ProductsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Recommended Products</h2>
        <p className="text-muted-foreground mb-6">
          Based on your inspection results, we recommend these products to improve your home.
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          <Button variant="outline" className="bg-background">
            Security
          </Button>
          <Button variant="outline" className="bg-muted/50">
            Maintenance
          </Button>
          <Button variant="outline" className="bg-muted/50">
            Improvement
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-0 relative">
            <Badge className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600">Recommended</Badge>
            <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="SimpliSafe Home Security System"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">SimpliSafe Home Security System</h3>
            <p className="text-orange-600 font-medium my-1">$279.99</p>
            <p className="text-sm text-muted-foreground mb-4">
              Complete wireless home security system with professional monitoring. Easy to install and no long-term
              contracts.
            </p>
            <Button className="w-full flex items-center gap-1" variant="outline">
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="Ring Video Doorbell"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">Ring Video Doorbell</h3>
            <p className="text-orange-600 font-medium my-1">$99.99</p>
            <p className="text-sm text-muted-foreground mb-4">
              HD video doorbell with motion detection and two-way talk. See, hear, and speak to visitors from your
              phone.
            </p>
            <Button className="w-full flex items-center gap-1" variant="outline">
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="Yale Assure Smart Lock"
                width={200}
                height={200}
                className="object-contain"
              />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">Yale Assure Smart Lock</h3>
            <p className="text-orange-600 font-medium my-1">$249.99</p>
            <p className="text-sm text-muted-foreground mb-4">
              Keyless entry smart lock that works with your smartphone. Auto-lock feature and virtual keys for guests.
            </p>
            <Button className="w-full flex items-center gap-1" variant="outline">
              <ExternalLink className="h-4 w-4" />
              View Deal
            </Button>
          </CardContent>
        </Card>
      </div>

      <p className="text-xs text-muted-foreground">
        * As an affiliate partner, we may earn a commission from qualifying purchases.
      </p>
    </div>
  )
}

