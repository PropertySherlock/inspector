import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, PenToolIcon as Tool, CheckCircle, AlertTriangle } from "lucide-react"

interface TaskDetailProps {
  title: string
  dueDate: string
  difficulty: "Easy" | "Medium" | "Hard"
  duration: string
  description: string
  steps: string[]
  materials: string[]
  tips: string[]
}

export function TaskDetail({
  title,
  dueDate,
  difficulty,
  duration,
  description,
  steps,
  materials,
  tips,
}: TaskDetailProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{title}</h1>
        <div className="text-muted-foreground">Due {dueDate}</div>
      </div>

      <div className="flex items-center gap-4">
        <Badge variant="outline" className="bg-background">
          {difficulty}
        </Badge>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          {duration}
        </div>
      </div>

      <p className="text-muted-foreground">{description}</p>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Steps</h2>
        <ol className="space-y-2 ml-6 list-decimal">
          {steps.map((step, index) => (
            <li key={index} className="text-muted-foreground">
              {step}
            </li>
          ))}
        </ol>
      </div>

      <div className="space-y-4">
        <h2 className="flex items-center gap-2 text-xl font-semibold">
          <Tool className="h-5 w-5" />
          Materials Needed
        </h2>
        <ul className="space-y-2 ml-6 list-disc">
          {materials.map((material, index) => (
            <li key={index} className="text-muted-foreground">
              {material}
            </li>
          ))}
        </ul>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Pro Tips</h2>
        <ul className="space-y-2 ml-6 list-disc">
          {tips.map((tip, index) => (
            <li key={index} className="text-muted-foreground">
              {tip}
            </li>
          ))}
        </ul>
      </div>

      <div className="flex items-center gap-4 pt-4">
        <Button className="flex-1">
          <CheckCircle className="h-4 w-4 mr-2" />
          Mark as Complete
        </Button>
        <Button variant="outline" className="flex-1">
          <Tool className="h-4 w-4 mr-2" />
          Get Professional Help
        </Button>
      </div>

      <Button variant="ghost" className="w-full text-muted-foreground">
        <AlertTriangle className="h-4 w-4 mr-2" />
        Not relevant to your home? Remove task
      </Button>
    </div>
  )
}

