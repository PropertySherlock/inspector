import { FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface InspectionCardProps {
  address: string
  date: string
  status: "Completed" | "In Progress" | "Scheduled"
  id: string
}

export function InspectionCard({ address, date, status, id }: InspectionCardProps) {
  return (
    <div className="bg-white rounded-lg border p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div>
        <h3 className="font-bold text-lg">{address}</h3>
        <div className="flex items-center gap-2 mt-1">
          <p className="text-sm text-gray-500">Inspection on {date}</p>
          <Badge
            variant="outline"
            className={`
              ${status === "Completed" ? "bg-green-50 text-green-700 border-green-200" : ""}
              ${status === "In Progress" ? "bg-blue-50 text-blue-700 border-blue-200" : ""}
              ${status === "Scheduled" ? "bg-amber-50 text-amber-700 border-amber-200" : ""}
            `}
          >
            {status}
          </Badge>
        </div>
      </div>
      <Button
        variant="outline"
        className="text-orange-600 border-orange-200 hover:bg-orange-50 hover:text-orange-700"
        asChild
      >
        <a href={`/inspection/${id}`}>
          <FileText className="h-4 w-4 mr-2" />
          View Report
        </a>
      </Button>
    </div>
  )
}

