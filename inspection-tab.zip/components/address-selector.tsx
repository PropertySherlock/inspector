"use client"

import * as React from "react"
import { ChevronDown, ChevronUp, Home, Plus } from "lucide-react"

interface Property {
  id: string
  address: string
  city: string
  state: string
}

export function AddressSelector() {
  const [open, setOpen] = React.useState(false)
  const [selectedProperty, setSelectedProperty] = React.useState<Property>({
    id: "1",
    address: "39600 Fremont Blvd",
    city: "Fremont",
    state: "California",
  })

  const properties: Property[] = [
    {
      id: "1",
      address: "39600 Fremont Blvd",
      city: "Fremont",
      state: "California",
    },
    {
      id: "2",
      address: "456 Park Ave",
      city: "Springfield",
      state: "IL",
    },
  ]

  const dropdownRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleAddProperty = () => {
    console.log("Add new property")
    // In a real app, this would navigate to a form or open a dialog
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="text-left flex items-center justify-between px-0 py-3 text-xl font-semibold"
      >
        {`${selectedProperty.address}, ${selectedProperty.city}, ${selectedProperty.state}`}
        {open ? <ChevronUp className="h-5 w-5 ml-2" /> : <ChevronDown className="h-5 w-5 ml-2" />}
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 p-0 bg-white rounded-lg shadow-lg z-10 border border-gray-200">
          {properties.map((property) => (
            <div
              key={property.id}
              className="flex items-center px-6 py-4 hover:bg-gray-50 cursor-pointer"
              onClick={() => {
                setSelectedProperty(property)
                setOpen(false)
              }}
            >
              <Home className="h-5 w-5 text-gray-500 mr-4 flex-shrink-0" />
              <span className="font-medium">{`${property.address}, ${property.city}, ${property.state}`}</span>
            </div>
          ))}
          <div
            className="flex items-center px-6 py-4 text-orange-500 hover:bg-gray-50 cursor-pointer"
            onClick={handleAddProperty}
          >
            <Plus className="h-5 w-5 mr-4 flex-shrink-0" />
            <span className="font-medium">Add New Property</span>
          </div>
        </div>
      )}
    </div>
  )
}

