/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "#E86C3A", // Coral orange
          foreground: "#FFFFFF",
          light: "#F17D4B", // Lighter coral
          dark: "#D55B29", // Darker coral
        },
        secondary: {
          DEFAULT: "#FDF7F4", // Light peach background
          foreground: "#666666", // Gray text
        },
        success: {
          DEFAULT: "#2D9D3C", // Success green
          light: "#E8F5E9",
          foreground: "#FFFFFF",
        },
        warning: {
          DEFAULT: "#E86C3A", // Warning orange (same as primary)
          light: "#FFF3E0",
          foreground: "#FFFFFF",
        },
        danger: {
          DEFAULT: "#DC3545", // Danger red
          light: "#FEEBEE",
          foreground: "#FFFFFF",
        },
        muted: {
          DEFAULT: "#F5F5F5",
          foreground: "#666666",
        },
        accent: {
          DEFAULT: "#FDF7F4",
          foreground: "#E86C3A",
        },
      },
      borderRadius: {
        lg: "0.625rem", // 10px
        md: "0.5rem", // 8px
        sm: "0.25rem", // 4px
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

