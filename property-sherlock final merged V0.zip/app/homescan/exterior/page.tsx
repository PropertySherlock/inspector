"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ChevronRight, Info } from "lucide-react"
import type { ConditionRating } from "@/types/homescan"
import { PhotoUploader } from "@/components/homescan/photo-uploader"

export default function ExteriorPage() {
  const router = useRouter()
  const [roofCondition, setRoofCondition] = useState<ConditionRating>("good")
  const [roofNotes, setRoofNotes] = useState("")
  const [wallMaterial, setWallMaterial] = useState("")
  const [wallNotes, setWallNotes] = useState("")
  const [hasLeaks, setHasLeaks] = useState<boolean | null>(null)

  const conditionOptions = [
    { value: "excellent", label: "Excellent", description: "Like new, no visible issues" },
    { value: "good", label: "Good", description: "Minor wear, no apparent issues" },
    { value: "fair", label: "Fair", description: "Some visible wear, may need attention soon" },
    { value: "poor", label: "Poor", description: "Significant wear or damage, needs attention" },
  ]

  return (
    <div className="space-y-8">
      {/* Roof Condition Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Roof Condition</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* Roof Condition Question */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium">What is the overall condition of your roof?</h3>
              <button title="Learn more about roof conditions" className="text-gray-400 hover:text-gray-600">
                <Info className="h-4 w-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {conditionOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={`relative p-4 rounded-lg text-left transition-all ${
                    roofCondition === option.value
                      ? "bg-primary/5 border-2 border-primary"
                      : "bg-white border border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setRoofCondition(option.value as ConditionRating)}
                >
                  <div className="font-medium mb-1">{option.label}</div>
                  <div className="text-sm text-gray-600">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Water Damage Question */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Have you noticed any leaks or water damage?</h3>
            <div className="flex gap-4">
              <button
                type="button"
                className={`px-5 py-3 rounded-lg transition-all border ${
                  hasLeaks === true
                    ? "bg-primary/5 border-primary font-medium text-primary"
                    : "bg-white border-gray-200 hover:border-gray-300 text-gray-700"
                }`}
                onClick={() => setHasLeaks(true)}
              >
                Yes
              </button>
              <button
                type="button"
                className={`px-5 py-3 rounded-lg transition-all border ${
                  hasLeaks === false
                    ? "bg-primary/5 border-primary font-medium text-primary"
                    : "bg-white border-gray-200 hover:border-gray-300 text-gray-700"
                }`}
                onClick={() => setHasLeaks(false)}
              >
                No
              </button>
            </div>
          </div>

          {/* Additional Notes */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Additional notes about your roof</h3>
            <Textarea
              placeholder="Enter any additional information about your roof..."
              value={roofNotes}
              onChange={(e) => setRoofNotes(e.target.value)}
              className="min-h-[120px] bg-white"
            />
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your roof</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Siding & Exterior Walls Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Siding & Exterior Walls</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* Wall Material Question */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">What material is your siding made of?</h3>
            <Input
              placeholder="e.g., vinyl, wood, brick, stucco"
              value={wallMaterial}
              onChange={(e) => setWallMaterial(e.target.value)}
              className="max-w-md bg-white"
            />
          </div>

          {/* Additional Notes */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Additional notes about your exterior walls</h3>
            <Textarea
              placeholder="Enter any additional information about your exterior walls..."
              value={wallNotes}
              onChange={(e) => setWallNotes(e.target.value)}
              className="min-h-[120px] bg-white"
            />
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your exterior walls</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Navigation Button */}
      <div className="flex justify-end mt-8">
        <Button
          onClick={() => router.push("/homescan/interior")}
          className="group bg-primary hover:bg-primary-dark text-white"
        >
          Next: Interior
          <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </div>
    </div>
  )
}

