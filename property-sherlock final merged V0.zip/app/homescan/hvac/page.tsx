"use client"

import { useState } from "react"
import { Section } from "@/components/homescan/section"
import { InfoCard } from "@/components/homescan/info-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { PhotoUploader } from "@/components/homescan/photo-uploader"

export default function HVACPage() {
  const [isEditing, setIsEditing] = useState(false)
  const [systemType, setSystemType] = useState("")
  const [age, setAge] = useState("")
  const [notes, setNotes] = useState("")

  return (
    <Section title="HVAC System">
      <InfoCard
        title="Basic Information"
        description="Enter the basic details about your HVAC system"
        onEdit={() => setIsEditing(true)}
      >
        {isEditing ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">System Type</label>
              <Input
                placeholder="e.g., Central AC with Gas Furnace"
                value={systemType}
                onChange={(e) => setSystemType(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">System Age</label>
              <Input placeholder="e.g., 5 years" value={age} onChange={(e) => setAge(e.target.value)} />
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsEditing(false)}>Save Changes</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {!systemType && !age ? (
              <p className="text-gray-500 text-sm">Click the edit button to add basic information</p>
            ) : (
              <>
                {systemType && (
                  <div>
                    <span className="text-sm text-gray-500">System Type:</span>
                    <p>{systemType}</p>
                  </div>
                )}
                {age && (
                  <div>
                    <span className="text-sm text-gray-500">System Age:</span>
                    <p>{age}</p>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </InfoCard>

      <InfoCard title="Detailed Information" description="Add notes and photos to document your HVAC system">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Notes</label>
            <Textarea
              placeholder="Enter any additional information..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="min-h-[100px]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Photos</label>
            <PhotoUploader />
          </div>

          <Button className="w-full">Save Changes</Button>
        </div>
      </InfoCard>
    </Section>
  )
}

