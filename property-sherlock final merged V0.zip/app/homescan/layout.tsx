"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { getHomeScanData, saveHomeScanProgress } from "@/lib/api"
import type { HomeScanData } from "@/types/homescan"
import Link from "next/link"
import { ArrowLeft, CheckCircle2, ChevronRight } from "lucide-react"
import { toast } from "@/components/ui/toast"
import { HireInspectorButton } from "@/components/hire-inspector-button"

export default function HomeScanLayout({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<HomeScanData | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [completing, setCompleting] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    async function fetchData() {
      try {
        const homeScanData = await getHomeScanData()
        setData(homeScanData)
      } catch (error) {
        console.error("Failed to fetch HomeScan data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleSaveProgress = async () => {
    if (!data) return

    setSaving(true)
    try {
      const currentSection = pathname.split("/").pop() || ""
      await saveHomeScanProgress({
        sectionId: currentSection,
        action: "save",
        formData: {},
      })

      toast({
        title: "Progress saved",
        description: "Your HomeScan progress has been saved successfully.",
      })

      const updatedData = await getHomeScanData()
      setData(updatedData)
    } catch (error) {
      console.error("Failed to save progress:", error)
      toast({
        title: "Error saving progress",
        description: "There was a problem saving your progress. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleCompleteHomeScan = async () => {
    if (!data) return

    setCompleting(true)
    try {
      await saveHomeScanProgress({
        action: "complete",
        formData: {},
      })

      toast({
        title: "HomeScan completed",
        description: "Your HomeScan has been completed successfully.",
      })

      router.push("/dashboard")
    } catch (error) {
      console.error("Failed to complete HomeScan:", error)
      toast({
        title: "Error completing HomeScan",
        description: "There was a problem completing your HomeScan. Please try again.",
        variant: "destructive",
      })
    } finally {
      setCompleting(false)
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (!data) {
    return <div className="min-h-screen flex items-center justify-center">Failed to load HomeScan data</div>
  }

  const currentSection = pathname.split("/").pop() || ""

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center mb-4">
            <Link href="/dashboard" className="flex items-center text-gray-600 hover:text-gray-900">
              <ArrowLeft className="h-5 w-5 mr-2" />
              <span className="font-medium">Back to Dashboard</span>
            </Link>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold">HomeScan</h1>
              <p className="text-gray-600">Document your home's condition</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-sm font-medium text-gray-700">{data.progress}% Complete</div>
              <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${data.progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b shadow-sm">
        <div className="container max-w-5xl mx-auto">
          <div className="flex">
            {["exterior", "interior", "systems"].map((section) => (
              <Link
                key={section}
                href={`/homescan/${section}`}
                className={`px-6 py-4 text-center capitalize font-medium transition-colors ${
                  currentSection === section
                    ? "text-primary border-b-2 border-primary"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                }`}
              >
                {section}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container max-w-5xl mx-auto px-4 py-8">
        {children}

        {/* Action Buttons */}
        <div className="mt-12 flex flex-col sm:flex-row gap-4 justify-end">
          <Button variant="outline" onClick={handleSaveProgress} disabled={saving} className="order-2 sm:order-1">
            {saving ? "Saving..." : "Save Progress"}
          </Button>
          <Button
            onClick={handleCompleteHomeScan}
            disabled={completing}
            className="bg-primary hover:bg-primary-dark text-white order-1 sm:order-2"
          >
            {completing ? (
              "Completing..."
            ) : (
              <span className="flex items-center">
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Complete HomeScan
              </span>
            )}
          </Button>
        </div>
      </main>

      {/* Hire Inspector CTA */}
      <div className="fixed bottom-8 right-8 z-50">
        <HireInspectorButton
          className="shadow-lg rounded-full px-6 py-6 bg-white text-primary border-2 border-primary/20 hover:bg-primary/5"
          variant="ghost"
          size="lg"
        >
          <span className="font-semibold">Hire a Professional Inspector</span>
          <ChevronRight className="ml-2 h-5 w-5" />
        </HireInspectorButton>
      </div>
    </div>
  )
}

