"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowLeft, CheckCircle2, Info } from "lucide-react"
import type { ConditionRating } from "@/types/homescan"
import { PhotoUploader } from "@/components/homescan/photo-uploader"

export default function SystemsPage() {
  const router = useRouter()
  const [hvacCondition, setHvacCondition] = useState<ConditionRating>("good")
  const [hvacType, setHvacType] = useState("")
  const [hvacAge, setHvacAge] = useState("")
  const [hasPlumbingLeaks, setHasPlumbingLeaks] = useState<boolean | null>(null)
  const [waterHeaterAge, setWaterHeaterAge] = useState("")
  const [systemsNotes, setSystemsNotes] = useState("")

  const conditionOptions = [
    { value: "excellent", label: "Excellent", description: "Like new, no visible issues" },
    { value: "good", label: "Good", description: "Minor wear, no apparent issues" },
    { value: "fair", label: "Fair", description: "Some visible wear, may need attention soon" },
    { value: "poor", label: "Poor", description: "Significant wear or damage, needs attention" },
  ]

  const handleComplete = () => {
    // In a real app, you would save the data here
    router.push("/dashboard")
  }

  return (
    <div className="space-y-8">
      {/* HVAC System Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">HVAC System</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* HVAC Type */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">What type of HVAC system do you have?</h3>
            <Input
              placeholder="e.g., central air, heat pump, furnace"
              value={hvacType}
              onChange={(e) => setHvacType(e.target.value)}
              className="max-w-md bg-white"
            />
          </div>

          {/* HVAC Age */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">How old is your HVAC system?</h3>
            <Input
              placeholder="e.g., 5 years"
              value={hvacAge}
              onChange={(e) => setHvacAge(e.target.value)}
              className="max-w-md bg-white"
            />
          </div>

          {/* HVAC Condition */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium">What is the overall condition of your HVAC system?</h3>
              <button title="Learn more about HVAC conditions" className="text-gray-400 hover:text-gray-600">
                <Info className="h-4 w-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {conditionOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={`relative p-4 rounded-lg text-left transition-all ${
                    hvacCondition === option.value
                      ? "bg-primary/5 border-2 border-primary"
                      : "bg-white border border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setHvacCondition(option.value as ConditionRating)}
                >
                  <div className="font-medium mb-1">{option.label}</div>
                  <div className="text-sm text-gray-600">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your HVAC system</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Plumbing System Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Plumbing System</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* Plumbing Leaks */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Have you noticed any leaks in your plumbing?</h3>
            <div className="flex gap-4">
              <button
                type="button"
                className={`px-5 py-3 rounded-lg transition-all border ${
                  hasPlumbingLeaks === true
                    ? "bg-primary/5 border-primary font-medium text-primary"
                    : "bg-white border-gray-200 hover:border-gray-300 text-gray-700"
                }`}
                onClick={() => setHasPlumbingLeaks(true)}
              >
                Yes
              </button>
              <button
                type="button"
                className={`px-5 py-3 rounded-lg transition-all border ${
                  hasPlumbingLeaks === false
                    ? "bg-primary/5 border-primary font-medium text-primary"
                    : "bg-white border-gray-200 hover:border-gray-300 text-gray-700"
                }`}
                onClick={() => setHasPlumbingLeaks(false)}
              >
                No
              </button>
            </div>
          </div>

          {/* Water Heater Age */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">How old is your water heater?</h3>
            <Input
              placeholder="e.g., 3 years"
              value={waterHeaterAge}
              onChange={(e) => setWaterHeaterAge(e.target.value)}
              className="max-w-md bg-white"
            />
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your plumbing system or water heater</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Additional Information Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Additional Information</h2>
        </div>

        <div className="p-6 space-y-6">
          {/* Additional Notes */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Additional notes about your home systems</h3>
            <Textarea
              placeholder="Enter any additional information about your home systems..."
              value={systemsNotes}
              onChange={(e) => setSystemsNotes(e.target.value)}
              className="min-h-[120px] bg-white"
            />
          </div>
        </div>
      </section>

      {/* Navigation Buttons */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={() => router.push("/homescan/interior")} className="group">
          <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
          Back: Interior
        </Button>
        <Button onClick={handleComplete} className="group bg-primary hover:bg-primary-dark text-white">
          <CheckCircle2 className="mr-2 h-4 w-4" />
          Complete HomeScan
        </Button>
      </div>
    </div>
  )
}

