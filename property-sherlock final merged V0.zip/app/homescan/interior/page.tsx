"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowLeft, ChevronRight, Info } from "lucide-react"
import type { ConditionRating } from "@/types/homescan"
import { PhotoUploader } from "@/components/homescan/photo-uploader"

export default function InteriorPage() {
  const router = useRouter()
  const [livingRoomCondition, setLivingRoomCondition] = useState<ConditionRating>("good")
  const [kitchenCondition, setKitchenCondition] = useState<ConditionRating>("good")
  const [floorType, setFloorType] = useState("")
  const [interiorNotes, setInteriorNotes] = useState("")

  const conditionOptions = [
    { value: "excellent", label: "Excellent", description: "Like new, no visible issues" },
    { value: "good", label: "Good", description: "Minor wear, no apparent issues" },
    { value: "fair", label: "Fair", description: "Some visible wear, may need attention soon" },
    { value: "poor", label: "Poor", description: "Significant wear or damage, needs attention" },
  ]

  return (
    <div className="space-y-8">
      {/* Living Areas Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Living Areas</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* Living Room Condition */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium">What is the overall condition of your living room?</h3>
              <button title="Learn more about living room conditions" className="text-gray-400 hover:text-gray-600">
                <Info className="h-4 w-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {conditionOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={`relative p-4 rounded-lg text-left transition-all ${
                    livingRoomCondition === option.value
                      ? "bg-primary/5 border-2 border-primary"
                      : "bg-white border border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setLivingRoomCondition(option.value as ConditionRating)}
                >
                  <div className="font-medium mb-1">{option.label}</div>
                  <div className="text-sm text-gray-600">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Flooring Type */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">What type of flooring do you have?</h3>
            <Input
              placeholder="e.g., hardwood, carpet, tile, laminate"
              value={floorType}
              onChange={(e) => setFloorType(e.target.value)}
              className="max-w-md bg-white"
            />
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your living areas</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Kitchen Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Kitchen</h2>
        </div>

        <div className="p-6 space-y-8">
          {/* Kitchen Condition */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium">What is the overall condition of your kitchen?</h3>
              <button title="Learn more about kitchen conditions" className="text-gray-400 hover:text-gray-600">
                <Info className="h-4 w-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {conditionOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={`relative p-4 rounded-lg text-left transition-all ${
                    kitchenCondition === option.value
                      ? "bg-primary/5 border-2 border-primary"
                      : "bg-white border border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setKitchenCondition(option.value as ConditionRating)}
                >
                  <div className="font-medium mb-1">{option.label}</div>
                  <div className="text-sm text-gray-600">{option.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Photos Upload */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Upload photos of your kitchen</h3>
            <PhotoUploader />
          </div>
        </div>
      </section>

      {/* Additional Information Section */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="border-b px-6 py-4 bg-gray-50">
          <h2 className="text-xl font-bold">Additional Information</h2>
        </div>

        <div className="p-6 space-y-6">
          {/* Additional Notes */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Additional notes about your interior</h3>
            <Textarea
              placeholder="Enter any additional information about your home's interior..."
              value={interiorNotes}
              onChange={(e) => setInteriorNotes(e.target.value)}
              className="min-h-[120px] bg-white"
            />
          </div>
        </div>
      </section>

      {/* Navigation Buttons */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={() => router.push("/homescan/exterior")} className="group">
          <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
          Back: Exterior
        </Button>
        <Button
          onClick={() => router.push("/homescan/systems")}
          className="group bg-primary hover:bg-primary-dark text-white"
        >
          Next: Systems
          <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </div>
    </div>
  )
}

