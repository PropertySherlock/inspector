import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft } from "lucide-react"

export default function ScheduleInspectionLoading() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="container mx-auto px-4 pt-4">
          <div className="mb-4 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2 text-gray-400" />
            <Skeleton className="h-5 w-32" />
          </div>

          <div className="mb-8">
            <Skeleton className="h-10 w-full max-w-md" />
          </div>

          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-64 mb-2" />
              <Skeleton className="h-4 w-full max-w-md" />
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center">
                  <Skeleton className="h-4 w-4 mr-2" />
                  <Skeleton className="h-5 w-32" />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                  {Array.from({ length: 7 }).map((_, index) => (
                    <Skeleton key={index} className="h-16 w-full rounded-md" />
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center">
                  <Skeleton className="h-4 w-4 mr-2" />
                  <Skeleton className="h-5 w-32" />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {Array.from({ length: 4 }).map((_, index) => (
                    <Skeleton key={index} className="h-12 w-full rounded-md" />
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Skeleton className="h-5 w-40" />
                <Skeleton className="h-24 w-full rounded-md" />
              </div>

              <Skeleton className="h-11 w-full" />
            </CardContent>
          </Card>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

