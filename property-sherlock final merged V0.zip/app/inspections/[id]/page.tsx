"use client"

import { useEffect, useState } from "react"
import { Navigation } from "@/components/dashboard/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check, Users, ChevronRight, Share2, Download } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function InspectionPage({ params }: { params: { id: string } }) {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the findings tab by default
    router.push(`/inspections/${params.id}/findings/roofing`)
  }, [params.id, router])

  return null
}

function InspectionDetailPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState<"findings" | "maintenance" | "products">("findings")
  const inspectionId = params.id
  const router = useRouter()

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="bg-white border-b">
          <div className="container max-w-5xl mx-auto px-4 py-6">
            <h1 className="text-2xl font-bold">8100 Sky Mountain Ln</h1>
            <p className="text-gray-600">Mountain View, California</p>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                <span className="text-green-600 font-medium">Completed</span>
              </div>
              <p className="text-sm text-gray-600">Inspection completed on March 5, 2025</p>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-2">
          <Link href="/inspections" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Inspections
          </Link>
        </div>

        <div className="container mx-auto px-4 py-4">
          {/* Update the button styling and spacing in the header section */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <h2 className="text-xl font-bold">Inspection Report</h2>
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
              <Button
                className="w-full sm:w-auto bg-[#E86C3A] hover:bg-[#D55B29] text-white h-11 px-6 text-base font-medium"
                onClick={() => router.push(`/inspections/schedule?followUp=true&inspectionId=${inspectionId}`)}
              >
                Schedule Follow-up
              </Button>
              <div className="flex items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                <Button
                  variant="outline"
                  className="flex-1 sm:flex-none border-gray-300"
                  onClick={() => {
                    // In a real app, this would open a share dialog
                    alert("Share functionality would open here")
                  }}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 sm:flex-none border-gray-300"
                  onClick={() => {
                    // In a real app, this would trigger a download
                    alert("Download functionality would trigger here")
                  }}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex border rounded-lg overflow-hidden mb-6">
            <Link
              href={`/inspections/${params.id}/findings/roofing`}
              className={`flex-1 py-3 px-4 text-center transition-colors ${
                activeTab === "findings"
                  ? "bg-white border-b-2 border-[#E86C3A] font-medium text-gray-900"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
              }`}
            >
              Findings
            </Link>
            <Link
              href={`/inspections/${params.id}/maintenance`}
              className={`flex-1 py-3 px-4 text-center transition-colors ${
                activeTab === "maintenance"
                  ? "bg-white border-b-2 border-[#E86C3A] font-medium text-gray-900"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
              }`}
            >
              Maintenance Plan
            </Link>
            <Link
              href={`/inspections/${params.id}/products`}
              className={`flex-1 py-3 px-4 text-center transition-colors ${
                activeTab === "products"
                  ? "bg-white border-b-2 border-[#E86C3A] font-medium text-gray-900"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
              }`}
            >
              Recommended Products
            </Link>
          </div>

          {/* Tab Content */}
          {activeTab === "findings" && <FindingsTab params={params} />}
          {activeTab === "maintenance" && <MaintenancePlanTab />}
          {activeTab === "products" && <RecommendedProductsTab />}
        </div>
      </main>

      <Navigation />
    </div>
  )
}

function FindingsTab({ params }: { params: { id: string } }) {
  const [activeCategory, setActiveCategory] = useState("roofing")

  return (
    <div>
      <h3 className="text-lg font-medium mb-4">Detailed findings from your home inspection, organized by category.</h3>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2 mb-6 overflow-x-auto pb-2">
        {[
          "hvac",
          "plumbing",
          "appliances",
          "electrical-system",
          "roofing",
          "structure-foundation",
          "exterior",
          "windows-doors",
        ].map((category) => {
          const isActive = category === activeCategory
          const displayName = category
            .split("-")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" & ")

          return (
            <Link
              key={category}
              href={`/inspections/${params.id}/findings/${category}`}
              className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-colors ${
                isActive ? "bg-[#E86C3A] text-white" : "bg-white border hover:bg-gray-50"
              }`}
            >
              {displayName}
            </Link>
          )
        })}
      </div>

      {/* Roof Section */}
      <div className="bg-white border rounded-lg mb-6 overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-xl font-semibold">Roof</h3>
          <span className="text-warning bg-warning-light px-3 py-1 rounded-md text-sm font-medium">Minor Repairs</span>
        </div>
        <div className="p-4">
          <p className="mb-4">
            Some shingles showing signs of wear and potential damage in the northwest corner of the roof. Visual
            inspection revealed curling, cracking, and a few missing granules on approximately 15% of the visible
            shingles.
          </p>

          {/* Image placeholders */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
              <img src="/placeholder.svg?height=200&width=300" alt="Roof inspection" className="max-h-full" />
            </div>
            <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
              <img src="/placeholder.svg?height=200&width=300" alt="Roof inspection" className="max-h-full" />
            </div>
          </div>

          <div className="mb-6">
            <h4 className="font-semibold mb-2">Inspector's Notes</h4>
            <p className="text-gray-700">
              The affected shingles are primarily on the northwest slope. While not an immediate concern for leaks,
              these should be addressed within 3-6 months to prevent water intrusion and more extensive damage. The
              flashing around the chimney appears to be in good condition.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 space-y-2">
              <li>Replace damaged shingles within 3-6 months</li>
              <li>Consider a full roof inspection if you notice any interior water stains</li>
              <li>Clean gutters to ensure proper drainage</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Plumbing Section */}
      <div className="bg-white border rounded-lg mb-6 overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-xl font-semibold">Plumbing</h3>
          <span className="text-success bg-success-light px-3 py-1 rounded-md text-sm font-medium">Good Condition</span>
        </div>
        <div className="p-4">
          <p className="mb-4">
            All plumbing fixtures and pipes are functioning properly. Water pressure is within normal range at all
            fixtures. No leaks detected in visible plumbing lines or under sinks.
          </p>

          {/* Image placeholder */}
          <div className="aspect-video bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
            <img src="/placeholder.svg?height=300&width=600" alt="Plumbing inspection" className="max-h-full" />
          </div>

          <div className="mb-6">
            <h4 className="font-semibold mb-2">Inspector's Notes</h4>
            <p className="text-gray-700">
              Water heater is approximately 5 years old and functioning properly. Main water shut-off valve is
              accessible and operational. Drainage appears adequate with no signs of backup in any fixtures.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 space-y-2">
              <li>Continue regular maintenance checks</li>
              <li>Consider installing water leak detectors under sinks as a preventative measure</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

function MaintenancePlanTab() {
  const [tasks, setTasks] = useState([
    {
      id: "1",
      dueDate: "MAR 27",
      title: "Replace your air filter",
      difficulty: "Easy",
      duration: "10 minutes",
      completed: false,
    },
    {
      id: "2",
      dueDate: "MAR 29",
      title: "Clean your cooktop",
      difficulty: "Easy",
      duration: "15 minutes",
      completed: false,
    },
    {
      id: "3",
      dueDate: "MAR 30",
      title: "Test smoke detectors",
      difficulty: "Easy",
      duration: "5 minutes",
      completed: false,
    },
  ])

  const toggleTaskCompletion = (taskId: string) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
  }

  return (
    <div>
      <h3 className="text-xl font-bold mb-3">To-do's</h3>
      <div className="space-y-3">
        {tasks.map((task) => (
          <div
            key={task.id}
            className={`border rounded-lg bg-white hover:shadow-md transition-shadow ${task.completed ? "bg-gray-50 border-gray-200" : ""}`}
          >
            <div className="p-3 sm:p-4">
              <div className="flex items-start">
                <button
                  onClick={() => toggleTaskCompletion(task.id)}
                  className={`mt-1 mr-3 flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 rounded-full border ${
                    task.completed
                      ? "bg-[#E86C3A] border-[#E86C3A] text-white flex items-center justify-center"
                      : "border-gray-300"
                  }`}
                  aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
                >
                  {task.completed && <Check className="h-3 w-3 sm:h-4 sm:w-4" />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-xs sm:text-sm text-gray-500 mb-1">
                    <span>DUE {task.dueDate}</span>
                  </div>
                  <h3
                    className={`text-base sm:text-lg font-semibold mb-2 ${task.completed ? "line-through text-gray-500" : ""} truncate`}
                  >
                    {task.title}
                  </h3>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap gap-2 mb-2 sm:mb-0">
                      <span className="bg-gray-200 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                        {task.difficulty}
                      </span>
                      <span className="bg-gray-200 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                        {task.duration}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-3 w-full sm:w-auto">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center text-[#E86C3A] border-[#E86C3A] text-xs sm:text-sm flex-1 sm:flex-none justify-center sm:justify-start"
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Get Help
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#E86C3A] text-xs sm:text-sm flex-1 sm:flex-none justify-center sm:justify-start"
                        asChild
                      >
                        <Link href={`/tasks/${task.id}`} className="flex items-center">
                          Details
                          <ChevronRight className="h-4 w-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function RecommendedProductsTab() {
  return (
    <div>
      <p className="text-gray-700 mb-6">
        Based on your inspection results, we recommend these products to improve your home.
      </p>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Product 1 */}
        <div className="border rounded-lg overflow-hidden bg-white">
          <div className="relative">
            <div className="aspect-square bg-gray-100 flex items-center justify-center">
              <img
                src="/placeholder.svg?height=200&width=200"
                alt="SimpliSafe Home Security System"
                className="max-h-full"
              />
            </div>
            <div className="absolute top-2 right-2 bg-[#E86C3A] text-white text-xs px-2 py-1 rounded">Recommended</div>
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-lg mb-1">SimpliSafe Home Security System</h3>
            <p className="text-[#E86C3A] font-bold mb-2">$279.99</p>
            <p className="text-sm text-gray-600 mb-4">
              Complete wireless home security system with professional monitoring. Easy to install and no long-term
              contracts.
            </p>
            <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
              <span className="mr-1">View Deal</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-external-link"
              >
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" x2="21" y1="14" y2="3" />
              </svg>
            </Button>
          </div>
        </div>

        {/* Product 2 */}
        <div className="border rounded-lg overflow-hidden bg-white">
          <div className="aspect-square bg-gray-100 flex items-center justify-center">
            <img src="/placeholder.svg?height=200&width=200" alt="Ring Video Doorbell" className="max-h-full" />
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-lg mb-1">Ring Video Doorbell</h3>
            <p className="text-[#E86C3A] font-bold mb-2">$99.99</p>
            <p className="text-sm text-gray-600 mb-4">
              HD video doorbell with motion detection and two-way talk. See, hear, and speak to visitors from your
              phone.
            </p>
            <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
              <span className="mr-1">View Deal</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-external-link"
              >
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" x2="21" y1="14" y2="3" />
              </svg>
            </Button>
          </div>
        </div>

        {/* Product 3 */}
        <div className="border rounded-lg overflow-hidden bg-white">
          <div className="aspect-square bg-gray-100 flex items-center justify-center">
            <img src="/placeholder.svg?height=200&width=200" alt="Yale Assure Smart Lock" className="max-h-full" />
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-lg mb-1">Yale Assure Smart Lock</h3>
            <p className="text-[#E86C3A] font-bold mb-2">$249.99</p>
            <p className="text-sm text-gray-600 mb-4">
              Keyless entry smart lock that works with your smartphone. Auto-lock feature and virtual keys for guests.
            </p>
            <Button variant="outline" className="w-full text-[#E86C3A] border-[#E86C3A] hover:bg-[#E86C3A]/5">
              <span className="mr-1">View Deal</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-external-link"
              >
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" x2="21" y1="14" y2="3" />
              </svg>
            </Button>
          </div>
        </div>
      </div>

      <p className="text-xs text-gray-500 mt-6">
        * As an affiliate partner, we may earn a commission from qualifying purchases.
      </p>
    </div>
  )
}

