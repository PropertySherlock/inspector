"use client"
import { Navigation } from "@/components/dashboard/navigation"
import { Button } from "@/components/ui/button"
import { FileText } from "lucide-react"
import { useRouter } from "next/navigation"
import { PropertySelector } from "@/components/dashboard/property-selector"
import { ScheduleInspectionButton } from "@/components/dashboard/schedule-inspection-button"

type Scan = {
  id: string
  address: string
  date: string
  status: "Completed" | "In Progress" | "Scheduled"
}

export default function InspectionsPage() {
  const router = useRouter()

  // This would come from an API in a real app
  const pastScans: Scan[] = [
    {
      id: "1",
      address: "8100 Sky Mountain Ln",
      date: "March 5, 2025",
      status: "Completed",
    },
    {
      id: "2",
      address: "8100 Sky Mountain Ln",
      date: "December 10, 2024",
      status: "Completed",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 pb-20">
        <div className="container mx-auto px-4 pt-4">
          <div className="mb-8">
            <PropertySelector />
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 sm:gap-0">
            <h1 className="text-2xl font-bold">Inspections</h1>
            <ScheduleInspectionButton
              variant="default"
              className="w-full sm:w-auto bg-[#E86C3A] hover:bg-[#D55B29] text-white h-11 px-6 text-base font-medium transition-colors"
            >
              Schedule New
            </ScheduleInspectionButton>
          </div>

          {pastScans.length > 0 ? (
            <div className="space-y-4">
              {pastScans.map((scan) => (
                <div key={scan.id} className="bg-white border rounded-lg hover:shadow-md transition-shadow">
                  <div className="p-5 flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div>
                      <h3 className="text-lg sm:text-xl font-semibold mb-1">{scan.address}</h3>
                      <p className="text-sm text-gray-500 mb-2">Inspection on {scan.date}</p>
                      <div className="flex items-center">
                        <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                        <span className="text-green-600 text-sm font-medium">{scan.status}</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-gray-700 border-gray-300 hover:bg-gray-50 w-full sm:w-auto justify-center"
                      onClick={() => router.push(`/inspections/${scan.id}`)}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      View Report
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border">
              <div className="flex justify-center mb-4">
                <div className="bg-gray-100 p-4 rounded-full">
                  <FileText className="h-8 w-8 text-gray-400" />
                </div>
              </div>
              <h2 className="text-xl font-semibold mb-2">No inspections yet</h2>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">
                Schedule your first professional home inspection to get a comprehensive assessment of your property.
              </p>
              <ScheduleInspectionButton
                variant="default"
                className="bg-[#E86C3A] hover:bg-[#D55B29] text-white h-11 px-6 text-base font-medium transition-colors"
              >
                Schedule Your First Inspection
              </ScheduleInspectionButton>
            </div>
          )}
        </div>
      </main>

      <Navigation />
    </div>
  )
}

