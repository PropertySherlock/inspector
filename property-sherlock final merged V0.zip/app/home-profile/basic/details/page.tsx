"use client"

import { useState } from "react"
import { ArrowLeft, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"

export default function DetailedInformationPage() {
  const router = useRouter()
  const [notes, setNotes] = useState("")
  const [photos, setPhotos] = useState<File[]>([])

  const handleSave = () => {
    // Save logic would go here
    router.back()
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Detailed Information</h1>
        </div>
      </div>

      <main className="flex-1 p-4 max-w-3xl mx-auto">
        <div className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="notes" className="text-sm font-medium">
              Notes
            </label>
            <Textarea
              id="notes"
              placeholder="Enter any additional information..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="min-h-[150px]"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Photos</label>
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-8">
              <div className="flex flex-col items-center text-center">
                <Upload className="h-8 w-8 text-gray-400 mb-2" />
                <h4 className="font-medium mb-1">Upload photos</h4>
                <p className="text-sm text-gray-500 mb-4">Drag and drop or click to browse</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  id="photo-upload"
                  onChange={(e) => {
                    if (e.target.files) {
                      setPhotos(Array.from(e.target.files))
                    }
                  }}
                />
                <label htmlFor="photo-upload" className="cursor-pointer"></label>
              </div>
            </div>
          </div>

          <Button className="w-full bg-primary hover:bg-primary-dark text-white" onClick={handleSave}>
            Save Changes
          </Button>

          <Button variant="outline" className="w-full" onClick={() => router.back()}>
            Cancel
          </Button>
        </div>
      </main>
    </div>
  )
}

