import { Navigation } from "@/components/dashboard/navigation"
import { HomeProfileProvider } from "@/context/home-profile-context"
import type { ReactNode } from "react"

export default function HomeProfileLayout({ children }: { children: ReactNode }) {
  return (
    <HomeProfileProvider>
      {children}
      <Navigation />
    </HomeProfileProvider>
  )
}

