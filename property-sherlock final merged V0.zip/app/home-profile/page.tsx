"use client"

import { ArrowLeft, ChevronRight, Check } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"

export default function HomeProfilePage() {
  const router = useRouter()
  const { sections, sectionData, getSectionPhotos } = useHomeProfile()

  // Calculate completion status for each section
  const getSectionCompletion = (sectionId: string) => {
    const data = sectionData[sectionId] || {}
    const photos = getSectionPhotos(sectionId)

    // If there's any data or photos, consider it started
    const hasStarted = Object.keys(data).length > 0 || photos.length > 0

    // If there's substantial data (more than 2 fields filled), consider it completed
    const isCompleted = Object.keys(data).length >= 2

    return { hasStarted, isCompleted }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">39600 Fremont Blvd, Fremont, California</h1>
        </div>
      </div>

      <main className="flex-1 px-4 py-6 md:px-6 lg:px-8 pb-20">
        <div className="max-w-5xl mx-auto w-full">
          <h2 className="text-2xl font-bold mb-6">Home Profile</h2>

          <div className="grid gap-4 md:gap-6">
            {sections.map((section, index) => {
              const Icon = section.icon
              const { hasStarted, isCompleted } = getSectionCompletion(section.id)

              return (
                <Link href={`/home-profile/${section.id}`} key={section.id}>
                  <div
                    className={`flex items-center p-4 md:p-5 bg-white ${index !== 0 ? "border-t" : "rounded-t-lg"} ${
                      index === sections.length - 1 ? "rounded-b-lg" : ""
                    } hover:bg-gray-50 transition-colors border shadow-sm`}
                  >
                    <div className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-full bg-primary/10 text-primary mr-4 flex-shrink-0">
                      <Icon className="w-5 h-5 md:w-6 md:h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base md:text-lg font-medium">{section.title}</h3>
                      {hasStarted && (
                        <p className="text-xs md:text-sm text-gray-500">{isCompleted ? "Completed" : "In progress"}</p>
                      )}
                    </div>
                    {isCompleted ? (
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600 flex-shrink-0">
                        <Check className="w-4 h-4" />
                      </div>
                    ) : (
                      <ChevronRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
                    )}
                  </div>
                </Link>
              )
            })}
          </div>
        </div>
      </main>
    </div>
  )
}

