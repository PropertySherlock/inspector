export type ConditionRating = "excellent" | "good" | "fair" | "poor"

export type QuestionType = "condition" | "text" | "textarea" | "photo" | "boolean" | "multiple"

export interface HomeScanQuestion {
  id: string
  type: QuestionType
  question: string
  description?: string
  options?: {
    value: string
    label: string
    description?: string
  }[]
  required?: boolean
}

export interface HomeScanSection {
  id: string
  name: string
  questions: HomeScanQuestion[]
}

export interface HomeScanData {
  sections: HomeScanSection[]
  progress: number
}

