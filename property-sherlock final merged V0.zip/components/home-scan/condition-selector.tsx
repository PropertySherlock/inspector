"use client"
import { cn } from "@/lib/utils"

interface ConditionOption {
  value: string
  label: string
  description?: string
}

interface ConditionSelectorProps {
  options: ConditionOption[]
  value: string
  onChange: (value: string) => void
}

export function ConditionSelector({ options, value, onChange }: ConditionSelectorProps) {
  return (
    <div className="space-y-3">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          className={cn(
            "w-full text-left p-4 rounded-lg transition-all",
            "hover:bg-gray-50",
            "border-2",
            value === option.value
              ? "border-primary bg-primary/5"
              : "border-transparent bg-white hover:border-gray-200",
          )}
        >
          <div className="flex flex-col gap-1">
            <span className="font-medium">{option.label}</span>
            {option.description && <span className="text-gray-600 text-sm">{option.description}</span>}
          </div>
        </button>
      ))}
    </div>
  )
}

