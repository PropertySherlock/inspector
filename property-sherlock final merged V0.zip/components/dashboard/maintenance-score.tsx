"use client"

import { Wrench, Check, Home, ChevronRight } from "lucide-react"
import { PropertySelector } from "@/components/dashboard/property-selector"
import { useMaintenanceContext } from "@/context/maintenance-context"
import Link from "next/link"

export function MaintenanceScore() {
  const { score, maxScore, completedTasks } = useMaintenanceContext()
  const needsAttention = score < maxScore

  return (
    <div className="bg-gray-100 py-4 border-b">
      <div className="container max-w-5xl mx-auto px-3">
        <div className="mb-4">
          <PropertySelector />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Score Circle - Larger */}
          <div className="md:col-span-3 flex justify-center md:justify-start">
            <div className="relative w-32 h-32">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl font-bold text-gray-900">{score}</div>
                  <div className="text-sm text-gray-600">of {maxScore}</div>
                </div>
              </div>
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(0,0,0,0.1)" strokeWidth="8" />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="#E86C3A"
                  strokeWidth="8"
                  strokeDasharray={`${(score / maxScore) * 283} 283`}
                  strokeLinecap="round"
                  transform="rotate(-90 50 50)"
                />
              </svg>
            </div>
          </div>

          {/* Maintenance Info */}
          <div className="md:col-span-5 flex flex-col gap-4">
            <div className="flex items-center">
              <div className="bg-gray-200 p-3 rounded-full mr-4 flex-shrink-0">
                <Wrench className="h-6 w-6 text-gray-700" />
              </div>
              <div>
                <div className="text-lg font-medium text-gray-900">Maintenance</div>
                <div className="text-sm text-gray-600">{needsAttention ? "Needs attention" : "All tasks complete"}</div>
              </div>
            </div>

            <div className="flex items-center">
              <div className="bg-gray-200 p-3 rounded-full mr-4 flex-shrink-0">
                <Check className="h-6 w-6 text-gray-700" />
              </div>
              <div>
                <div className="text-lg font-medium text-gray-900">Completed (Mar)</div>
                <div className="text-sm text-gray-600">{completedTasks} to-do's</div>
              </div>
            </div>
          </div>

          {/* Home Profile - Larger */}
          <div className="md:col-span-4">
            <Link
              href="/home-profile"
              className="flex items-center p-4 bg-white rounded-lg border border-gray-200 hover:border-primary hover:shadow-md transition-all group"
            >
              <div className="bg-primary/10 p-3 rounded-full mr-4 flex-shrink-0">
                <Home className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="text-lg font-medium text-gray-900 group-hover:text-primary transition-colors">
                  Home Profile
                </div>
                <div className="text-sm text-gray-600">View and update your home details</div>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400 group-hover:text-primary transition-colors ml-2" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

