import Link from "next/link"
import { Search, ArrowRight } from "lucide-react"
import { getHomeScanData } from "@/lib/api"

export async function HomeScanCTA() {
  // In a real app, this would be a server component fetching data
  const data = await getHomeScanData()
  const progress = data.progress

  return (
    <div className="bg-white mb-4 p-4">
      <div className="flex items-center gap-1.5 mb-1">
        <Search className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-semibold">HomeScan</h2>
      </div>

      <p className="text-gray-600 mb-1">Complete your home profile</p>

      <p className="text-gray-600 text-sm mb-6">
        Get a comprehensive scan of your home to identify potential issues and customize your maintenance plan.
      </p>

      <div className="flex items-center justify-between text-xs mb-1.5">
        <span className="text-gray-700">Completion</span>
        <span className="font-bold text-gray-900">{progress}%</span>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
        <div className="bg-primary h-2 rounded-full" style={{ width: `${progress}%` }}></div>
      </div>

      <Link
        href="/homescan/exterior"
        className="w-full bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-4 rounded-md flex items-center justify-center transition-colors"
      >
        <span>{progress > 0 ? "Continue HomeScan" : "Start HomeScan Now"}</span>
        <ArrowRight className="ml-2 h-5 w-5" />
      </Link>
    </div>
  )
}

