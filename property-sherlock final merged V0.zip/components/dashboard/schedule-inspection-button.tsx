"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Calendar } from "lucide-react"
import { useRouter } from "next/navigation"

interface ScheduleInspectionButtonProps {
  className?: string
  variant?: "default" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
  children?: React.ReactNode
}

export function ScheduleInspectionButton({
  className,
  variant = "outline",
  size = "default",
  children,
}: ScheduleInspectionButtonProps) {
  const router = useRouter()

  return (
    <Button variant={variant} size={size} className={className} onClick={() => router.push("/inspections/schedule")}>
      <Calendar className="h-4 w-4 mr-2" />
      {children || "Schedule Inspection"}
    </Button>
  )
}

