import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, FileText } from "lucide-react"
import Link from "next/link"

type Scan = {
  id: string
  address: string
  date: string
  status: "Completed" | "In Progress" | "Scheduled"
}

const pastScans: Scan[] = [
  {
    id: "1",
    address: "8100 Sky Mountain Ln",
    date: "March 5, 2025",
    status: "Completed",
  },
  {
    id: "2",
    address: "8100 Sky Mountain Ln",
    date: "December 10, 2024",
    status: "Completed",
  },
]

export function PastScans() {
  return (
    <div className="mb-20">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Inspections</h2>
        <Button variant="outline" className="text-primary border-primary">
          <Calendar className="h-4 w-4 mr-2" />
          Schedule New
        </Button>
      </div>

      <div className="space-y-4">
        {pastScans.map((scan) => (
          <Card key={scan.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold mb-1">{scan.address}</h3>
                  <p className="text-sm text-gray-500 mb-2">Inspection on {scan.date}</p>
                  <div className="flex items-center">
                    <span className="inline-block w-2 h-2 rounded-full bg-success mr-2"></span>
                    <span className="text-success">{scan.status}</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-primary" asChild>
                  <Link href={`/inspections/${scan.id}`}>
                    <FileText className="h-4 w-4 mr-1" />
                    View Report
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

