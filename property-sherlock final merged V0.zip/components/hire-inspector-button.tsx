"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { UserCheck } from "lucide-react"
import { useRouter } from "next/navigation"

interface HireInspectorButtonProps {
  className?: string
  variant?: "default" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
  children?: React.ReactNode
}

export function HireInspectorButton({
  className,
  variant = "default",
  size = "default",
  children,
}: HireInspectorButtonProps) {
  const router = useRouter()

  return (
    <Button variant={variant} size={size} className={className} onClick={() => router.push("/inspections/schedule")}>
      <UserCheck className="h-4 w-4 mr-2" />
      {children || "Hire Professional Inspector"}
    </Button>
  )
}

