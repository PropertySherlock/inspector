"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Camera, X } from "lucide-react"
import Image from "next/image"

interface PhotoUploadProps {
  onUpload: (files: File[]) => void
  maxFiles?: number
}

export function PhotoUpload({ onUpload, maxFiles = 5 }: PhotoUploadProps) {
  const [files, setFiles] = useState<File[]>([])

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      setFiles((prev) => {
        const newFiles = [...prev, ...acceptedFiles].slice(0, maxFiles)
        onUpload(newFiles)
        return newFiles
      })
    },
    [maxFiles, onUpload],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png", ".webp"],
    },
    maxFiles,
  })

  const removeFile = (index: number) => {
    setFiles((prev) => {
      const newFiles = prev.filter((_, i) => i !== index)
      onUpload(newFiles)
      return newFiles
    })
  }

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 transition-colors ${
          isDragActive ? "border-primary bg-primary/5" : "border-gray-200"
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center text-center">
          <Camera className="h-8 w-8 text-gray-400 mb-3" />
          <div className="text-sm text-gray-600">
            {isDragActive ? "Drop the files here" : "Drag and drop or click to browse"}
          </div>
        </div>
      </div>

      {files.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {files.map((file, index) => (
            <div key={index} className="relative">
              <Image
                src={URL.createObjectURL(file) || "/placeholder.svg"}
                alt=""
                width={200}
                height={200}
                className="w-full h-32 object-cover rounded-lg"
              />
              <button
                onClick={() => removeFile(index)}
                className="absolute -top-2 -right-2 p-1 bg-white rounded-full shadow-md hover:bg-gray-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

