"use client"

import * as React from "react"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface ConditionOption {
  value: string
  label: string
  description: string
}

const conditionOptions: ConditionOption[] = [
  {
    value: "excellent",
    label: "Excellent",
    description: "Like new, no visible issues",
  },
  {
    value: "good",
    label: "Good",
    description: "Minor wear, no apparent issues",
  },
  {
    value: "fair",
    label: "Fair",
    description: "Some visible wear, may need attention soon",
  },
  {
    value: "poor",
    label: "Poor",
    description: "Significant wear or damage, needs attention",
  },
]

export function ConditionSurvey() {
  const [value, setValue] = React.useState("excellent")

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">What is the overall condition of your roof?</h2>
      <RadioGroup value={value} onValueChange={setValue} className="space-y-2">
        {conditionOptions.map((option) => (
          <div key={option.value} className="flex items-start space-x-3 rounded-lg border p-4 hover:bg-muted/50">
            <RadioGroupItem
              value={option.value}
              id={option.value}
              className="border-gray-300 text-primary data-[state=checked]:border-primary data-[state=checked]:bg-primary"
            />
            <div className="space-y-1">
              <Label htmlFor={option.value} className="text-base font-medium">
                {option.label}
              </Label>
              <p className="text-sm text-muted-foreground">{option.description}</p>
            </div>
          </div>
        ))}
      </RadioGroup>
    </div>
  )
}

