"use client"

import type { ReactNode } from "react"
import { PencilIcon } from "lucide-react"

interface InfoCardProps {
  title: string
  description?: string
  children?: ReactNode
  onEdit?: () => void
}

export function InfoCard({ title, description, children, onEdit }: InfoCardProps) {
  return (
    <div className="bg-white rounded-lg border p-6 mb-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h2 className="text-xl font-semibold mb-1">{title}</h2>
          {description && <p className="text-gray-600 text-sm">{description}</p>}
        </div>
        {onEdit && (
          <button onClick={onEdit} className="p-2 hover:bg-gray-100 rounded-full transition-colors" aria-label="Edit">
            <PencilIcon className="h-5 w-5 text-gray-500" />
          </button>
        )}
      </div>
      {children}
    </div>
  )
}

