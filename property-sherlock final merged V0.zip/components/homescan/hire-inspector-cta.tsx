import Link from "next/link"
import { UserCheck } from "lucide-react"

export function HireInspectorCTA() {
  return (
    <div className="fixed bottom-8 left-8 z-50">
      <Link
        href="/inspections/schedule"
        className="flex items-center gap-3 bg-white border-2 border-primary/30 shadow-xl rounded-full px-7 py-4 text-primary hover:bg-primary/5 transition-colors group"
      >
        <div className="bg-primary/10 p-3 rounded-full group-hover:bg-primary/20 transition-colors">
          <UserCheck className="h-6 w-6" />
        </div>
        <span className="font-semibold text-lg pr-1">Hire a Professional Inspector</span>
      </Link>
    </div>
  )
}

