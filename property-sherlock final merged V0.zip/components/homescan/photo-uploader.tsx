"use client"

import type React from "react"

import { useState } from "react"
import { Camera, Upload, X } from "lucide-react"
import Image from "next/image"

interface PhotoUploaderProps {
  onUpload?: (files: File[]) => void
}

export function PhotoUploader({ onUpload }: PhotoUploaderProps) {
  const [photos, setPhotos] = useState<File[]>([])
  const [previewUrls, setPreviewUrls] = useState<string[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files)
      setPhotos([...photos, ...newFiles])

      // Create preview URLs
      const newUrls = newFiles.map((file) => URL.createObjectURL(file))
      setPreviewUrls([...previewUrls, ...newUrls])

      if (onUpload) {
        onUpload([...photos, ...newFiles])
      }
    }
  }

  const removePhoto = (index: number) => {
    const newPhotos = [...photos]
    newPhotos.splice(index, 1)
    setPhotos(newPhotos)

    // Revoke the URL to avoid memory leaks
    URL.revokeObjectURL(previewUrls[index])

    const newUrls = [...previewUrls]
    newUrls.splice(index, 1)
    setPreviewUrls(newUrls)

    if (onUpload) {
      onUpload(newPhotos)
    }
  }

  return (
    <div className="space-y-4">
      <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center transition-colors hover:border-primary/30">
        <div className="flex flex-col items-center">
          <Camera className="h-8 w-8 text-gray-400 mb-2" />
          <p className="text-sm text-gray-600 mb-4">Drag and drop or click to browse</p>
          <label className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-md cursor-pointer hover:bg-primary-dark transition-colors">
            <Upload className="h-4 w-4 mr-2" />
            <span>Upload photos</span>
            <input type="file" className="hidden" accept="image/*" multiple onChange={handleFileChange} />
          </label>
        </div>
      </div>

      {previewUrls.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {previewUrls.map((url, index) => (
            <div key={index} className="relative group overflow-hidden rounded-lg border border-gray-200">
              <div className="aspect-square">
                <Image
                  src={url || "/placeholder.svg"}
                  alt={`Uploaded photo ${index + 1}`}
                  width={300}
                  height={300}
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                onClick={() => removePhoto(index)}
                className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-100"
                aria-label="Remove photo"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

