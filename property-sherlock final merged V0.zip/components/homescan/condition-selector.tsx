"use client"

import type { ConditionRating } from "@/types/homescan"

interface ConditionSelectorProps {
  value: ConditionRating
  onChange: (value: ConditionRating) => void
}

export function ConditionSelector({ value, onChange }: ConditionSelectorProps) {
  const conditions: { value: ConditionRating; label: string; description: string }[] = [
    {
      value: "excellent",
      label: "Excellent",
      description: "Like new, no visible issues",
    },
    {
      value: "good",
      label: "Good",
      description: "Minor wear, no apparent issues",
    },
    {
      value: "fair",
      label: "Fair",
      description: "Some visible wear, may need attention soon",
    },
    {
      value: "poor",
      label: "Poor",
      description: "Significant wear or damage, needs attention",
    },
  ]

  return (
    <div className="space-y-3">
      {conditions.map((condition) => (
        <label
          key={condition.value}
          className={`flex items-start p-4 border rounded-lg cursor-pointer transition-colors ${
            value === condition.value ? "border-primary bg-primary/5" : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <input
            type="radio"
            name="condition"
            value={condition.value}
            checked={value === condition.value}
            onChange={() => onChange(condition.value)}
            className="mt-1"
          />
          <div className="ml-3">
            <div className="font-medium">{condition.label}</div>
            <div className="text-sm text-gray-500">{condition.description}</div>
          </div>
        </label>
      ))}
    </div>
  )
}

