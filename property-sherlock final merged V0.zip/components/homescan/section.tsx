import type { ReactNode } from "react"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface SectionProps {
  title: string
  children: ReactNode
  backUrl?: string
}

export function Section({ title, children, backUrl }: SectionProps) {
  return (
    <div className="p-6">
      <div className="mb-6">
        {backUrl && (
          <Link href={backUrl} className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Link>
        )}
        <h1 className="text-2xl font-bold">{title}</h1>
      </div>
      {children}
    </div>
  )
}

