import type { ReactNode } from "react"

interface QuestionGroupProps {
  title: string
  children: ReactNode
}

export function QuestionGroup({ title, children }: QuestionGroupProps) {
  return (
    <div className="space-y-4 mb-6 last:mb-0">
      <h3 className="text-lg font-medium">{title}</h3>
      <div>{children}</div>
    </div>
  )
}

