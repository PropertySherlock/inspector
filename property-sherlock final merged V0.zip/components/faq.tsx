"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

interface FAQProps {
  questions: {
    question: string
    answer: string
  }[]
}

export function FAQ({ questions }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <div className="space-y-4">
      {questions.map((item, index) => (
        <div
          key={index}
          className={`border rounded-lg overflow-hidden ${openIndex === index ? "border-[#161B22]" : "border-gray-200"}`}
        >
          <button
            className="flex justify-between items-center w-full p-4 text-left bg-white hover:bg-gray-50 transition-colors"
            onClick={() => toggleQuestion(index)}
            aria-expanded={openIndex === index}
          >
            <span className="font-medium text-lg">{item.question}</span>
            {openIndex === index ? (
              <ChevronUp className="h-5 w-5 text-[#161B22]" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-400" />
            )}
          </button>
          {openIndex === index && (
            <div className="p-4 pt-0 bg-white">
              <p className="text-gray-600">{item.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

