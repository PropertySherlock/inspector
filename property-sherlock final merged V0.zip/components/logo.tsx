import Image from "next/image"

export function Logo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <Image
      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Property%20Sherlock%20Transparent%20Background-POgSUuo1P6Bh2e4vD8traxHacKIGjK.png"
      alt="Property Sherlock Logo"
      width={32}
      height={32}
      className={className}
      priority
    />
  )
}

