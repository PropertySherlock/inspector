"use client"

import { ArrowLeft, Pencil, Plus, ChevronRight, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import { useState } from "react"
import type { Section } from "@/lib/home-profile-data"

interface SectionPageProps {
  section: Section
}

export function SectionPage({ section }: SectionPageProps) {
  const router = useRouter()
  const { getSectionData, getSectionUpgrades, updateSectionData } = useHomeProfile()

  const sectionData = getSectionData(section.id)
  const upgrades = getSectionUpgrades(section.id)

  const [isSaving, setIsSaving] = useState(false)

  const handleSave = () => {
    setIsSaving(true)
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      router.push("/home-profile")
    }, 500)
  }

  // Replace the renderFieldValue function with this improved version:
  const renderFieldValue = (fieldId: string, value: any) => {
    if (!value) return null

    const field = section.fields.find((f) => f.id === fieldId)
    if (!field) return null

    if (field.type === "select" && field.options) {
      const option = field.options.find((opt) => opt.value === value)
      return option ? option.label : value
    }

    return value
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Detailed Information</h1>
        </div>
      </div>

      <main className="flex-1 p-0">
        <div className="flex flex-col items-center py-8 bg-white border-b">
          <div className="text-primary mb-2">{section.icon && <section.icon className="h-8 w-8" />}</div>
          <h2 className="text-2xl font-bold">{section.title}</h2>
        </div>

        <div className="p-4 max-w-3xl mx-auto">
          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold">{section.title}</h3>
              <button
                onClick={() => router.push(`/home-profile/${section.id}/edit`)}
                className="text-gray-500 hover:text-gray-700"
              >
                <Pencil className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4">
              {Object.keys(sectionData).length > 0 ? (
                <div className="space-y-4">
                  {section.fields.map((field) =>
                    sectionData[field.id] ? (
                      <div key={field.id} className="border-b pb-3 last:border-b-0 last:pb-0">
                        <div className="text-sm text-gray-500">{field.label}</div>
                        <div className="font-medium text-base">{renderFieldValue(field.id, sectionData[field.id])}</div>
                      </div>
                    ) : null,
                  )}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500 mb-4">No information added yet</p>
                  <Button
                    variant="outline"
                    className="flex items-center justify-center"
                    onClick={() => router.push(`/home-profile/${section.id}/edit`)}
                  >
                    <Pencil className="h-4 w-4 mr-2" />
                    Add {section.title.toLowerCase()} details
                  </Button>
                </div>
              )}
            </div>
          </div>

          {section.upgradesEnabled && (
            <div className="bg-white rounded-lg border mb-6">
              <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-lg font-semibold">Upgrades</h3>
                <button
                  onClick={() => router.push(`/home-profile/${section.id}/upgrade`)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>
              <div className="p-4">
                {upgrades.length > 0 ? (
                  <div className="space-y-4">
                    {upgrades.map((upgrade, index) => (
                      <div key={index} className="border-b pb-3 last:border-b-0 last:pb-0">
                        <div className="font-medium">{upgrade.title}</div>
                        <div className="text-sm text-gray-500">
                          {upgrade.date} • ${upgrade.cost}
                        </div>
                        {upgrade.description && <div className="text-sm mt-1">{upgrade.description}</div>}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">
                    Document any upgrades you've made to your {section.title.toLowerCase()}
                  </p>
                )}

                <Button
                  variant="outline"
                  className="w-full mt-4 flex items-center justify-center"
                  onClick={() => router.push(`/home-profile/${section.id}/upgrade`)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Upgrade
                </Button>
              </div>
            </div>
          )}

          {section.detailsEnabled && (
            <div className="bg-white rounded-lg border mb-6">
              <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-lg font-semibold">Detailed Information</h3>
                <button
                  onClick={() => router.push(`/home-profile/${section.id}/details`)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
              <div className="p-4">
                <p className="text-gray-500 mb-4">
                  Add notes and photos to document your {section.title.toLowerCase()}
                </p>

                <Button
                  variant="outline"
                  className="w-full flex items-center justify-center"
                  onClick={() => router.push(`/home-profile/${section.id}/details`)}
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Add Photos
                </Button>
              </div>
            </div>
          )}

          <Button
            className="w-full bg-primary hover:bg-primary-dark text-white"
            onClick={handleSave}
            disabled={isSaving}
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </main>
    </div>
  )
}

