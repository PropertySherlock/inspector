"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section } from "@/lib/home-profile-data"

interface UpgradeFormProps {
  section: Section
}

export function UpgradeForm({ section }: UpgradeFormProps) {
  const router = useRouter()
  const { addUpgrade } = useHomeProfile()

  const [title, setTitle] = useState("")
  const [date, setDate] = useState("")
  const [cost, setCost] = useState("")
  const [description, setDescription] = useState("")
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSaving, setIsSaving] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!title.trim()) {
      newErrors.title = "Upgrade title is required"
    }

    if (!date.trim()) {
      newErrors.date = "Date is required"
    }

    if (cost && isNaN(Number(cost.replace(/[$,]/g, "")))) {
      newErrors.cost = "Cost must be a number"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSave = () => {
    if (!validateForm()) {
      return
    }

    setIsSaving(true)

    // Format the cost with dollar sign if it's a number
    let formattedCost = cost
    if (cost && !isNaN(Number(cost.replace(/[$,]/g, "")))) {
      formattedCost = "$" + Number(cost.replace(/[$,]/g, "")).toLocaleString()
    }

    // Add the upgrade
    addUpgrade(section.id, {
      title,
      date,
      cost: formattedCost,
      description,
    })

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      router.back()
    }, 500)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Add Upgrade</h1>
        </div>
      </div>

      <main className="flex-1 px-4 py-6 md:px-6 lg:px-8 w-full">
        <div className="max-w-5xl mx-auto w-full">
          <div className="bg-white rounded-lg border p-4 md:p-6 mb-6">
            <h2 className="text-lg md:text-xl font-semibold mb-4">
              Document an upgrade to your {section.title.toLowerCase()}
            </h2>
            <p className="text-gray-500 mb-6">
              Record improvements you've made to help track your home's maintenance history and value.
            </p>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <label htmlFor="title" className="text-sm font-medium">
                  Upgrade Title <span className="text-red-500">*</span>
                </label>
                <Input
                  id="title"
                  placeholder="e.g., New Water Heater, Roof Replacement"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value)
                    if (errors.title) {
                      setErrors({ ...errors, title: "" })
                    }
                  }}
                  className={errors.title ? "border-red-500" : ""}
                />
                {errors.title && <p className="text-red-500 text-sm">{errors.title}</p>}
              </div>

              <div className="space-y-2">
                <label htmlFor="date" className="text-sm font-medium">
                  Date Completed <span className="text-red-500">*</span>
                </label>
                <Input
                  id="date"
                  placeholder="e.g., March 2025, 03/2025"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value)
                    if (errors.date) {
                      setErrors({ ...errors, date: "" })
                    }
                  }}
                  className={errors.date ? "border-red-500" : ""}
                />
                {errors.date && <p className="text-red-500 text-sm">{errors.date}</p>}
              </div>

              <div className="space-y-2">
                <label htmlFor="cost" className="text-sm font-medium">
                  Cost
                </label>
                <Input
                  id="cost"
                  placeholder="e.g., 1200"
                  value={cost}
                  onChange={(e) => {
                    setCost(e.target.value)
                    if (errors.cost) {
                      setErrors({ ...errors, cost: "" })
                    }
                  }}
                  className={errors.cost ? "border-red-500" : ""}
                />
                {errors.cost && <p className="text-red-500 text-sm">{errors.cost}</p>}
                <p className="text-xs text-gray-500">Enter the amount without dollar signs or commas</p>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label htmlFor="description" className="text-sm font-medium">
                  Description
                </label>
                <Textarea
                  id="description"
                  placeholder="Enter any additional details about the upgrade, such as the contractor used, warranty information, or specific materials"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button
              className="flex-1 bg-primary hover:bg-primary-dark text-white h-12 text-base"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? "Saving..." : "Save Upgrade"}
            </Button>

            <Button variant="outline" className="flex-1 h-12" onClick={() => router.back()}>
              Cancel
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

