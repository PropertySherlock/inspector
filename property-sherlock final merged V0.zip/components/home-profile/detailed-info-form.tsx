"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section } from "@/lib/home-profile-data"

interface DetailedInfoFormProps {
  section: Section
}

export function DetailedInfoForm({ section }: DetailedInfoFormProps) {
  const router = useRouter()
  const { getSectionData, updateSectionData, addSectionPhotos } = useHomeProfile()

  const existingData = getSectionData(section.id)
  const [notes, setNotes] = useState(existingData.notes || "")
  const [photos, setPhotos] = useState<File[]>([])
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = () => {
    setIsSaving(true)

    // Save notes
    updateSectionData(section.id, { notes })

    // Save photos
    if (photos.length > 0) {
      addSectionPhotos(section.id, photos)
    }

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      router.back()
    }, 500)
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">Detailed Information</h1>
        </div>
      </div>

      <main className="flex-1 px-4 py-6 md:px-6 lg:px-8 w-full">
        <div className="max-w-5xl mx-auto w-full">
          <div className="space-y-8">
            {/* Notes Section */}
            <div className="bg-white rounded-lg border p-4 md:p-6">
              <h2 className="text-xl font-bold mb-4">Additional notes about your {section.title.toLowerCase()}</h2>
              <Textarea
                placeholder="Enter any additional information..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="min-h-[200px] bg-white w-full"
              />
            </div>

            {/* Photos Section */}
            <div className="bg-white rounded-lg border p-4 md:p-6">
              <h2 className="text-xl font-bold mb-4">Upload photos of your {section.title.toLowerCase()}</h2>
              <div className="border-2 border-dashed border-gray-200 rounded-lg p-6">
                <div className="flex flex-col items-center text-center">
                  <Camera className="h-10 w-10 text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Upload photos</h3>
                  <p className="text-gray-500 mb-6">Drag and drop or click to browse</p>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="hidden"
                    id="photo-upload"
                    onChange={handlePhotoUpload}
                  />
                  <label
                    htmlFor="photo-upload"
                    className="bg-white border border-gray-300 rounded-md px-6 py-2 cursor-pointer hover:border-gray-400 transition-colors text-base"
                  >
                    Choose Files
                  </label>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <Button
                className="flex-1 bg-primary hover:bg-primary-dark text-white h-12 text-base"
                onClick={handleSave}
                disabled={isSaving}
              >
                {isSaving ? "Saving..." : "Save Changes"}
              </Button>
              <Button variant="outline" className="flex-1 h-12" onClick={() => router.back()} disabled={isSaving}>
                Cancel
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

