"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ArrowLeft, Camera, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section, Field } from "@/lib/home-profile-data"

interface SectionFormProps {
  section: Section
}

export function SectionForm({ section }: SectionFormProps) {
  const router = useRouter()
  const { getSectionData, updateSectionData, getSectionPhotos, addSectionPhotos } = useHomeProfile()

  const existingData = getSectionData(section.id)
  const [formData, setFormData] = useState<Record<string, any>>(existingData)
  const [photos, setPhotos] = useState<File[]>(getSectionPhotos(section.id))
  const [previewUrls, setPreviewUrls] = useState<string[]>([])
  const [isSaving, setIsSaving] = useState(false)

  // Generate preview URLs for photos
  useEffect(() => {
    const urls = photos.map((photo) => URL.createObjectURL(photo))
    setPreviewUrls(urls)

    // Cleanup function to revoke object URLs
    return () => {
      urls.forEach((url) => URL.revokeObjectURL(url))
    }
  }, [photos])

  const handleInputChange = (fieldId: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [fieldId]: value,
    }))
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files)
      setPhotos((prev) => [...prev, ...newFiles])
    }
  }

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSave = () => {
    setIsSaving(true)

    // Save form data
    updateSectionData(section.id, formData)

    // Save photos
    if (photos.length > 0) {
      addSectionPhotos(section.id, photos)
    }

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      router.push("/home-profile")
    }, 500)
  }

  const renderField = (field: Field) => {
    switch (field.type) {
      case "text":
      case "date":
        return (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
          />
        )
      case "number":
        return (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
            type="number"
          />
        )
      case "textarea":
        return (
          <Textarea
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleInputChange(field.id, e.target.value)}
            className="min-h-[120px]"
          />
        )
      case "select":
        return (
          <Select value={formData[field.id] || ""} onValueChange={(value) => handleInputChange(field.id, value)}>
            <SelectTrigger>
              <SelectValue placeholder={field.placeholder || `Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      case "photo":
        return (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex flex-col items-center text-center">
                <Camera className="h-8 w-8 text-gray-400 mb-2" />
                <h4 className="font-medium mb-1">Upload photos</h4>
                <p className="text-sm text-gray-500 mb-4">Drag and drop or click to browse</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  id={`photo-upload-${field.id}`}
                  onChange={handlePhotoUpload}
                />
                <label
                  htmlFor={`photo-upload-${field.id}`}
                  className="bg-primary text-white px-4 py-2 rounded-md cursor-pointer hover:bg-primary-dark transition-colors"
                >
                  Choose Photos
                </label>
              </div>
            </div>

            {previewUrls.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {previewUrls.map((url, index) => (
                  <div key={index} className="relative group">
                    <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                      <img
                        src={url || "/placeholder.svg"}
                        alt={`Uploaded photo ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <button
                      onClick={() => removePhoto(index)}
                      className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                      aria-label="Remove photo"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )
      default:
        return null
    }
  }

  // Group fields by type for better organization
  const basicFields = section.fields.filter((field) => field.type !== "textarea" && field.type !== "photo")
  const textareaFields = section.fields.filter((field) => field.type === "textarea")
  const photoFields = section.fields.filter((field) => field.type === "photo")

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">{section.title}</h1>
        </div>
      </div>

      <main className="flex-1 p-4 max-w-3xl mx-auto pb-20">
        {/* Section Header */}
        <div className="flex flex-col items-center py-6 bg-white rounded-lg border mb-6">
          <div className="text-primary mb-2">{section.icon && <section.icon className="h-8 w-8" />}</div>
          <h2 className="text-2xl font-bold">{section.title}</h2>
          {section.description && <p className="text-gray-500 mt-2">{section.description}</p>}
        </div>

        {/* Basic Fields */}
        {basicFields.length > 0 && (
          <div className="bg-white rounded-lg border p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
            <div className="space-y-6">
              {basicFields.map((field) => (
                <div key={field.id} className="space-y-2">
                  <label htmlFor={field.id} className="text-sm font-medium">
                    {field.label}
                  </label>
                  {renderField(field)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Textarea Fields */}
        {textareaFields.length > 0 && (
          <div className="bg-white rounded-lg border p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Additional Information</h3>
            <div className="space-y-6">
              {textareaFields.map((field) => (
                <div key={field.id} className="space-y-2">
                  <label htmlFor={field.id} className="text-sm font-medium">
                    {field.label}
                  </label>
                  {renderField(field)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Photo Fields */}
        {photoFields.length > 0 && (
          <div className="bg-white rounded-lg border p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Photos</h3>
            <div className="space-y-6">
              {photoFields.map((field) => (
                <div key={field.id} className="space-y-2">
                  <label htmlFor={field.id} className="text-sm font-medium">
                    {field.label}
                  </label>
                  {field.description && <p className="text-sm text-gray-500 mb-2">{field.description}</p>}
                  {renderField(field)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Save Button */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
          <div className="max-w-3xl mx-auto">
            <Button
              className="w-full bg-primary hover:bg-primary-dark text-white h-12 text-base"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

