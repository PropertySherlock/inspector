"use client"

import { ArrowLeft, Plus, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { useHomeProfile } from "@/context/home-profile-context"
import type { Section } from "@/lib/home-profile-data"

interface SectionViewProps {
  section: Section
}

export function SectionView({ section }: SectionViewProps) {
  const router = useRouter()
  const { getSectionData, getSectionPhotos } = useHomeProfile()

  const sectionData = getSectionData(section.id)
  const photos = getSectionPhotos(section.id)

  const renderBasicInfo = () => {
    if (!sectionData) return null

    return Object.entries(sectionData).map(([key, value]) => {
      const field = section.fields.find((f) => f.id === key)
      if (!field || field.type === "photo" || field.type === "textarea") return null

      return (
        <div key={key} className="mb-2">
          <div className="text-sm text-gray-500">{field.label}</div>
          <div className="font-medium">{value}</div>
        </div>
      )
    })
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white p-4 border-b">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold">{section.title}</h1>
        </div>
      </div>

      <main className="flex-1 w-full">
        <div className="flex flex-col items-center py-6 md:py-8 bg-white border-b w-full">
          <div className="text-primary mb-2">{section.icon && <section.icon className="h-8 w-8" />}</div>
          <h2 className="text-2xl md:text-3xl font-bold">{section.title}</h2>
        </div>

        <div className="px-4 py-6 md:px-6 lg:px-8 max-w-5xl mx-auto w-full">
          {/* Basic Information */}
          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 md:p-5 border-b">
              <h3 className="text-lg md:text-xl font-semibold">Basic Information</h3>
              <button
                onClick={() => router.push(`/home-profile/${section.id}/edit`)}
                className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 md:p-5">
              {Object.keys(sectionData).length > 0 ? (
                renderBasicInfo()
              ) : (
                <p className="text-gray-500">Click the edit button to add basic information</p>
              )}
            </div>
          </div>

          {/* Upgrades */}
          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 md:p-5 border-b">
              <h3 className="text-lg md:text-xl font-semibold">Upgrades</h3>
              <button
                onClick={() => router.push(`/home-profile/${section.id}/upgrade`)}
                className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 md:p-5">
              <p className="text-gray-500">Document any upgrades you've made to your {section.title.toLowerCase()}</p>
              <Button
                variant="outline"
                className="w-full mt-4"
                onClick={() => router.push(`/home-profile/${section.id}/upgrade`)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Upgrade
              </Button>
            </div>
          </div>

          {/* Detailed Information */}
          <div className="bg-white rounded-lg border mb-6">
            <div className="flex justify-between items-center p-4 md:p-5 border-b">
              <h3 className="text-lg md:text-xl font-semibold">Detailed Information</h3>
              <button
                onClick={() => router.push(`/home-profile/${section.id}/details`)}
                className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 md:p-5">
              <p className="text-gray-500 mb-4">Add notes and photos to document your {section.title.toLowerCase()}</p>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => router.push(`/home-profile/${section.id}/details`)}
              >
                <Camera className="h-4 w-4 mr-2" />
                Add Photos
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

