"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Camera, Check, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

// This would come from an API in a real application
const scanCategories = [
  {
    id: "exterior",
    name: "Exterior",
    sections: [
      {
        id: "roof",
        title: "Roof Condition",
        questions: [
          {
            id: "roof-condition",
            type: "radio",
            label: "What is the overall condition of the roof?",
            options: [
              { value: "excellent", label: "Excellent - Like new, no visible issues" },
              { value: "good", label: "Good - Minor wear, no apparent issues" },
              { value: "fair", label: "Fair - Some visible wear, may need attention soon" },
              { value: "poor", label: "Poor - Significant wear or damage, needs attention" },
            ],
            defaultValue: "good",
          },
          {
            id: "roof-leaks",
            type: "radio",
            label: "Are there any visible leaks or water damage?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
              { value: "unsure", label: "Not visible/accessible" },
            ],
            defaultValue: "no",
          },
          {
            id: "roof-age",
            type: "text",
            label: "Estimated age of roof",
            placeholder: "e.g., 5-10 years",
          },
          {
            id: "roof-notes",
            type: "textarea",
            label: "Additional notes about the roof",
            placeholder: "Enter any additional observations about the roof...",
          },
          {
            id: "roof-photos",
            type: "photo",
            label: "Upload photos of the roof",
          },
        ],
      },
      {
        id: "siding",
        title: "Siding & Exterior Walls",
        questions: [
          {
            id: "siding-condition",
            type: "radio",
            label: "What is the condition of the siding/exterior walls?",
            options: [
              { value: "excellent", label: "Excellent - Like new" },
              { value: "good", label: "Good - Minor wear" },
              { value: "fair", label: "Fair - Some visible issues" },
              { value: "poor", label: "Poor - Significant damage" },
            ],
            defaultValue: "good",
          },
          {
            id: "siding-material",
            type: "text",
            label: "What material is the siding made of?",
            placeholder: "e.g., vinyl, wood, brick, stucco",
          },
          {
            id: "siding-notes",
            type: "textarea",
            label: "Additional notes about the exterior walls",
            placeholder: "Enter any additional observations about the exterior walls...",
          },
          {
            id: "siding-photos",
            type: "photo",
            label: "Upload photos of the exterior walls",
          },
        ],
      },
    ],
  },
  {
    id: "interior",
    name: "Interior",
    sections: [
      {
        id: "walls",
        title: "Walls & Ceilings",
        questions: [
          {
            id: "walls-cracks",
            type: "radio",
            label: "Are there any cracks in the walls or ceilings?",
            options: [
              { value: "none", label: "No cracks" },
              { value: "minor", label: "Minor hairline cracks" },
              { value: "moderate", label: 'Moderate cracks (1/8" to 1/4")' },
              { value: "severe", label: 'Severe cracks (larger than 1/4")' },
            ],
            defaultValue: "minor",
          },
          {
            id: "walls-stains",
            type: "radio",
            label: "Are there any water stains on walls or ceilings?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
            ],
            defaultValue: "no",
          },
          {
            id: "walls-location",
            type: "text",
            label: "If there are cracks or stains, where are they located?",
            placeholder: "e.g., master bedroom ceiling, living room wall",
          },
          {
            id: "walls-notes",
            type: "textarea",
            label: "Additional notes about the walls and ceilings",
            placeholder: "Enter any additional observations about the walls and ceilings...",
          },
          {
            id: "walls-photos",
            type: "photo",
            label: "Upload photos of any concerning areas",
          },
        ],
      },
      {
        id: "floors",
        title: "Floors",
        questions: [
          {
            id: "floors-condition",
            type: "radio",
            label: "What is the overall condition of the floors?",
            options: [
              { value: "excellent", label: "Excellent - Like new" },
              { value: "good", label: "Good - Minor wear" },
              { value: "fair", label: "Fair - Some visible issues" },
              { value: "poor", label: "Poor - Significant damage" },
            ],
            defaultValue: "good",
          },
          {
            id: "floors-type",
            type: "text",
            label: "What type of flooring is in most rooms?",
            placeholder: "e.g., hardwood, carpet, tile, laminate",
          },
          {
            id: "floors-notes",
            type: "textarea",
            label: "Additional notes about the floors",
            placeholder: "Enter any additional observations about the floors...",
          },
          {
            id: "floors-photos",
            type: "photo",
            label: "Upload photos of the floors",
          },
        ],
      },
    ],
  },
  {
    id: "systems",
    name: "Systems",
    sections: [
      {
        id: "hvac",
        title: "HVAC System",
        questions: [
          {
            id: "hvac-condition",
            type: "radio",
            label: "What is the overall condition of the HVAC system?",
            options: [
              { value: "excellent", label: "Excellent - Like new, no issues" },
              { value: "good", label: "Good - Working well, minor wear" },
              { value: "fair", label: "Fair - Working but showing age" },
              { value: "poor", label: "Poor - Not working properly" },
            ],
            defaultValue: "good",
          },
          {
            id: "hvac-age",
            type: "text",
            label: "Estimated age of HVAC system",
            placeholder: "e.g., 5 years, 10+ years",
          },
          {
            id: "hvac-maintenance",
            type: "text",
            label: "Maintenance records available?",
            placeholder: "e.g., last serviced 6 months ago, no records available",
          },
          {
            id: "hvac-notes",
            type: "textarea",
            label: "Additional notes about the HVAC system",
            placeholder: "Enter any additional observations about the HVAC system...",
          },
          {
            id: "hvac-photos",
            type: "photo",
            label: "Upload photos of the HVAC system",
          },
        ],
      },
      {
        id: "plumbing",
        title: "Plumbing",
        questions: [
          {
            id: "plumbing-issues",
            type: "radio",
            label: "Are there any visible leaks or water pressure issues?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
            ],
            defaultValue: "no",
          },
          {
            id: "plumbing-details",
            type: "text",
            label: "If there are plumbing issues, describe them",
            placeholder: "e.g., slow drain in master bath, low pressure in kitchen",
          },
          {
            id: "plumbing-notes",
            type: "textarea",
            label: "Additional notes about the plumbing",
            placeholder: "Enter any additional observations about the plumbing...",
          },
          {
            id: "plumbing-photos",
            type: "photo",
            label: "Upload photos of any plumbing concerns",
          },
        ],
      },
      {
        id: "electrical",
        title: "Electrical",
        questions: [
          {
            id: "electrical-panel",
            type: "radio",
            label: "Condition of the electrical panel",
            options: [
              { value: "excellent", label: "Excellent - Modern, well-organized" },
              { value: "good", label: "Good - Clean, functioning properly" },
              { value: "fair", label: "Fair - Some issues but functional" },
              { value: "poor", label: "Poor - Outdated or hazardous" },
            ],
            defaultValue: "good",
          },
          {
            id: "electrical-issues",
            type: "text",
            label: "Any electrical issues observed?",
            placeholder: "e.g., flickering lights, circuit breaker issues",
          },
          {
            id: "electrical-notes",
            type: "textarea",
            label: "Additional notes about the electrical system",
            placeholder: "Enter any additional observations about the electrical system...",
          },
          {
            id: "electrical-photos",
            type: "photo",
            label: "Upload photos of electrical panel or concerns",
          },
        ],
      },
    ],
  },
]

export default function InspectorScanPage() {
  const [activeCategory, setActiveCategory] = useState(scanCategories[0].id)
  const [progress, setProgress] = useState(0)
  const [photos, setPhotos] = useState<Record<string, File[]>>({})
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [clientInfo, setClientInfo] = useState({
    name: "Sarah Johnson",
    address: "123 Main Street, Anytown, CA",
    inspectionDate: new Date().toLocaleDateString(),
  })

  const handlePhotoUpload = (questionId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos((prev) => ({
        ...prev,
        [questionId]: Array.from(e.target.files || []),
      }))

      // Update progress when photos are added
      updateProgress()
    }
  }

  const handleInputChange = (questionId: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [questionId]: value,
    }))

    // Update progress when inputs change
    updateProgress()
  }

  const updateProgress = () => {
    // Simple progress calculation - can be made more sophisticated
    const totalQuestions = scanCategories.flatMap((category) =>
      category.sections.flatMap((section) => section.questions),
    ).length

    const answeredQuestions = Object.keys(formData).length + Object.keys(photos).length
    setProgress(Math.round((answeredQuestions / totalQuestions) * 100))
  }

  const handleSave = () => {
    // Save functionality would go here
    alert("Progress saved!")
  }

  const handleComplete = () => {
    // Complete functionality would go here
    window.location.href = "/inspector/reports"
  }

  const renderQuestion = (question: any) => {
    switch (question.type) {
      case "radio":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>{question.label}</Label>
            <RadioGroup
              defaultValue={question.defaultValue}
              onValueChange={(value) => handleInputChange(question.id, value)}
            >
              {question.options.map((option: any) => (
                <div className="flex items-center space-x-2" key={option.value}>
                  <RadioGroupItem value={option.value} id={`${question.id}-${option.value}`} />
                  <Label htmlFor={`${question.id}-${option.value}`}>{option.label}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        )

      case "text":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>{question.label}</Label>
            <Input
              placeholder={question.placeholder}
              onChange={(e) => handleInputChange(question.id, e.target.value)}
            />
          </div>
        )

      case "textarea":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>{question.label}</Label>
            <Textarea
              placeholder={question.placeholder}
              onChange={(e) => handleInputChange(question.id, e.target.value)}
            />
          </div>
        )

      case "photo":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>{question.label}</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here or click to browse</p>
                <Button variant="outline" size="sm" className="relative">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photos
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={(e) => handlePhotoUpload(question.id, e)}
                  />
                </Button>
              </div>
              {photos[question.id]?.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium">{photos[question.id].length} photo(s) selected</p>
                </div>
              )}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="container max-w-5xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/inspector/dashboard">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back to Dashboard</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Professional Inspection</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Progress: {progress}%</span>
            <Progress value={progress} className="w-24" />
          </div>
          <Button variant="outline" onClick={handleSave}>
            Save Progress
          </Button>
          <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleComplete}>
            <Check className="mr-2 h-4 w-4" />
            Complete Inspection
          </Button>
        </div>
      </div>

      <Card className="bg-gray-50 border-gray-200">
        <CardContent className="p-4">
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div>
              <p className="font-medium">Client:</p>
              <p>{clientInfo.name}</p>
            </div>
            <div>
              <p className="font-medium">Address:</p>
              <p>{clientInfo.address}</p>
            </div>
            <div>
              <p className="font-medium">Inspection Date:</p>
              <p>{clientInfo.inspectionDate}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-4">
        <div className="sticky top-0 z-10 bg-background pt-2 pb-4">
          <TabsList className="grid w-full grid-cols-3 h-auto p-1">
            {scanCategories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="py-3 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700"
              >
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {scanCategories.map((category) => (
          <TabsContent key={category.id} value={category.id} className="space-y-6">
            {category.sections.map((section) => (
              <Card key={section.id}>
                <CardHeader>
                  <CardTitle>{section.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {section.questions.map((question) => renderQuestion(question))}
                </CardContent>
                {section.id === category.sections[category.sections.length - 1].id && (
                  <CardFooter className="flex justify-between">
                    {category.id !== scanCategories[0].id && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          const currentIndex = scanCategories.findIndex((c) => c.id === category.id)
                          if (currentIndex > 0) {
                            setActiveCategory(scanCategories[currentIndex - 1].id)
                          }
                        }}
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to{" "}
                        {
                          scanCategories.find(
                            (c, i) => scanCategories.findIndex((cat) => cat.id === category.id) - 1 === i,
                          )?.name
                        }
                      </Button>
                    )}
                    {category.id !== scanCategories[scanCategories.length - 1].id ? (
                      <Button
                        className="bg-orange-500 hover:bg-orange-600 ml-auto"
                        onClick={() => {
                          const currentIndex = scanCategories.findIndex((c) => c.id === category.id)
                          if (currentIndex < scanCategories.length - 1) {
                            setActiveCategory(scanCategories[currentIndex + 1].id)
                          }
                        }}
                      >
                        Next:{" "}
                        {
                          scanCategories.find(
                            (c, i) => scanCategories.findIndex((cat) => cat.id === category.id) + 1 === i,
                          )?.name
                        }
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button className="bg-orange-500 hover:bg-orange-600 ml-auto" onClick={handleComplete}>
                        <Check className="mr-2 h-4 w-4" />
                        Complete Inspection
                      </Button>
                    )}
                  </CardFooter>
                )}
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

