import Link from "next/link"
import { ArrowRight, Calendar, CheckSquare, ClipboardList, User2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function InspectorDashboardPage() {
  // This would come from your database in a real app
  const upcomingInspections = [
    {
      id: 1,
      clientName: "Sarah Johnson",
      address: "123 Main Street, Anytown, CA",
      date: "Today, 2:00 PM",
      status: "Upcoming",
    },
    {
      id: 2,
      clientName: "Michael Smith",
      address: "456 Oak Avenue, Somewhere, CA",
      date: "Tomorrow, 10:00 AM",
      status: "Upcoming",
    },
    {
      id: 3,
      clientName: "Emily Wilson",
      address: "789 Pine Road, Elsewhere, CA",
      date: "Mar 8, 1:30 PM",
      status: "Upcoming",
    },
  ]

  const recentInspections = [
    {
      id: 101,
      clientName: "David Brown",
      address: "321 Maple Drive, Nowhere, CA",
      date: "Mar 3, 2024",
      status: "Completed",
    },
    {
      id: 102,
      clientName: "Jennifer Lee",
      address: "654 Cedar Lane, Everywhere, CA",
      date: "Mar 1, 2024",
      status: "Completed",
    },
  ]

  return (
    <div className="container max-w-5xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Inspector Dashboard</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <Calendar className="h-4 w-4" />
            Calendar View
          </Button>
          <Button className="bg-orange-500 hover:bg-orange-600" size="sm">
            <CheckSquare className="h-4 w-4 mr-2" />
            New Inspection
          </Button>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upcoming Inspections</h2>
          <div className="grid gap-4">
            {upcomingInspections.map((inspection) => (
              <Card key={inspection.id}>
                <CardContent className="p-0">
                  <div className="p-4 md:p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <User2 className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{inspection.clientName}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{inspection.address}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Calendar className="h-4 w-4 text-orange-500" />
                        <span className="text-sm font-medium">{inspection.date}</span>
                        <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-inset ring-green-600/20">
                          {inspection.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        Reschedule
                      </Button>
                      <Link href={inspection.id === 1 ? "/inspector" : "#"}>
                        <Button className="bg-orange-500 hover:bg-orange-600" size="sm">
                          Start Inspection
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Recent Inspections</h2>
          <div className="grid gap-4">
            {recentInspections.map((inspection) => (
              <Card key={inspection.id}>
                <CardContent className="p-0">
                  <div className="p-4 md:p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <User2 className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{inspection.clientName}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{inspection.address}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{inspection.date}</span>
                        <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-600/20">
                          {inspection.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" className="gap-2">
                        <ClipboardList className="h-4 w-4" />
                        View Report
                      </Button>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

