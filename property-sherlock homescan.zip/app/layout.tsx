import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Link from "next/link"
import { Bell, User } from "lucide-react"

import { Button } from "@/components/ui/button"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Property Sherlock",
  description: "Your home maintenance companion",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="border-b">
          <div className="container flex h-16 items-center justify-between">
            <div className="flex items-center gap-6">
              <Link href="/dashboard" className="flex items-center gap-2">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Property%20Sherlock%20Transparent%20Background-g9hTN7BswTdwXORfwOoaVPEyKhyplG.png"
                  alt="Property Sherlock"
                  className="h-8 w-8"
                />
                <span className="font-bold text-xl">Property Sherlock</span>
              </Link>
              <nav className="hidden md:flex items-center gap-6">
                <Link href="/dashboard" className="text-sm font-medium">
                  Home
                </Link>
                <Link href="#" className="text-sm font-medium">
                  About Us
                </Link>
                <Link href="#" className="text-sm font-medium">
                  Contact Us
                </Link>
              </nav>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
                <span className="sr-only">Notifications</span>
              </Button>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Account</span>
              </Button>
            </div>
          </div>
        </header>
        {children}
      </body>
    </html>
  )
}



import './globals.css'