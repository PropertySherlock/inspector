"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, UserCheck } from "lucide-react"
import { Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ScheduleInspectorPage() {
  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleNext = () => {
    setStep(step + 1)
    window.scrollTo(0, 0)
  }

  const handlePrevious = () => {
    setStep(step - 1)
    window.scrollTo(0, 0)
  }

  const handleSubmit = () => {
    setIsSubmitting(true)
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      window.location.href = "/dashboard"
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="container max-w-3xl py-8 space-y-6">
        <div className="flex items-center gap-2">
          <Link href="/home-scan">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Schedule a Professional Inspector</h1>
        </div>

        <div className="bg-white rounded-lg p-4 mb-6 flex justify-between">
          <div className="flex space-x-4">
            {[1, 2, 3, 4].map((stepNumber) => (
              <div
                key={stepNumber}
                className={`flex items-center ${step >= stepNumber ? "text-orange-500" : "text-gray-400"}`}
              >
                <div
                  className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                    step === stepNumber
                      ? "border-orange-500 bg-orange-50"
                      : step > stepNumber
                        ? "border-orange-500 bg-orange-500 text-white"
                        : "border-gray-300"
                  }`}
                >
                  {step > stepNumber ? <Check className="h-4 w-4" /> : stepNumber}
                </div>
                <span className={`ml-2 text-sm ${step === stepNumber ? "font-medium" : ""}`}>
                  {stepNumber === 1 ? "Type" : stepNumber === 2 ? "Date" : stepNumber === 3 ? "Info" : "Confirm"}
                </span>
              </div>
            ))}
          </div>
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Select Inspection Type</CardTitle>
              <CardDescription>Choose the type of inspection you need</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup defaultValue="comprehensive">
                <div className="flex flex-col space-y-4">
                  <div className="border rounded-lg p-4 relative">
                    <div className="absolute right-4 top-4">
                      <RadioGroupItem value="comprehensive" id="comprehensive" />
                    </div>
                    <div className="pr-6">
                      <Label htmlFor="comprehensive" className="font-medium text-lg">
                        Comprehensive Home Inspection
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        A thorough inspection of the entire property, including exterior, interior, and all major
                        systems.
                      </p>
                      <p className="font-medium mt-2">$499</p>
                    </div>
                  </div>
                  <div className="border rounded-lg p-4 relative">
                    <div className="absolute right-4 top-4">
                      <RadioGroupItem value="focused" id="focused" />
                    </div>
                    <div className="pr-6">
                      <Label htmlFor="focused" className="font-medium text-lg">
                        Focused Inspection
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        A targeted inspection focusing on specific areas or systems of concern.
                      </p>
                      <p className="font-medium mt-2">$299</p>
                    </div>
                  </div>
                  <div className="border rounded-lg p-4 relative">
                    <div className="absolute right-4 top-4">
                      <RadioGroupItem value="pre-purchase" id="pre-purchase" />
                    </div>
                    <div className="pr-6">
                      <Label htmlFor="pre-purchase" className="font-medium text-lg">
                        Pre-Purchase Inspection
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Comprehensive inspection designed for home buyers before finalizing a purchase.
                      </p>
                      <p className="font-medium mt-2">$549</p>
                    </div>
                  </div>
                </div>
              </RadioGroup>
            </CardContent>
            <CardFooter className="flex justify-end pt-6">
              <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleNext}>
                Continue
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Select Date and Time</CardTitle>
              <CardDescription>Choose when you'd like the inspector to visit</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Preferred Date</Label>
                <div className="grid grid-cols-3 gap-2">
                  {["Mar 8", "Mar 9", "Mar 10", "Mar 11", "Mar 12", "Mar 13"].map((date) => (
                    <Button key={date} variant="outline" className="h-20 flex flex-col gap-1">
                      <span className="text-sm text-muted-foreground">{date.split(" ")[0]}</span>
                      <span className="text-xl">{date.split(" ")[1]}</span>
                    </Button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Preferred Time</Label>
                <Select defaultValue="morning">
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (9am - 12pm)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (12pm - 3pm)</SelectItem>
                    <SelectItem value="evening">Evening (3pm - 6pm)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-6">
              <Button variant="outline" onClick={handlePrevious}>
                Back
              </Button>
              <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleNext}>
                Continue
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Your Information</CardTitle>
              <CardDescription>Please provide your contact details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input id="first-name" placeholder="Enter your first name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input id="last-name" placeholder="Enter your last name" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="Enter your email" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" type="tel" placeholder="Enter your phone number" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Property Address</Label>
                <Input id="address" placeholder="Enter the property address" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes (Optional)</Label>
                <Input id="notes" placeholder="Any specific areas of concern?" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-6">
              <Button variant="outline" onClick={handlePrevious}>
                Back
              </Button>
              <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleNext}>
                Continue
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 4 && (
          <Card>
            <CardHeader className="bg-green-50 rounded-t-lg">
              <div className="flex items-center gap-2">
                <UserCheck className="h-6 w-6 text-green-600" />
                <CardTitle className="text-xl text-green-700">Confirm Your Inspection</CardTitle>
              </div>
              <CardDescription>Please review your inspection details before confirming.</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2 border-b pb-4">
                <h3 className="font-medium">Inspection Details</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-muted-foreground">Type:</div>
                  <div>Comprehensive Home Inspection</div>
                  <div className="text-muted-foreground">Date:</div>
                  <div>March 10, 2024</div>
                  <div className="text-muted-foreground">Time:</div>
                  <div>Morning (9am - 12pm)</div>
                  <div className="text-muted-foreground">Price:</div>
                  <div className="font-medium">$499</div>
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Contact Information</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-muted-foreground">Name:</div>
                  <div>John Doe</div>
                  <div className="text-muted-foreground">Email:</div>
                  <div>john.doe@example.com</div>
                  <div className="text-muted-foreground">Phone:</div>
                  <div>(555) 123-4567</div>
                  <div className="text-muted-foreground">Address:</div>
                  <div>123 Main St, Anytown, CA</div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-6">
              <Button variant="outline" onClick={handlePrevious}>
                Back
              </Button>
              <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? "Processing..." : "Confirm Inspection"}
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}

