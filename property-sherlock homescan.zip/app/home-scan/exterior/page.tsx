"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Camera, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"

export default function ExteriorScanPage() {
  const [photos, setPhotos] = useState<File[]>([])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="container max-w-3xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/home-scan">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Exterior Assessment</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Progress: 10%</span>
          <Progress value={10} className="w-24" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Roof Condition</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>What is the overall condition of your roof?</Label>
            <RadioGroup defaultValue="good">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="excellent" id="roof-excellent" />
                <Label htmlFor="roof-excellent">Excellent - Like new, no visible issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="good" id="roof-good" />
                <Label htmlFor="roof-good">Good - Minor wear, no apparent issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="fair" id="roof-fair" />
                <Label htmlFor="roof-fair">Fair - Some visible wear, may need attention soon</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="poor" id="roof-poor" />
                <Label htmlFor="roof-poor">Poor - Significant wear or damage, needs attention</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="unknown" id="roof-unknown" />
                <Label htmlFor="roof-unknown">I don't know</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>Have you noticed any leaks or water damage?</Label>
            <RadioGroup defaultValue="no">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="leaks-yes" />
                <Label htmlFor="leaks-yes">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="leaks-no" />
                <Label htmlFor="leaks-no">No</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="unsure" id="leaks-unsure" />
                <Label htmlFor="leaks-unsure">Not sure</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>Additional notes about your roof (optional)</Label>
            <Textarea placeholder="Enter any additional information about your roof..." />
          </div>

          <div className="space-y-2">
            <Label>Upload photos of your roof (optional)</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here or click to browse</p>
                <Button variant="outline" size="sm" className="relative">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photos
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={handlePhotoUpload}
                  />
                </Button>
              </div>
              {photos.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium">{photos.length} photo(s) selected</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Save Progress</Button>
          <Link href="/home-scan/exterior/siding">
            <Button className="bg-orange-500 hover:bg-orange-600">
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

