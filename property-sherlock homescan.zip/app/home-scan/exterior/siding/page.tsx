"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Camera, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"

export default function SidingScanPage() {
  const [photos, setPhotos] = useState<File[]>([])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="container max-w-3xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/home-scan/exterior">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Exterior Assessment</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Progress: 15%</span>
          <Progress value={15} className="w-24" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Siding & Exterior Walls</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>What type of siding/exterior finish does your home have?</Label>
            <RadioGroup defaultValue="vinyl">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="vinyl" id="siding-vinyl" />
                <Label htmlFor="siding-vinyl">Vinyl siding</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="wood" id="siding-wood" />
                <Label htmlFor="siding-wood">Wood siding</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="brick" id="siding-brick" />
                <Label htmlFor="siding-brick">Brick</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="stucco" id="siding-stucco" />
                <Label htmlFor="siding-stucco">Stucco</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="fiber-cement" id="siding-fiber-cement" />
                <Label htmlFor="siding-fiber-cement">Fiber cement (Hardie board)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="siding-other" />
                <Label htmlFor="siding-other">Other/Mixed</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>What is the condition of your siding/exterior walls?</Label>
            <RadioGroup defaultValue="good">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="excellent" id="condition-excellent" />
                <Label htmlFor="condition-excellent">Excellent - Like new</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="good" id="condition-good" />
                <Label htmlFor="condition-good">Good - Minor wear</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="fair" id="condition-fair" />
                <Label htmlFor="condition-fair">Fair - Some visible issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="poor" id="condition-poor" />
                <Label htmlFor="condition-poor">Poor - Significant damage</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>Have you noticed any of the following issues? (Check all that apply)</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-cracks" />
                <Label htmlFor="issue-cracks">Cracks or gaps</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-rot" />
                <Label htmlFor="issue-rot">Rot or decay</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-mold" />
                <Label htmlFor="issue-mold">Mold or mildew</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-peeling" />
                <Label htmlFor="issue-peeling">Peeling paint</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-loose" />
                <Label htmlFor="issue-loose">Loose or missing pieces</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-none" />
                <Label htmlFor="issue-none">No issues noticed</Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Additional notes about your exterior walls (optional)</Label>
            <Textarea placeholder="Enter any additional information about your exterior walls..." />
          </div>

          <div className="space-y-2">
            <Label>Upload photos of your exterior walls (optional)</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here or click to browse</p>
                <Button variant="outline" size="sm" className="relative">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photos
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={handlePhotoUpload}
                  />
                </Button>
              </div>
              {photos.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium">{photos.length} photo(s) selected</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Save Progress</Button>
          <Link href="/home-scan/interior">
            <Button className="bg-orange-500 hover:bg-orange-600">
              Next Section: Interior
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

