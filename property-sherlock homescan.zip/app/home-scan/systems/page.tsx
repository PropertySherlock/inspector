"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Camera, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SystemsScanPage() {
  const [photos, setPhotos] = useState<File[]>([])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="container max-w-3xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/home-scan/interior">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Systems Assessment</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Progress: 60%</span>
          <Progress value={60} className="w-24" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>HVAC System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>What type of heating system do you have?</Label>
            <RadioGroup defaultValue="forced-air">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="forced-air" id="heating-forced-air" />
                <Label htmlFor="heating-forced-air">Forced air furnace</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="heat-pump" id="heating-heat-pump" />
                <Label htmlFor="heating-heat-pump">Heat pump</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="boiler" id="heating-boiler" />
                <Label htmlFor="heating-boiler">Boiler (radiators/baseboard)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="electric" id="heating-electric" />
                <Label htmlFor="heating-electric">Electric baseboard</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="heating-other" />
                <Label htmlFor="heating-other">Other</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>How old is your HVAC system?</Label>
            <Select defaultValue="5-10">
              <SelectTrigger>
                <SelectValue placeholder="Select age range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-5">Less than 5 years</SelectItem>
                <SelectItem value="5-10">5-10 years</SelectItem>
                <SelectItem value="10-15">10-15 years</SelectItem>
                <SelectItem value="15-20">15-20 years</SelectItem>
                <SelectItem value="20+">More than 20 years</SelectItem>
                <SelectItem value="unknown">I don't know</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>When was the last time your HVAC system was serviced?</Label>
            <Select defaultValue="1-2">
              <SelectTrigger>
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-1">Within the last year</SelectItem>
                <SelectItem value="1-2">1-2 years ago</SelectItem>
                <SelectItem value="2-5">2-5 years ago</SelectItem>
                <SelectItem value="5+">More than 5 years ago</SelectItem>
                <SelectItem value="never">Never</SelectItem>
                <SelectItem value="unknown">I don't know</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Have you experienced any of the following issues? (Check all that apply)</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-uneven" />
                <Label htmlFor="issue-uneven">Uneven heating/cooling</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-noise" />
                <Label htmlFor="issue-noise">Unusual noises</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-efficiency" />
                <Label htmlFor="issue-efficiency">Poor efficiency/high bills</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-breakdown" />
                <Label htmlFor="issue-breakdown">Frequent breakdowns</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="issue-none" />
                <Label htmlFor="issue-none">No issues</Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Upload photos of your HVAC system (optional)</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here or click to browse</p>
                <Button variant="outline" size="sm" className="relative">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photos
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={handlePhotoUpload}
                  />
                </Button>
              </div>
              {photos.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium">{photos.length} photo(s) selected</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Save Progress</Button>
          <Link href="/home-scan/summary">
            <Button className="bg-orange-500 hover:bg-orange-600">
              Next: Summary
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

