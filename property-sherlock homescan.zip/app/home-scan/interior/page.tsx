"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Camera, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

export default function InteriorScanPage() {
  const [photos, setPhotos] = useState<File[]>([])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos(Array.from(e.target.files))
    }
  }

  return (
    <div className="container max-w-3xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/home-scan/exterior/siding">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Interior Assessment</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Progress: 30%</span>
          <Progress value={30} className="w-24" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Walls & Ceilings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Have you noticed any cracks in your walls or ceilings?</Label>
            <RadioGroup defaultValue="minor">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="none" id="cracks-none" />
                <Label htmlFor="cracks-none">No cracks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="minor" id="cracks-minor" />
                <Label htmlFor="cracks-minor">Minor hairline cracks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="moderate" id="cracks-moderate" />
                <Label htmlFor="cracks-moderate">Moderate cracks (1/8" to 1/4")</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="severe" id="cracks-severe" />
                <Label htmlFor="cracks-severe">Severe cracks (larger than 1/4")</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>Have you noticed any water stains on walls or ceilings?</Label>
            <RadioGroup defaultValue="no">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="stains-yes" />
                <Label htmlFor="stains-yes">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="stains-no" />
                <Label htmlFor="stains-no">No</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="unsure" id="stains-unsure" />
                <Label htmlFor="stains-unsure">Not sure</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>When was the last time the interior was painted?</Label>
            <Select defaultValue="3-5">
              <SelectTrigger>
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-1">Within the last year</SelectItem>
                <SelectItem value="1-3">1-3 years ago</SelectItem>
                <SelectItem value="3-5">3-5 years ago</SelectItem>
                <SelectItem value="5-10">5-10 years ago</SelectItem>
                <SelectItem value="10+">More than 10 years ago</SelectItem>
                <SelectItem value="unknown">I don't know</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Additional notes about your walls and ceilings (optional)</Label>
            <Textarea placeholder="Enter any additional information about your walls and ceilings..." />
          </div>

          <div className="space-y-2">
            <Label>Upload photos of any concerning areas (optional)</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here or click to browse</p>
                <Button variant="outline" size="sm" className="relative">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photos
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={handlePhotoUpload}
                  />
                </Button>
              </div>
              {photos.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium">{photos.length} photo(s) selected</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Save Progress</Button>
          <Link href="/home-scan/systems">
            <Button className="bg-orange-500 hover:bg-orange-600">
              Next Section: Systems
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

