"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Calendar, Camera, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

// This would come from an API in a real application
const scanCategories = [
  {
    id: "exterior",
    name: "Exterior",
    sections: [
      {
        id: "roof",
        title: "Roof Condition",
        questions: [
          {
            id: "roof-condition",
            type: "radio",
            label: "What is the overall condition of your roof?",
            options: [
              { value: "excellent", label: "Excellent - Like new, no visible issues" },
              { value: "good", label: "Good - Minor wear, no apparent issues" },
              { value: "fair", label: "Fair - Some visible wear, may need attention soon" },
              { value: "poor", label: "Poor - Significant wear or damage, needs attention" },
            ],
            defaultValue: "good",
          },
          {
            id: "roof-leaks",
            type: "radio",
            label: "Have you noticed any leaks or water damage?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
              { value: "unsure", label: "Not sure" },
            ],
            defaultValue: "no",
          },
          {
            id: "roof-notes",
            type: "textarea",
            label: "Additional notes about your roof",
            placeholder: "Enter any additional information about your roof...",
          },
          {
            id: "roof-photos",
            type: "photo",
            label: "Upload photos of your roof",
          },
        ],
      },
      {
        id: "siding",
        title: "Siding & Exterior Walls",
        questions: [
          {
            id: "siding-condition",
            type: "radio",
            label: "What is the condition of your siding/exterior walls?",
            options: [
              { value: "excellent", label: "Excellent - Like new" },
              { value: "good", label: "Good - Minor wear" },
              { value: "fair", label: "Fair - Some visible issues" },
              { value: "poor", label: "Poor - Significant damage" },
            ],
            defaultValue: "good",
          },
          {
            id: "siding-material",
            type: "text",
            label: "What material is your siding made of?",
            placeholder: "e.g., vinyl, wood, brick, stucco",
          },
          {
            id: "siding-notes",
            type: "textarea",
            label: "Additional notes about your exterior walls",
            placeholder: "Enter any additional information about your exterior walls...",
          },
          {
            id: "siding-photos",
            type: "photo",
            label: "Upload photos of your exterior walls",
          },
        ],
      },
    ],
  },
  {
    id: "interior",
    name: "Interior",
    sections: [
      {
        id: "walls",
        title: "Walls & Ceilings",
        questions: [
          {
            id: "walls-cracks",
            type: "radio",
            label: "Have you noticed any cracks in your walls or ceilings?",
            options: [
              { value: "none", label: "No cracks" },
              { value: "minor", label: "Minor hairline cracks" },
              { value: "moderate", label: 'Moderate cracks (1/8" to 1/4")' },
              { value: "severe", label: 'Severe cracks (larger than 1/4")' },
            ],
            defaultValue: "minor",
          },
          {
            id: "walls-stains",
            type: "radio",
            label: "Have you noticed any water stains on walls or ceilings?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
            ],
            defaultValue: "no",
          },
          {
            id: "walls-location",
            type: "text",
            label: "If you have cracks or stains, where are they located?",
            placeholder: "e.g., master bedroom ceiling, living room wall",
          },
          {
            id: "walls-notes",
            type: "textarea",
            label: "Additional notes about your walls and ceilings",
            placeholder: "Enter any additional information about your walls and ceilings...",
          },
          {
            id: "walls-photos",
            type: "photo",
            label: "Upload photos of any concerning areas",
          },
        ],
      },
      {
        id: "floors",
        title: "Floors",
        questions: [
          {
            id: "floors-condition",
            type: "radio",
            label: "What is the overall condition of your floors?",
            options: [
              { value: "excellent", label: "Excellent - Like new" },
              { value: "good", label: "Good - Minor wear" },
              { value: "fair", label: "Fair - Some visible issues" },
              { value: "poor", label: "Poor - Significant damage" },
            ],
            defaultValue: "good",
          },
          {
            id: "floors-type",
            type: "text",
            label: "What type of flooring do you have in most rooms?",
            placeholder: "e.g., hardwood, carpet, tile, laminate",
          },
          {
            id: "floors-notes",
            type: "textarea",
            label: "Additional notes about your floors",
            placeholder: "Enter any additional information about your floors...",
          },
          {
            id: "floors-photos",
            type: "photo",
            label: "Upload photos of your floors",
          },
        ],
      },
    ],
  },
  {
    id: "systems",
    name: "Systems",
    sections: [
      {
        id: "hvac",
        title: "HVAC System",
        questions: [
          {
            id: "hvac-condition",
            type: "radio",
            label: "What is the overall condition of your HVAC system?",
            options: [
              { value: "excellent", label: "Excellent - Like new, no issues" },
              { value: "good", label: "Good - Working well, minor wear" },
              { value: "fair", label: "Fair - Working but showing age" },
              { value: "poor", label: "Poor - Not working properly" },
            ],
            defaultValue: "good",
          },
          {
            id: "hvac-age",
            type: "text",
            label: "How old is your HVAC system?",
            placeholder: "e.g., 5 years, 10+ years",
          },
          {
            id: "hvac-notes",
            type: "textarea",
            label: "Additional notes about your HVAC system",
            placeholder: "Enter any additional information about your HVAC system...",
          },
          {
            id: "hvac-photos",
            type: "photo",
            label: "Upload photos of your HVAC system",
          },
        ],
      },
      {
        id: "plumbing",
        title: "Plumbing",
        questions: [
          {
            id: "plumbing-issues",
            type: "radio",
            label: "Have you noticed any leaks or water pressure issues?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
            ],
            defaultValue: "no",
          },
          {
            id: "plumbing-details",
            type: "text",
            label: "If you have plumbing issues, please describe them",
            placeholder: "e.g., slow drain in master bath, low pressure in kitchen",
          },
          {
            id: "plumbing-notes",
            type: "textarea",
            label: "Additional notes about your plumbing",
            placeholder: "Enter any additional information about your plumbing...",
          },
          {
            id: "plumbing-photos",
            type: "photo",
            label: "Upload photos of any plumbing concerns",
          },
        ],
      },
      {
        id: "electrical",
        title: "Electrical",
        questions: [
          {
            id: "electrical-issues",
            type: "radio",
            label: "Have you experienced any electrical issues?",
            options: [
              { value: "yes", label: "Yes" },
              { value: "no", label: "No" },
            ],
            defaultValue: "no",
          },
          {
            id: "electrical-details",
            type: "text",
            label: "If you have electrical issues, please describe them",
            placeholder: "e.g., flickering lights, circuit breaker trips frequently",
          },
          {
            id: "electrical-notes",
            type: "textarea",
            label: "Additional notes about your electrical system",
            placeholder: "Enter any additional information about your electrical system...",
          },
          {
            id: "electrical-photos",
            type: "photo",
            label: "Upload photos of electrical panel or concerns",
          },
        ],
      },
    ],
  },
]

export default function HomeScanPage() {
  const [activeCategory, setActiveCategory] = useState(scanCategories[0].id)
  const [progress, setProgress] = useState(0)
  const [photos, setPhotos] = useState<Record<string, File[]>>({})
  const [formData, setFormData] = useState<Record<string, any>>({})

  const handlePhotoUpload = (questionId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos((prev) => ({
        ...prev,
        [questionId]: Array.from(e.target.files || []),
      }))

      // Update progress when photos are added
      updateProgress()
    }
  }

  const handleInputChange = (questionId: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [questionId]: value,
    }))

    // Update progress when inputs change
    updateProgress()
  }

  const updateProgress = () => {
    // Simple progress calculation - can be made more sophisticated
    const totalQuestions = scanCategories.flatMap((category) =>
      category.sections.flatMap((section) => section.questions),
    ).length

    const answeredQuestions = Object.keys(formData).length + Object.keys(photos).length
    setProgress(Math.round((answeredQuestions / totalQuestions) * 100))
  }

  const handleSave = () => {
    // Save functionality would go here
    alert("Progress saved!")
  }

  const handleComplete = () => {
    // Complete functionality would go here
    window.location.href = "/dashboard"
  }

  const renderQuestion = (question: any) => {
    switch (question.type) {
      case "radio":
        return (
          <div className="space-y-3" key={question.id}>
            <Label className="text-base font-medium">{question.label}</Label>
            <RadioGroup
              defaultValue={question.defaultValue}
              onValueChange={(value) => handleInputChange(question.id, value)}
              className="space-y-2"
            >
              {question.options.map((option: any) => (
                <div
                  className="flex items-center space-x-3 rounded-lg border p-4 cursor-pointer hover:bg-gray-50"
                  key={option.value}
                >
                  <RadioGroupItem value={option.value} id={`${question.id}-${option.value}`} className="mt-0.5" />
                  <Label htmlFor={`${question.id}-${option.value}`} className="flex-grow cursor-pointer font-normal">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        )

      case "text":
        return (
          <div className="space-y-3" key={question.id}>
            <Label className="text-base font-medium">{question.label}</Label>
            <Input
              placeholder={question.placeholder}
              onChange={(e) => handleInputChange(question.id, e.target.value)}
              className="h-12"
            />
          </div>
        )

      case "textarea":
        return (
          <div className="space-y-3" key={question.id}>
            <Label className="text-base font-medium">{question.label}</Label>
            <Textarea
              placeholder={question.placeholder}
              onChange={(e) => handleInputChange(question.id, e.target.value)}
              className="min-h-[120px] resize-none placeholder:text-gray-400"
            />
          </div>
        )

      case "photo":
        return (
          <div className="space-y-3" key={question.id}>
            <Label className="text-base font-medium">{question.label}</Label>
            <div
              className="relative rounded-lg border-2 border-dashed p-8 text-center hover:bg-gray-50 transition-colors cursor-pointer"
              onClick={() => document.getElementById(`photo-upload-${question.id}`)?.click()}
            >
              <input
                id={`photo-upload-${question.id}`}
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                onChange={(e) => handlePhotoUpload(question.id, e)}
              />
              <div className="mx-auto flex max-w-[420px] flex-col items-center gap-3">
                <div className="rounded-full bg-gray-100 p-4">
                  <Camera className="h-6 w-6 text-gray-400" />
                </div>
                <div>
                  <p className="text-base font-medium">Upload photos</p>
                  <p className="text-sm text-gray-400">Drag and drop or click to browse</p>
                </div>
              </div>
              {photos[question.id]?.length > 0 && (
                <div className="mt-6 flex items-center justify-center gap-2">
                  <div className="rounded-full bg-orange-50 p-1">
                    <Check className="h-4 w-4 text-orange-500" />
                  </div>
                  <p className="text-sm text-gray-600">
                    {photos[question.id].length} photo{photos[question.id].length > 1 ? "s" : ""} selected
                  </p>
                </div>
              )}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="container max-w-5xl py-6 space-y-6 pb-24">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" className="rounded-full">
                <ArrowLeft className="h-5 w-5" />
                <span className="sr-only">Back to Dashboard</span>
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">HomeScan</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Progress: {progress}%</span>
              <Progress value={progress} className="w-24" />
            </div>
            <Button variant="outline" onClick={handleSave}>
              Save Progress
            </Button>
            <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleComplete}>
              <Check className="mr-2 h-4 w-4" />
              Complete HomeScan
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-4">
        <div className="sticky top-0 z-10 bg-background pt-2 pb-4">
          <TabsList className="grid w-full grid-cols-3 h-auto p-1">
            {scanCategories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="py-3 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700"
              >
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {scanCategories.map((category) => (
          <TabsContent key={category.id} value={category.id} className="space-y-6">
            {category.sections.map((section) => (
              <Card key={section.id}>
                <CardHeader>
                  <CardTitle>{section.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {section.questions.map((question) => renderQuestion(question))}
                </CardContent>
                {section.id === category.sections[category.sections.length - 1].id && (
                  <CardFooter className="flex justify-between">
                    {category.id !== scanCategories[0].id && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          const currentIndex = scanCategories.findIndex((c) => c.id === category.id)
                          if (currentIndex > 0) {
                            setActiveCategory(scanCategories[currentIndex - 1].id)
                          }
                        }}
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to{" "}
                        {
                          scanCategories.find(
                            (c, i) => scanCategories.findIndex((cat) => cat.id === category.id) - 1 === i,
                          )?.name
                        }
                      </Button>
                    )}
                    {category.id !== scanCategories[scanCategories.length - 1].id ? (
                      <Button
                        className="bg-orange-500 hover:bg-orange-600 ml-auto"
                        onClick={() => {
                          const currentIndex = scanCategories.findIndex((c) => c.id === category.id)
                          if (currentIndex < scanCategories.length - 1) {
                            setActiveCategory(scanCategories[currentIndex + 1].id)
                          }
                        }}
                      >
                        Next:{" "}
                        {
                          scanCategories.find(
                            (c, i) => scanCategories.findIndex((cat) => cat.id === category.id) + 1 === i,
                          )?.name
                        }
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button className="bg-orange-500 hover:bg-orange-600 ml-auto" onClick={handleComplete}>
                        <Check className="mr-2 h-4 w-4" />
                        Complete HomeScan
                      </Button>
                    )}
                  </CardFooter>
                )}
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>

      {/* Floating CTA for scheduling an inspector */}
      <div className="fixed bottom-0 left-0 right-0 z-50">
        <div className="container max-w-5xl mx-auto px-4 pb-4">
          <div className="bg-orange-50 border border-orange-100 rounded-lg shadow-lg p-3 md:p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3 md:gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-orange-500 shrink-0" />
              <div>
                <h3 className="font-medium text-orange-800 text-sm md:text-base">Want a Professional Assessment?</h3>
                <p className="text-xs md:text-sm text-orange-700 hidden md:block">
                  Schedule a certified inspector to perform a comprehensive home inspection.
                </p>
              </div>
            </div>
            <Button
              className="bg-orange-500 hover:bg-orange-600 text-white whitespace-nowrap"
              onClick={() => (window.location.href = "/schedule-inspector")}
            >
              Schedule an Inspector
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

