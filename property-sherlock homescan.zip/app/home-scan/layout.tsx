import type React from "react"
export default function HomeScanLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <main className="min-h-screen bg-gray-50 pb-20">{children}</main>
}

