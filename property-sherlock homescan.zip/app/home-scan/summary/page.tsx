"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Calendar, Check, CheckCircle2, Clock, Download, Home } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SummaryPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = () => {
    setIsSubmitting(true)
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      window.location.href = "/dashboard"
    }, 2000)
  }

  return (
    <div className="container max-w-4xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/home-scan/systems">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">HomeScan Summary</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Progress: 95%</span>
          <Progress value={95} className="w-24" />
        </div>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader className="bg-green-50 rounded-t-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-6 w-6 text-green-600" />
            <CardTitle className="text-xl text-green-700">HomeScan Complete!</CardTitle>
          </div>
          <CardDescription>
            Thank you for completing your HomeScan. Here's a summary of your assessment.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Tabs defaultValue="summary">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="issues">Potential Issues</TabsTrigger>
              <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            </TabsList>
            <TabsContent value="summary" className="pt-4 space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Home className="h-4 w-4" />
                      Exterior
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        Roof in good condition
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        Vinyl siding in good condition
                      </li>
                      <li className="flex items-center gap-2 text-amber-600">
                        <span className="h-1 w-1 rounded-full bg-amber-600 inline-block mt-1"></span>
                        Minor cracks noted
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Home className="h-4 w-4" />
                      Interior
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        Walls in good condition
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        No water damage detected
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        Interior paint 3-5 years old
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Home className="h-4 w-4" />
                      Systems
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        HVAC system 5-10 years old
                      </li>
                      <li className="flex items-center gap-2 text-amber-600">
                        <span className="h-1 w-1 rounded-full bg-amber-600 inline-block mt-1"></span>
                        Last serviced 1-2 years ago
                      </li>
                      <li className="flex items-center gap-2 text-amber-600">
                        <span className="h-1 w-1 rounded-full bg-amber-600 inline-block mt-1"></span>
                        Uneven heating reported
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="rounded-lg bg-blue-50 p-4 border border-blue-100">
                <h3 className="font-medium text-blue-800">Want a Professional Assessment?</h3>
                <p className="text-sm text-blue-700 mt-1">
                  While your self-assessment provides valuable insights, a professional inspector can provide a more
                  detailed evaluation.
                </p>
                <Button
                  variant="outline"
                  className="mt-2 bg-white text-blue-700 border-blue-200 hover:bg-blue-50 hover:text-blue-800"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule an Inspector
                </Button>
              </div>
            </TabsContent>
            <TabsContent value="issues" className="pt-4 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Potential Issues Identified</CardTitle>
                  <CardDescription>
                    Based on your responses, we've identified the following potential issues:
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="pb-4 border-b">
                      <div className="font-medium">Minor cracks in exterior siding</div>
                      <p className="text-sm text-muted-foreground mt-1">
                        You reported minor cracks in your vinyl siding. These should be addressed to prevent water
                        infiltration.
                      </p>
                    </li>
                    <li className="pb-4 border-b">
                      <div className="font-medium">HVAC maintenance overdue</div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Your HVAC system was last serviced 1-2 years ago. Annual maintenance is recommended.
                      </p>
                    </li>
                    <li>
                      <div className="font-medium">Uneven heating/cooling</div>
                      <p className="text-sm text-muted-foreground mt-1">
                        You reported uneven heating in your home, which could indicate ductwork issues or an improperly
                        sized system.
                      </p>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="recommendations" className="pt-4 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Recommended Actions</CardTitle>
                  <CardDescription>Here are our recommendations based on your HomeScan results:</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="pb-4 border-b">
                      <div className="font-medium flex items-center gap-2">
                        <Clock className="h-4 w-4 text-orange-500" />
                        Schedule HVAC maintenance
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Book a professional HVAC technician to service your system and address the uneven heating
                        issues.
                      </p>
                      <div className="mt-2">
                        <Button size="sm" variant="outline">
                          Find a Pro
                        </Button>
                      </div>
                    </li>
                    <li className="pb-4 border-b">
                      <div className="font-medium flex items-center gap-2">
                        <Clock className="h-4 w-4 text-orange-500" />
                        Repair exterior siding cracks
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Seal and repair the minor cracks in your vinyl siding to prevent water damage.
                      </p>
                      <div className="mt-2">
                        <Button size="sm" variant="outline">
                          Find a Pro
                        </Button>
                      </div>
                    </li>
                    <li>
                      <div className="font-medium flex items-center gap-2">
                        <Clock className="h-4 w-4 text-green-500" />
                        Regular maintenance reminder
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        We've added these items to your maintenance schedule. You'll receive reminders when it's time to
                        address them.
                      </p>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between pt-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download Report
          </Button>
          <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Submitting..." : "Complete HomeScan"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

