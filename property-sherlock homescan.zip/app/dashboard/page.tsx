import Link from "next/link"
import { ArrowRight, CheckCircle, Home, Search, PenToolIcon as Tool } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function DashboardPage() {
  // This would come from your database in a real app
  const homeScanProgress = 0 // 0 for not started, or a percentage for in progress
  const address = "39600 Fremont Blvd, Fremont, California"
  const homeScore = 0
  const maxScore = 100

  return (
    <div className="container max-w-5xl py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Home className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-xl font-semibold">{address}</h2>
        </div>
        <Button variant="outline" size="sm">
          Change
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Home Score</CardTitle>
          </CardHeader>
          <CardContent className="pb-2">
            <div className="flex justify-center">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle
                    className="text-muted-foreground/20 stroke-current"
                    strokeWidth="10"
                    fill="transparent"
                    r="40"
                    cx="50"
                    cy="50"
                  />
                  <circle
                    className="text-orange-500 stroke-current"
                    strokeWidth="10"
                    strokeLinecap="round"
                    fill="transparent"
                    r="40"
                    cx="50"
                    cy="50"
                    strokeDasharray={`${(homeScore / maxScore) * 251.2} 251.2`}
                    strokeDashoffset="0"
                    transform="rotate(-90 50 50)"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-4xl font-bold">{homeScore}</div>
                </div>
              </div>
            </div>
            <div className="text-center text-sm text-muted-foreground mt-2">of {maxScore}</div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Search className="h-4 w-4" />
                HomeScan
              </CardTitle>
              {homeScanProgress > 0 && homeScanProgress < 100 && (
                <Link href="/home-scan">
                  <Button variant="ghost" size="sm" className="gap-1">
                    Continue
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </Link>
              )}
            </div>
            <CardDescription>Complete your home profile</CardDescription>
          </CardHeader>
          <CardContent className="pb-2 space-y-4">
            <p className="text-sm">
              Get a comprehensive scan of your home to identify potential issues and customize your maintenance plan.
            </p>
            {homeScanProgress > 0 ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Completion</span>
                  <span>{homeScanProgress}%</span>
                </div>
                <Progress value={homeScanProgress} />
              </div>
            ) : (
              <Link href="/home-scan">
                <Button className="w-full bg-orange-500 hover:bg-orange-600">
                  Start HomeScan Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">To-do's</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1">
              <span className="bg-orange-500 text-white text-xs px-1.5 py-0.5 rounded-full">22</span>
              Due soon
            </Button>
            <Button variant="ghost" size="sm">
              Past due
            </Button>
          </div>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="p-4 border-b">
              <div className="flex items-start gap-3">
                <div className="flex h-5 w-5 items-center justify-center rounded-full border">
                  <CheckCircle className="h-4 w-4 text-muted-foreground/40" />
                </div>
                <div className="space-y-1">
                  <div>
                    <span className="text-xs text-muted-foreground">DUE MAR 27</span>
                    <h3 className="font-semibold">Replace your air filter</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium">
                      Easy
                    </span>
                    <span className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium">
                      10 minutes
                    </span>
                  </div>
                </div>
                <div className="ml-auto flex gap-2">
                  <Button variant="outline" size="sm" className="text-orange-500 border-orange-200">
                    <Tool className="h-4 w-4 mr-1" />
                    Get Help
                  </Button>
                  <Button variant="ghost" size="sm">
                    Details
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-5 w-5 items-center justify-center rounded-full border">
                  <CheckCircle className="h-4 w-4 text-muted-foreground/40" />
                </div>
                <div className="space-y-1">
                  <div>
                    <span className="text-xs text-muted-foreground">DUE MAR 29</span>
                    <h3 className="font-semibold">Clean your cooktop</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium">
                      Easy
                    </span>
                    <span className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium">
                      15 minutes
                    </span>
                  </div>
                </div>
                <div className="ml-auto flex gap-2">
                  <Button variant="outline" size="sm" className="text-orange-500 border-orange-200">
                    <Tool className="h-4 w-4 mr-1" />
                    Get Help
                  </Button>
                  <Button variant="ghost" size="sm">
                    Details
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

