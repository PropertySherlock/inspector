import Link from "next/link"
import { Home, Search, Tag } from "lucide-react"

export function Navigation() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2">
      <Link href="/dashboard" className="flex flex-col items-center p-2 text-primary">
        <Home className="h-6 w-6" />
        <span className="text-xs mt-1">Maintenance</span>
      </Link>
      <Link href="/inspections" className="flex flex-col items-center p-2 text-gray-500">
        <Search className="h-6 w-6" />
        <span className="text-xs mt-1">Inspections</span>
      </Link>
      <Link href="/offers" className="flex flex-col items-center p-2 text-gray-500">
        <Tag className="h-6 w-6" />
        <span className="text-xs mt-1">Offers</span>
      </Link>
    </nav>
  )
}

