"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, Check, Users } from "lucide-react"
import Link from "next/link"

type Task = {
  id: string
  title: string
  dueDate: string
  difficulty: "Easy" | "Medium" | "Hard"
  duration: string
  completed: boolean
}

export function MaintenanceTasks() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Replace your air filter",
      dueDate: "MAR 27",
      difficulty: "Easy",
      duration: "10 minutes",
      completed: false,
    },
    {
      id: "2",
      title: "Clean your cooktop",
      dueDate: "MAR 29",
      difficulty: "Easy",
      duration: "15 minutes",
      completed: false,
    },
    {
      id: "3",
      title: "Inspect your exterior walls",
      dueDate: "MAR 30",
      difficulty: "Easy",
      duration: "10 minutes",
      completed: false,
    },
  ])

  const toggleTaskCompletion = (taskId: string) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
  }

  return (
    <div className="mb-20">
      <h2 className="text-xl font-bold mb-3">To-do's</h2>

      <div className="flex mb-3 border rounded-lg overflow-hidden">
        <button className="flex-1 py-2 bg-white border-b-2 border-primary font-medium text-sm">
          Due soon <span className="inline-block bg-primary text-white rounded-full px-2 py-0.5 text-xs ml-1">22</span>
        </button>
        <button className="flex-1 py-2 bg-gray-100 text-gray-500 text-sm">Past due</button>
      </div>

      <div className="space-y-3">
        {tasks.map((task) => (
          <Card
            key={task.id}
            className={`hover:shadow-md transition-shadow ${task.completed ? "bg-gray-50 border-gray-200" : ""}`}
          >
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-start">
                <button
                  onClick={() => toggleTaskCompletion(task.id)}
                  className={`mt-1 mr-3 flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 rounded-full border ${
                    task.completed
                      ? "bg-primary border-primary text-white flex items-center justify-center"
                      : "border-gray-300"
                  }`}
                  aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
                >
                  {task.completed && <Check className="h-3 w-3 sm:h-4 sm:w-4" />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-xs sm:text-sm text-gray-500 mb-1">DUE {task.dueDate}</div>
                  <h3
                    className={`text-base sm:text-lg font-semibold mb-2 ${task.completed ? "line-through text-gray-500" : ""} truncate`}
                  >
                    {task.title}
                  </h3>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap gap-2 mb-2 sm:mb-0">
                      <span className="bg-gray-200 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                        {task.difficulty}
                      </span>
                      <span className="bg-gray-200 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                        {task.duration}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-3 w-full sm:w-auto">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center text-primary border-primary text-xs sm:text-sm flex-1 sm:flex-none justify-center sm:justify-start"
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Get Help
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-primary text-xs sm:text-sm flex-1 sm:flex-none justify-center sm:justify-start"
                        asChild
                      >
                        <Link href={`/tasks/${task.id}`} className="flex items-center">
                          Details
                          <ChevronRight className="h-4 w-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center mt-4">
        <Link href="/tasks" className="text-primary font-medium hover:underline">
          See all
        </Link>
      </div>
    </div>
  )
}

