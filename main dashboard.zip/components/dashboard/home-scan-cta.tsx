import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, ArrowRight } from "lucide-react"

export function HomeScanCTA() {
  return (
    <Card className="border mb-4">
      <CardHeader className="bg-gray-50 pb-2 pt-3 px-4">
        <CardTitle className="text-gray-900 flex items-center text-lg">
          <Search className="mr-2 h-4 w-4 text-primary flex-shrink-0" />
          HomeScan
        </CardTitle>
        <CardDescription>Complete your home profile</CardDescription>
      </CardHeader>
      <CardContent className="pt-3 pb-2 px-4">
        <p className="text-xs mb-3 text-gray-700">
          Get a comprehensive scan of your home to identify potential issues and customize your maintenance plan.
        </p>
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-gray-700">Completion</span>
          <span className="font-bold text-gray-900">0%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-primary h-2 rounded-full" style={{ width: "0%" }}></div>
        </div>
      </CardContent>
      <CardFooter className="pt-2 pb-3 px-4">
        <Button className="w-full flex items-center justify-center text-sm">
          Start HomeScan Now <ArrowRight className="ml-2 h-3 w-3" />
        </Button>
      </CardFooter>
    </Card>
  )
}

