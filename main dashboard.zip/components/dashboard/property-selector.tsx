"use client"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ChevronDown, Home, Plus } from "lucide-react"

type Property = {
  id: string
  address: string
}

export function PropertySelector() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [properties, setProperties] = useState<Property[]>([])
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  useEffect(() => {
    // In a real app, you would get this from state management or API
    const storedAddress = localStorage.getItem("user_address") || ""
    const storedCity = localStorage.getItem("user_city") || ""
    const storedState = localStorage.getItem("user_state") || ""

    const defaultProperties = [
      { id: "1", address: storedAddress ? `${storedAddress}, ${storedCity}, ${storedState}` : "8100 Sky Mountain Ln" },
      { id: "2", address: "456 Park Ave, Springfield, IL" },
    ]

    setProperties(defaultProperties)
    setSelectedProperty(defaultProperties[0])

    // Close dropdown when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen)
  }

  const selectProperty = (property: Property) => {
    setSelectedProperty(property)
    setIsDropdownOpen(false)
  }

  const addNewProperty = () => {
    router.push("/add-property")
    setIsDropdownOpen(false)
  }

  if (!selectedProperty) return null

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <button
        onClick={toggleDropdown}
        className="flex items-center text-2xl font-bold w-full overflow-hidden text-ellipsis whitespace-nowrap"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <span className="truncate">{selectedProperty.address}</span>
        <ChevronDown
          className={`ml-2 h-5 w-5 flex-shrink-0 text-gray-500 transition-transform ${isDropdownOpen ? "rotate-180" : ""}`}
        />
      </button>

      {isDropdownOpen && (
        <div className="absolute top-full left-0 mt-1 w-full min-w-[300px] max-w-full bg-white border rounded-md shadow-lg z-10">
          <div className="py-1">
            {properties.map((property) => (
              <button
                key={property.id}
                className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center"
                onClick={() => selectProperty(property)}
              >
                <Home className="h-4 w-4 mr-2 text-gray-500 flex-shrink-0" />
                <span className="text-sm font-medium truncate">{property.address}</span>
              </button>
            ))}
            <div className="border-t my-1"></div>
            <button
              className="w-full text-left px-4 py-3 hover:bg-gray-100 text-primary flex items-center"
              onClick={addNewProperty}
            >
              <Plus className="h-4 w-4 mr-2 flex-shrink-0" />
              <span className="text-sm font-medium">Add New Property</span>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

