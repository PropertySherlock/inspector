"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function VerificationPage() {
  const router = useRouter()
  const [code, setCode] = useState("")
  const [error, setError] = useState("")
  const [countdown, setCountdown] = useState(30)
  const [email, setEmail] = useState("")

  useEffect(() => {
    // In a real app, you would get this from state management
    const storedEmail = localStorage.getItem("user_email") || ""
    setEmail(storedEmail)

    // Simulate sending verification code
    console.log("Verification code sent to", storedEmail)

    // Countdown for resend button
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0))
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, you would validate the code
    // For now, just proceed to the next step
    router.push("/onboarding/address")
  }

  const handleResend = () => {
    // Simulate resending verification code
    console.log("Resending verification code to", email)
    setCountdown(30)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Verify your email</CardTitle>
        <CardDescription>We've sent a 6-digit verification code to {email}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="code" className="text-sm font-medium">
              Verification Code
            </label>
            <Input
              id="code"
              placeholder="Enter 6-digit code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength={6}
              inputMode="numeric"
              pattern="[0-9]*"
              autoComplete="one-time-code"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="text-sm text-center">
            {countdown > 0 ? (
              <p className="text-gray-500">Resend code in {countdown} seconds</p>
            ) : (
              <button type="button" className="text-primary hover:underline" onClick={handleResend}>
                Resend verification code
              </button>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            Verify
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

