"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function AddressPage() {
  const router = useRouter()
  const [address, setAddress] = useState("")
  const [city, setCity] = useState("")
  const [state, setState] = useState("")
  const [zipCode, setZipCode] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!address || !city || !state || !zipCode) {
      setError("Please fill in all address fields")
      return
    }

    if (!/^\d{5}(-\d{4})?$/.test(zipCode)) {
      setError("Please enter a valid ZIP code")
      return
    }

    // In a real app, you would save this to state management or API
    localStorage.setItem("user_address", address)
    localStorage.setItem("user_city", city)
    localStorage.setItem("user_state", state)
    localStorage.setItem("user_zipCode", zipCode)

    router.push("/dashboard")
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>What's your home address?</CardTitle>
        <CardDescription>We'll use this to customize your maintenance plan</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="address" className="text-sm font-medium">
              Street Address
            </label>
            <Input
              id="address"
              placeholder="123 Main St"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="city" className="text-sm font-medium">
              City
            </label>
            <Input id="city" placeholder="Anytown" value={city} onChange={(e) => setCity(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="state" className="text-sm font-medium">
                State
              </label>
              <Input id="state" placeholder="CA" value={state} onChange={(e) => setState(e.target.value)} />
            </div>
            <div className="space-y-2">
              <label htmlFor="zipCode" className="text-sm font-medium">
                ZIP Code
              </label>
              <Input id="zipCode" placeholder="12345" value={zipCode} onChange={(e) => setZipCode(e.target.value)} />
            </div>
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            Complete Setup
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

