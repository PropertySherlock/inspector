import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { Bell, Zap, Shield } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    id: "home-devices",
    title: "Home Devices",
    icon: Bell,
    href: "/offers/home-devices",
  },
  {
    id: "energy-optimization",
    title: "Energy Optimization",
    icon: Zap,
    href: "/offers/energy",
  },
  {
    id: "home-warranty",
    title: "Home Warranty",
    icon: Shield,
    href: "/offers/warranty",
  },
]

const featuredOffers = [
  {
    id: "simplisafe",
    logo: "/placeholder.svg?height=40&width=120",
    image: "/placeholder.svg?height=300&width=500",
    title: "Get 24/7 protection with SimpliSafe",
    promotion: "Get 60% off + 10 health pts",
    description: "Save hundreds on an award winning home security system from SimpliSafe. No contracts.",
  },
  // Add more offers as needed
]

export default function OffersPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 container max-w-5xl mx-auto px-4 py-6 mb-20">
        <h1 className="text-2xl font-bold mb-6">Categories</h1>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-12">
          {categories.map((category) => {
            const Icon = category.icon
            return (
              <Link key={category.id} href={category.href}>
                <Card className="h-full hover:border-primary transition-colors">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center h-full">
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <h2 className="text-lg font-semibold">{category.title}</h2>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Best fit for you</h2>
          <p className="text-gray-600 mb-6">We've curated these offers for you based upon your home's profile.</p>

          <div className="space-y-6">
            {featuredOffers.map((offer) => (
              <Card key={offer.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="sm:flex">
                  <div className="sm:w-1/3 relative">
                    <Image
                      src={offer.image || "/placeholder.svg"}
                      alt=""
                      width={500}
                      height={300}
                      className="w-full h-48 sm:h-full object-cover"
                    />
                  </div>
                  <div className="p-6 sm:w-2/3">
                    <div className="mb-4">
                      <Image
                        src={offer.logo || "/placeholder.svg"}
                        alt=""
                        width={120}
                        height={40}
                        className="h-8 w-auto"
                      />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{offer.title}</h3>
                    <p className="text-primary font-semibold mb-2">{offer.promotion}</p>
                    <p className="text-gray-600">{offer.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

