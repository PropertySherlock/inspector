import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { UniversalHeader } from "@/components/universal-header"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Property Sherlock",
  description: "Your home maintenance assistant",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <UniversalHeader />
          <div className="flex-1">{children}</div>
        </div>
      </body>
    </html>
  )
}



import './globals.css'