"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, ArrowLeft, Users, ShoppingBag, Clock, BarChart, XCircle } from "lucide-react"
import Link from "next/link"

export default function TaskDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [completed, setCompleted] = useState(false)

  // This would come from an API in a real app
  const task = {
    id: params.id,
    title: "Replace your air filter",
    dueDate: "MAR 27",
    difficulty: "Easy",
    duration: "10 minutes",
    description:
      "Regularly replacing your HVAC air filter improves air quality and system efficiency. It's a simple task that can save you money on energy bills and prevent costly repairs.",
    steps: [
      "Turn off your HVAC system",
      "Locate your air filter (usually in the return air duct or at the air handler)",
      "Note the size and direction of airflow on the existing filter",
      "Remove the old filter and dispose of it",
      "Insert the new filter with the arrows pointing in the direction of airflow",
      "Secure the filter compartment cover if applicable",
      "Turn your HVAC system back on",
    ],
    materials: ["New air filter (check size: typically 16x20, 20x25, etc.)", "Optional: vacuum cleaner for dust"],
    tips: [
      "Set a reminder to check your filter every 30-90 days",
      "Consider upgrading to a higher MERV rating for better filtration",
      "If you have pets or allergies, you may need to replace filters more frequently",
    ],
  }

  const toggleComplete = () => {
    setCompleted(!completed)
  }

  const handleRemoveTask = () => {
    // In a real app, you would make an API call here
    router.push("/dashboard")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 p-4 pt-3 pb-20 container max-w-5xl mx-auto">
        <div className="mb-4">
          <Link href="/dashboard" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </div>

        <Card className="mb-6">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xl sm:text-2xl">{task.title}</CardTitle>
              <div className="text-xs sm:text-sm text-gray-500">Due {task.dueDate}</div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2 mb-4">
              <div className="flex items-center bg-gray-100 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                <BarChart className="h-3 w-3 sm:h-4 sm:w-4 mr-1 text-gray-600" />
                {task.difficulty}
              </div>
              <div className="flex items-center bg-gray-100 px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm">
                <Clock className="h-3 w-3 sm:h-4 sm:w-4 mr-1 text-gray-600" />
                {task.duration}
              </div>
            </div>

            <p className="text-sm sm:text-base text-gray-700 mb-6">{task.description}</p>

            <div className="space-y-6">
              <div>
                <h3 className="text-base sm:text-lg font-medium mb-3">Steps</h3>
                <ol className="space-y-2 pl-5 list-decimal text-sm sm:text-base">
                  {task.steps.map((step, index) => (
                    <li key={index} className="text-gray-700">
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-medium mb-3 flex items-center">
                  <ShoppingBag className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-gray-600" />
                  Materials Needed
                </h3>
                <ul className="space-y-2 pl-5 list-disc text-sm sm:text-base">
                  {task.materials.map((material, index) => (
                    <li key={index} className="text-gray-700">
                      {material}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-medium mb-3">Pro Tips</h3>
                <ul className="space-y-2 pl-5 list-disc text-sm sm:text-base">
                  {task.tips.map((tip, index) => (
                    <li key={index} className="text-gray-700">
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              className={`flex-1 ${completed ? "bg-gray-200 text-gray-700 hover:bg-gray-300" : ""}`}
              onClick={toggleComplete}
            >
              {completed ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Completed
                </>
              ) : (
                "Mark as Complete"
              )}
            </Button>
            <Button variant="outline" className="flex-1 border-gray-300 text-gray-700">
              <Users className="h-4 w-4 mr-2" />
              Get Professional Help
            </Button>
          </div>

          <Button
            variant="ghost"
            className="text-red-500 hover:text-red-600 hover:bg-red-50"
            onClick={handleRemoveTask}
          >
            <XCircle className="h-4 w-4 mr-2" />
            Not relevant to your home? Remove task
          </Button>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

