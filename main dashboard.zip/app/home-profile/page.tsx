import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronRight } from "lucide-react"
import Link from "next/link"

const profileSections = [
  {
    id: "basic",
    title: "Basic information",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "protection",
    title: "Protection",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "plumbing",
    title: "Plumbing",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "hvac",
    title: "HVAC",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "appliances",
    title: "Appliances",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "exterior",
    title: "Exterior",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
  {
    id: "interior",
    title: "Interior",
    icon: "/placeholder.svg?height=24&width=24",
    completed: false,
  },
]

export default function HomeProfilePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 p-4 pt-3">
        <h1 className="text-2xl font-bold mb-4">Home Profile</h1>
        <Card className="mb-20">
          <CardContent className="p-0">
            {profileSections.map((section, index) => (
              <Link href={`/home-profile/${section.id}`} key={section.id}>
                <div className={`flex items-center p-4 ${index !== 0 ? "border-t" : ""}`}>
                  <div className="w-10 h-10 mr-4 flex-shrink-0">
                    <img src={section.icon || "/placeholder.svg"} alt="" className="w-full h-full" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-medium">{section.title}</h3>
                  </div>
                  <ChevronRight className="h-5 w-5 text-primary" />
                </div>
              </Link>
            ))}
          </CardContent>
        </Card>
      </main>

      <Navigation />
    </div>
  )
}

