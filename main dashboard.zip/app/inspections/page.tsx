import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, FileText } from "lucide-react"
import Link from "next/link"

type Scan = {
  id: string
  address: string
  date: string
  status: "Completed" | "In Progress" | "Scheduled"
}

export default function InspectionsPage() {
  // This would come from an API in a real app
  const pastScans: Scan[] = [
    {
      id: "1",
      address: "8100 Sky Mountain Ln",
      date: "March 5, 2025",
      status: "Completed",
    },
    {
      id: "2",
      address: "8100 Sky Mountain Ln",
      date: "December 10, 2024",
      status: "Completed",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 p-4 pt-3 pb-20 container mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 sm:gap-0">
          <h1 className="text-2xl font-bold">Inspections</h1>
          <Button className="flex items-center w-full sm:w-auto">
            <Calendar className="h-4 w-4 mr-2" />
            Schedule New
          </Button>
        </div>

        <div className="space-y-4">
          {pastScans.map((scan) => (
            <Card key={scan.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div>
                    <h3 className="text-lg sm:text-xl font-semibold mb-1">{scan.address}</h3>
                    <p className="text-xs sm:text-sm text-gray-500 mb-2">Inspection on {scan.date}</p>
                    <div className="flex items-center">
                      <span className="inline-block w-2 h-2 rounded-full bg-success mr-2"></span>
                      <span className="text-success text-sm">{scan.status}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="text-primary w-full sm:w-auto justify-center" asChild>
                    <Link href={`/inspections/${scan.id}`}>
                      <FileText className="h-4 w-4 mr-1" />
                      View Report
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {pastScans.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 mb-4">No inspections found</p>
            <Button>Schedule Your First Inspection</Button>
          </div>
        )}
      </main>

      <Navigation />
    </div>
  )
}

