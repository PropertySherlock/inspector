import { Navigation } from "@/components/dashboard/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Share2, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function InspectionDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <main className="flex-1 p-4 pt-3">
        <div className="mb-4">
          <Link href="/inspections" className="text-gray-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Inspections
          </Link>
        </div>

        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Inspection Report</h1>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-1" />
              Share
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-1" />
              Download
            </Button>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>8100 Sky Mountain Ln</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-500 mb-2">Inspection completed on March 5, 2025</p>
            <div className="flex items-center mb-4">
              <span className="inline-block w-2 h-2 rounded-full bg-success mr-2"></span>
              <span className="text-success">Completed</span>
            </div>
            <p className="text-sm mb-4">
              This report provides a comprehensive assessment of your property's condition, highlighting areas that need
              attention and maintenance recommendations.
            </p>
          </CardContent>
        </Card>

        <div className="grid gap-4 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Roof</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-2">
                <span className="inline-block w-2 h-2 rounded-full bg-warning mr-2"></span>
                <span className="text-warning font-medium">Minor Repairs</span>
              </div>
              <p className="text-sm">
                Some shingles showing signs of wear. Recommend replacing damaged shingles within the next 3-6 months.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Plumbing</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-2">
                <span className="inline-block w-2 h-2 rounded-full bg-success mr-2"></span>
                <span className="text-success font-medium">Good Condition</span>
              </div>
              <p className="text-sm">All plumbing fixtures and pipes are functioning properly. No leaks detected.</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Electrical</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-2">
                <span className="inline-block w-2 h-2 rounded-full bg-danger mr-2"></span>
                <span className="text-danger font-medium">Needs Attention</span>
              </div>
              <p className="text-sm">
                Outdated electrical panel with potential safety concerns. Recommend consulting with a licensed
                electrician for an upgrade.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">HVAC</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-2">
                <span className="inline-block w-2 h-2 rounded-full bg-success mr-2"></span>
                <span className="text-success font-medium">Good Condition</span>
              </div>
              <p className="text-sm">
                HVAC system is functioning efficiently. Regular maintenance is recommended to maintain performance.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mb-20">
          <Link href="/dashboard">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </main>

      <Navigation />
    </div>
  )
}

