import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home, ClipboardCheck, Calendar, Star, ArrowRight } from "lucide-react"
import { Logo } from "@/components/logo"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 md:py-32">
          <div className="container">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-8">
                <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">Property Inspections Made Simple</h1>
                <p className="text-xl text-secondary-foreground">
                  Comprehensive home inspections with detailed reports, maintenance plans, and product recommendations.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" asChild>
                    <Link href="/onboarding/name">Get Started</Link>
                  </Button>
                </div>
              </div>
              <div className="lg:order-last">
                <div className="space-y-4">
                  <div className="p-6 bg-white rounded-lg shadow-sm">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold">123 Main Street</h3>
                      <p className="text-sm text-secondary-foreground">Inspection completed on March 5, 2025</p>
                      <p className="text-success flex items-center gap-2">
                        <span className="inline-block w-2 h-2 rounded-full bg-success" />
                        Report Ready
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-6 bg-white rounded-lg shadow-sm">
                      <h4 className="font-medium mb-2">Roof</h4>
                      <p className="text-warning">Minor Repairs</p>
                    </div>
                    <div className="p-6 bg-white rounded-lg shadow-sm">
                      <h4 className="font-medium mb-2">Plumbing</h4>
                      <p className="text-success">Good Condition</p>
                    </div>
                    <div className="p-6 bg-white rounded-lg shadow-sm">
                      <h4 className="font-medium mb-2">Electrical</h4>
                      <p className="text-danger">Needs Attention</p>
                    </div>
                    <div className="p-6 bg-white rounded-lg shadow-sm">
                      <h4 className="font-medium mb-2">HVAC</h4>
                      <p className="text-success">Good Condition</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">How Property Sherlock Works</h2>
              <p className="text-secondary-foreground max-w-2xl mx-auto">
                Our comprehensive inspection process helps you understand your home's condition and plan for future
                maintenance.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-secondary p-6 rounded-lg">
                <div className="bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <Calendar className="text-primary h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Schedule Inspection</h3>
                <p className="text-secondary-foreground">
                  Book your inspection online in minutes. Choose a date and time that works for you.
                </p>
              </div>
              <div className="bg-secondary p-6 rounded-lg">
                <div className="bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <Home className="text-primary h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Thorough Inspection</h3>
                <p className="text-secondary-foreground">
                  Our certified inspectors thoroughly examine your property from foundation to roof.
                </p>
              </div>
              <div className="bg-secondary p-6 rounded-lg">
                <div className="bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <ClipboardCheck className="text-primary h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Detailed Report</h3>
                <p className="text-secondary-foreground">
                  Receive a comprehensive report with photos, maintenance recommendations, and repair priorities.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-16 bg-secondary">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
              <p className="text-secondary-foreground max-w-2xl mx-auto">
                Don't just take our word for it. Here's what homeowners have to say about Property Sherlock.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex text-primary mb-4">
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                </div>
                <blockquote className="mb-4">
                  <p className="text-secondary-foreground italic">
                    "Property Sherlock saved us thousands in potential repairs. The inspector found issues we would have
                    never noticed until it was too late."
                  </p>
                </blockquote>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                  <div>
                    <p className="font-medium">Sarah Johnson</p>
                    <p className="text-sm text-secondary-foreground">First-time Homebuyer</p>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex text-primary mb-4">
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                </div>
                <blockquote className="mb-4">
                  <p className="text-secondary-foreground italic">
                    "The maintenance dashboard is a game-changer. I now know exactly what needs to be done and when to
                    keep my home in top condition."
                  </p>
                </blockquote>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                  <div>
                    <p className="font-medium">Michael Rodriguez</p>
                    <p className="text-sm text-secondary-foreground">Homeowner for 5+ years</p>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex text-primary mb-4">
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                </div>
                <blockquote className="mb-4">
                  <p className="text-secondary-foreground italic">
                    "The inspector was thorough, professional, and took the time to explain everything. The report was
                    detailed and easy to understand."
                  </p>
                </blockquote>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                  <div>
                    <p className="font-medium">Jennifer Chen</p>
                    <p className="text-sm text-secondary-foreground">Real Estate Investor</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-primary text-white">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to get started?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Join thousands of homeowners who trust Property Sherlock to keep their homes safe and well-maintained.
            </p>
            <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-gray-100" asChild>
              <Link href="/onboarding/name">
                Get Started Today <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Link href="/" className="flex items-center gap-2">
                  <Logo className="h-6 w-6 text-primary" />
                  <span className="text-xl font-bold text-white">Property Sherlock</span>
                </Link>
              </div>
              <p className="text-gray-400">
                Your home's personal detective, helping you maintain and protect your investment.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Home Inspections
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Maintenance Plans
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Repair Recommendations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    HomeScan Technology
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Our Team
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <address className="not-italic text-gray-400">
                <p>1234 Inspection Ave</p>
                <p>Suite 500</p>
                <p>San Francisco, CA 94107</p>
                <p className="mt-2">info@propertysherlock.com</p>
                <p>(555) 123-4567</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Property Sherlock. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

