"use client"

import { useState } from "react"
import { ArrowLeft, Plus, ChevronRight, Trash2 } from "lucide-react"
import Link from "next/link"

export default function UpgradesPage() {
  const [upgrades, setUpgrades] = useState([
    {
      id: 1,
      title: "Smart Thermostat Installation",
      date: "June 2023",
      category: "HVAC",
      description: "Installed a Nest Learning Thermostat to improve energy efficiency",
    },
    {
      id: 2,
      title: "Water Filtration System",
      date: "March 2023",
      category: "Plumbing",
      description: "Added whole-house water filtration system",
    },
  ])

  const [showAddForm, setShowAddForm] = useState(false)
  const [newUpgrade, setNewUpgrade] = useState({
    title: "",
    date: "",
    category: "",
    description: "",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setNewUpgrade((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleAddUpgrade = () => {
    if (newUpgrade.title && newUpgrade.category) {
      setUpgrades((prev) => [
        ...prev,
        {
          id: Date.now(),
          ...newUpgrade,
        },
      ])

      setNewUpgrade({
        title: "",
        date: "",
        category: "",
        description: "",
      })

      setShowAddForm(false)
    }
  }

  const handleDeleteUpgrade = (id) => {
    setUpgrades((prev) => prev.filter((upgrade) => upgrade.id !== id))
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <Link href="/property-profile" className="p-2 rounded-full hover:bg-gray-100">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-xl font-bold">Upgrades</h1>
        <div className="w-10"></div>
      </header>

      <div className="flex-1 p-4 max-w-2xl mx-auto w-full">
        {showAddForm ? (
          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <h2 className="text-xl font-bold mb-4">Add New Upgrade</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  name="title"
                  value={newUpgrade.title}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., New Water Heater"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="text"
                  name="date"
                  value={newUpgrade.date}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., June 2023"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  name="category"
                  value={newUpgrade.category}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md bg-white"
                >
                  <option value="">Select category</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="HVAC">HVAC</option>
                  <option value="Electrical">Electrical</option>
                  <option value="Appliance">Appliance</option>
                  <option value="Exterior">Exterior</option>
                  <option value="Interior">Interior</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  name="description"
                  value={newUpgrade.description}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md min-h-[100px]"
                  placeholder="Describe the upgrade..."
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleAddUpgrade}
                  className="flex-1 py-2 bg-orange-500 text-white rounded-md font-medium"
                >
                  Save
                </button>
                <button onClick={() => setShowAddForm(false)} className="flex-1 py-2 border border-gray-300 rounded-md">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Your Upgrades</h2>
              <button onClick={() => setShowAddForm(true)} className="p-2 rounded-full bg-orange-100 text-orange-500">
                <Plus size={20} />
              </button>
            </div>

            {upgrades.length > 0 ? (
              <div className="space-y-3">
                {upgrades.map((upgrade) => (
                  <div key={upgrade.id} className="bg-white rounded-lg shadow p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-bold text-lg">{upgrade.title}</h3>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <span>{upgrade.date}</span>
                          {upgrade.category && (
                            <>
                              <span className="mx-2">•</span>
                              <span>{upgrade.category}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => handleDeleteUpgrade(upgrade.id)}
                        className="p-1 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>

                    {upgrade.description && <p className="mt-2 text-gray-700">{upgrade.description}</p>}

                    <div className="mt-3 pt-3 border-t flex justify-end">
                      <Link
                        href={`/property-profile/upgrades/${upgrade.id}`}
                        className="text-orange-500 flex items-center text-sm"
                      >
                        View Details <ChevronRight size={16} />
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <div className="text-gray-400 mb-3">
                  <svg
                    width="48"
                    height="48"
                    className="mx-auto"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2 3H8C9.06087 3 10.0783 3.42143 10.8284 4.17157C11.5786 4.92172 12 5.93913 12 7V21C12 20.2044 11.6839 19.4413 11.1213 18.8787C10.5587 18.3161 9.79565 18 9 18H2V3Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M22 3H16C14.9391 3 13.9217 3.42143 13.1716 4.17157C12.4214 4.92172 12 5.93913 12 7V21C12 20.2044 12.3161 19.4413 12.8787 18.8787C13.4413 18.3161 14.2044 18 15 18H22V3Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-medium mb-2">No upgrades yet</h3>
                <p className="text-gray-500 mb-4">Track improvements you've made to your home</p>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="px-4 py-2 bg-orange-500 text-white rounded-md font-medium"
                >
                  Add Your First Upgrade
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

