"use client"

import { useState } from "react"
import { ChevronRight, Home, ArrowLeft } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function PropertyProfile() {
  const [address, setAddress] = useState("39600 Fremont Blvd, Fremont, California")

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <Link href="/" className="flex items-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Property%20Sherlock%20Transparent%20Background-asxB50UIkvEQxQ4zfseSeArQ5QK9y9.png"
            alt="Property Sherlock Logo"
            width={32}
            height={32}
            className="mr-2 sm:mr-3 sm:w-10 sm:h-10"
          />
          <h1 className="text-lg sm:text-xl font-bold text-gray-800">Property Sherlock</h1>
        </Link>
        <div className="flex items-center gap-4">
          <button className="p-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z"
                stroke="black"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21"
                stroke="black"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <button className="p-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21"
                stroke="black"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"
                stroke="black"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </header>

      {/* Address Bar */}
      <div className="bg-white p-4 flex items-center">
        <Link href="/" className="mr-3">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h2 className="text-xl sm:text-2xl font-bold flex items-center">{address}</h2>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4">
        <h1 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Home Profile</h1>

        <div className="space-y-3 sm:space-y-4">
          {/* Category Items */}
          <CategoryItem
            icon={<Home className="text-orange-500" />}
            title="Basic information"
            href="/property-profile/basic-info"
          />

          <CategoryItem
            icon={
              <div className="relative">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" stroke="#E5E7EB" strokeWidth="2" />
                  <path d="M12 12 L12 6" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                  <circle cx="12" cy="12" r="1" fill="#F97316" />
                </svg>
              </div>
            }
            title="Protection"
            href="/property-profile/protection"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 22V16M12 16H7M12 16H17M7 8H5C4.44772 8 4 8.44772 4 9V19C4 19.5523 4.44772 20 5 20H19C19.5523 20 20 19.5523 20 19V9C20 8.44772 19.5523 8 19 8H17M7 8V6C7 4.89543 7.89543 4 9 4H15C16.1046 4 17 4.89543 17 6V8M7 8H17"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            }
            title="Plumbing"
            href="/property-profile/plumbing"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="2" y="7" width="20" height="14" rx="2" stroke="#F97316" strokeWidth="2" />
                <path d="M6 11H6.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M10 11H10.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M14 11H14.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M18 11H18.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M6 15H6.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M10 15H10.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M14 15H14.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M18 15H18.01" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M7 4L7 7" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <path d="M17 4L17 7" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
              </svg>
            }
            title="HVAC"
            href="/property-profile/hvac"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="4" y="4" width="16" height="16" rx="2" stroke="#F97316" strokeWidth="2" />
                <path d="M4 8H20" stroke="#F97316" strokeWidth="2" />
                <path d="M8 8V20" stroke="#F97316" strokeWidth="2" />
              </svg>
            }
            title="Appliances"
            href="/property-profile/appliances"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            }
            title="Exterior"
            href="/property-profile/exterior"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M9 22V12H15V22"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            }
            title="Interior"
            href="/property-profile/interior"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M2 3H8C9.06087 3 10.0783 3.42143 10.8284 4.17157C11.5786 4.92172 12 5.93913 12 7V21C12 20.2044 11.6839 19.4413 11.1213 18.8787C10.5587 18.3161 9.79565 18 9 18H2V3Z"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M22 3H16C14.9391 3 13.9217 3.42143 13.1716 4.17157C12.4214 4.92172 12 5.93913 12 7V21C12 20.2044 12.3161 19.4413 12.8787 18.8787C13.4413 18.3161 14.2044 18 15 18H22V3Z"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            }
            title="Upgrades"
            href="/property-profile/upgrades"
          />

          <CategoryItem
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V21L17 19L15 21L12 18L9 21L7 19L3 21Z"
                  stroke="#F97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <line x1="8" y1="10" x2="16" y2="10" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                <line x1="8" y1="14" x2="16" y2="14" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
              </svg>
            }
            title="Remodels"
            href="/property-profile/remodels"
          />
        </div>
      </div>
    </div>
  )
}

function CategoryItem({ icon, title, href }) {
  return (
    <Link href={href} className="flex items-center justify-between p-3 sm:p-4 bg-white rounded-lg shadow-sm">
      <div className="flex items-center">
        <div className="w-8 h-8 sm:w-10 sm:h-10 mr-3 sm:mr-4 flex items-center justify-center">{icon}</div>
        <span className="text-base sm:text-lg font-medium">{title}</span>
      </div>
      <ChevronRight className="text-gray-400 h-5 w-5 sm:h-6 sm:w-6" />
    </Link>
  )
}

