"use client"

import { useState } from "react"
import { ArrowLeft, Camera, Upload, Edit, ChevronRight, Plus } from "lucide-react"
import Link from "next/link"

export default function CategoryPage({ params }) {
  const { category } = params
  const [showDetailedForm, setShowDetailedForm] = useState(false)
  const [photos, setPhotos] = useState([])
  const [activeSection, setActiveSection] = useState("basic") // basic, upgrades, remodels, detailed

  const getCategoryTitle = () => {
    switch (category) {
      case "basic-info":
        return "Basic Information"
      case "protection":
        return "Protection Systems"
      case "plumbing":
        return "Plumbing System"
      case "hvac":
        return "HVAC System"
      case "appliances":
        return "Appliances"
      case "exterior":
        return "Exterior"
      case "interior":
        return "Interior"
      default:
        return "Category"
    }
  }

  const getCategoryIcon = () => {
    switch (category) {
      case "protection":
        return (
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white flex items-center justify-center">
            <svg
              width="32"
              height="32"
              className="sm:w-10 sm:h-10"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="12" cy="12" r="10" stroke="#E5E7EB" strokeWidth="2" />
              <path d="M12 12 L12 6" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
              <circle cx="12" cy="12" r="1" fill="#F97316" />
            </svg>
          </div>
        )
      case "plumbing":
        return (
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white flex items-center justify-center">
            <svg
              width="32"
              height="32"
              className="sm:w-10 sm:h-10"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 22V16M12 16H7M12 16H17M7 8H5C4.44772 8 4 8.44772 4 9V19C4 19.5523 4.44772 20 5 20H19C19.5523 20 20 19.5523 20 19V9C20 8.44772 19.5523 8 19 8H17M7 8V6C7 4.89543 7.89543 4 9 4H15C16.1046 4 17 4.89543 17 6V8M7 8H17"
                stroke="#F97316"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </div>
        )
      default:
        return (
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white flex items-center justify-center">
            <svg
              width="32"
              height="32"
              className="sm:w-10 sm:h-10"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z"
                stroke="#F97316"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        )
    }
  }

  const handlePhotoUpload = (e) => {
    if (e.target.files) {
      const newPhotos = Array.from(e.target.files).map((file) => URL.createObjectURL(file))
      setPhotos((prev) => [...prev, ...newPhotos])
    }
  }

  const openDetailedForm = (section = "basic") => {
    setActiveSection(section)
    setShowDetailedForm(true)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <Link href="/property-profile" className="p-2 rounded-full hover:bg-gray-100">
          <ArrowLeft size={24} />
        </Link>
      </header>

      {showDetailedForm ? (
        <DetailedForm
          category={category}
          onClose={() => setShowDetailedForm(false)}
          photos={photos}
          setPhotos={setPhotos}
          handlePhotoUpload={handlePhotoUpload}
          activeSection={activeSection}
        />
      ) : (
        <>
          {/* Category Header */}
          <div className="flex flex-col items-center justify-center py-8 bg-white">
            {getCategoryIcon()}
            <h1 className="text-2xl sm:text-3xl font-bold mt-3 sm:mt-4">{getCategoryTitle()}</h1>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-4 max-w-2xl mx-auto w-full">
            {/* Basic Information Card */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Basic Information</h2>
                <button className="p-2 rounded-full bg-gray-100" onClick={() => openDetailedForm("basic")}>
                  <Edit size={20} className="text-gray-600" />
                </button>
              </div>

              {category === "hvac" && (
                <>
                  <div className="py-3 border-b">
                    <p className="text-gray-500">System type</p>
                    <p className="text-lg">Central air conditioning</p>
                  </div>
                  <div className="py-3 border-b">
                    <p className="text-gray-500">Installation year</p>
                    <p className="text-lg">2015</p>
                  </div>
                  <div className="py-3">
                    <p className="text-gray-500">Last serviced</p>
                    <p className="text-lg">June 2024</p>
                  </div>
                </>
              )}

              {category === "plumbing" && (
                <>
                  <div className="py-3 border-b">
                    <p className="text-gray-500">Installation year</p>
                    <p className="text-lg">1957</p>
                  </div>
                  <div className="py-3">
                    <p className="text-gray-500">Material type</p>
                    <div className="flex items-center text-gray-400">
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="mr-2"
                      >
                        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                        <path d="M12 8V16" stroke="currentColor" strokeWidth="2" />
                        <path d="M12 16V16.01" stroke="currentColor" strokeWidth="2" />
                      </svg>
                      Missing fields
                    </div>
                  </div>
                </>
              )}

              {category === "protection" && (
                <>
                  <div className="py-3">
                    <p className="text-gray-500">Smoke and carbon monoxide detectors</p>
                    <p className="text-lg">Some</p>
                  </div>
                </>
              )}

              {category !== "hvac" && category !== "plumbing" && category !== "protection" && (
                <div className="py-3 text-gray-500">
                  <p>Click the edit button to add basic information</p>
                </div>
              )}
            </div>

            {/* Upgrades Card */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Upgrades</h2>
                <button className="p-2 rounded-full bg-gray-100" onClick={() => openDetailedForm("upgrades")}>
                  <Plus size={20} className="text-gray-600" />
                </button>
              </div>

              <div className="py-3 text-gray-500">
                <p>Document any upgrades you've made to your {getCategoryTitle().toLowerCase()}</p>

                {/* Example upgrade (would be populated from backend) */}
                {category === "hvac" && (
                  <div className="mt-4 border rounded-lg p-3">
                    <div className="flex justify-between">
                      <h3 className="font-medium">New thermostat</h3>
                      <span className="text-sm text-gray-500">2023</span>
                    </div>
                    <p className="text-sm mt-1">Installed smart thermostat with WiFi connectivity</p>
                  </div>
                )}

                {/* Add upgrade button */}
                <button
                  onClick={() => openDetailedForm("upgrades")}
                  className="w-full mt-4 py-2 border border-gray-300 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
                >
                  <Plus size={18} />
                  Add Upgrade
                </button>
              </div>
            </div>

            {/* Detailed Information Card */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Detailed Information</h2>
                <button className="p-2 rounded-full bg-gray-100" onClick={() => openDetailedForm("detailed")}>
                  <ChevronRight size={20} className="text-gray-600" />
                </button>
              </div>

              <p className="text-gray-500 mb-4">
                Add notes and photos to document your {getCategoryTitle().toLowerCase()}
              </p>

              {/* Photo Preview (if any) */}
              {photos.length > 0 && (
                <div className="grid grid-cols-2 gap-2 mb-4">
                  {photos.slice(0, 2).map((photo, index) => (
                    <div key={index} className="relative aspect-video">
                      <img
                        src={photo || "/placeholder.svg"}
                        alt={`Photo ${index + 1}`}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    </div>
                  ))}
                  {photos.length > 2 && (
                    <div className="col-span-2 text-center text-gray-500 mt-2">+{photos.length - 2} more photos</div>
                  )}
                </div>
              )}

              {/* Photo Upload Button */}
              <button
                onClick={() => openDetailedForm("detailed")}
                className="w-full py-3 border border-gray-300 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
              >
                <Camera size={20} />
                {photos.length > 0 ? "Add More Photos" : "Add Photos"}
              </button>
            </div>

            {/* Action Buttons */}
            <div className="mt-6">
              <button className="w-full py-3 bg-orange-500 text-white rounded-lg font-medium mb-3">Save Changes</button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function DetailedForm({ category, onClose, photos, setPhotos, handlePhotoUpload, activeSection }) {
  const [formData, setFormData] = useState({})
  const [upgradeDate, setUpgradeDate] = useState("")
  const [upgradeTitle, setUpgradeTitle] = useState("")
  const [upgradeDescription, setUpgradeDescription] = useState("")

  const getFormTitle = () => {
    switch (activeSection) {
      case "upgrades":
        return "Add Upgrade"
      case "remodels":
        return "Add Remodel"
      case "detailed":
        return "Detailed Information"
      default:
        return getCategoryTitle(category)
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const renderFormContent = () => {
    switch (activeSection) {
      case "upgrades":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Title</label>
              <input
                type="text"
                value={upgradeTitle}
                onChange={(e) => setUpgradeTitle(e.target.value)}
                placeholder="e.g., New thermostat, Filter upgrade"
                className="w-full p-3 border rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Date</label>
              <input
                type="text"
                value={upgradeDate}
                onChange={(e) => setUpgradeDate(e.target.value)}
                placeholder="Month and year"
                className="w-full p-3 border rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <textarea
                value={upgradeDescription}
                onChange={(e) => setUpgradeDescription(e.target.value)}
                placeholder="Describe the upgrade..."
                className="w-full p-3 border rounded-lg min-h-[120px]"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Photos</label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                {photos.length > 0 ? (
                  <div className="grid grid-cols-2 gap-4">
                    {photos.map((photo, index) => (
                      <div key={index} className="relative aspect-video">
                        <img
                          src={photo || "/placeholder.svg"}
                          alt={`Photo ${index + 1}`}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </div>
                    ))}
                    <label className="flex flex-col items-center justify-center border rounded-lg aspect-video cursor-pointer hover:bg-gray-50">
                      <Upload className="h-8 w-8 text-gray-400 mb-2" />
                      <span className="text-sm text-gray-500">Add more</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center cursor-pointer">
                    <Upload className="h-12 w-12 text-gray-400 mb-2" />
                    <p className="text-gray-500 mb-1">Upload photos</p>
                    <p className="text-gray-400 text-sm">Drag and drop or click to browse</p>
                    <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                  </label>
                )}
              </div>
            </div>
          </div>
        )
      case "detailed":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Notes</label>
              <textarea
                name="notes"
                placeholder="Enter any additional information..."
                className="w-full p-3 border rounded-lg min-h-[120px]"
                value={formData.notes || ""}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Photos</label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                {photos.length > 0 ? (
                  <div className="grid grid-cols-2 gap-4">
                    {photos.map((photo, index) => (
                      <div key={index} className="relative aspect-video">
                        <img
                          src={photo || "/placeholder.svg"}
                          alt={`Photo ${index + 1}`}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </div>
                    ))}
                    <label className="flex flex-col items-center justify-center border rounded-lg aspect-video cursor-pointer hover:bg-gray-50">
                      <Upload className="h-8 w-8 text-gray-400 mb-2" />
                      <span className="text-sm text-gray-500">Add more</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center cursor-pointer">
                    <Upload className="h-12 w-12 text-gray-400 mb-2" />
                    <p className="text-gray-500 mb-1">Upload photos</p>
                    <p className="text-gray-400 text-sm">Drag and drop or click to browse</p>
                    <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                  </label>
                )}
              </div>
            </div>
          </div>
        )
      default: // basic
        return renderBasicInfoFields()
    }
  }

  const renderBasicInfoFields = () => {
    switch (category) {
      case "hvac":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">System type</label>
              <select
                name="systemType"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.systemType || ""}
                onChange={handleChange}
              >
                <option value="">Select system type</option>
                <option value="central">Central air conditioning</option>
                <option value="heatPump">Heat pump</option>
                <option value="ductless">Ductless mini-split</option>
                <option value="window">Window unit</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Installation year</label>
              <input
                type="text"
                name="installationYear"
                placeholder="Enter year"
                className="w-full p-3 border rounded-lg"
                value={formData.installationYear || ""}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Last serviced</label>
              <input
                type="text"
                name="lastServiced"
                placeholder="Month and year"
                className="w-full p-3 border rounded-lg"
                value={formData.lastServiced || ""}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">SEER rating (if known)</label>
              <input
                type="text"
                name="seerRating"
                placeholder="Enter SEER rating"
                className="w-full p-3 border rounded-lg"
                value={formData.seerRating || ""}
                onChange={handleChange}
              />
            </div>
          </div>
        )
      case "plumbing":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Installation year</label>
              <input
                type="text"
                name="installationYear"
                placeholder="Enter year"
                className="w-full p-3 border rounded-lg"
                value={formData.installationYear || ""}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Material type</label>
              <select
                name="materialType"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.materialType || ""}
                onChange={handleChange}
              >
                <option value="">Select material type</option>
                <option value="copper">Copper</option>
                <option value="pex">PEX</option>
                <option value="pvc">PVC</option>
                <option value="galvanized">Galvanized steel</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Water heater type</label>
              <select
                name="waterHeaterType"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.waterHeaterType || ""}
                onChange={handleChange}
              >
                <option value="">Select water heater type</option>
                <option value="tank">Tank</option>
                <option value="tankless">Tankless</option>
                <option value="heatPump">Heat pump</option>
                <option value="solar">Solar</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
        )
      case "protection":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Smoke and carbon monoxide detectors</label>
              <select
                name="detectors"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.detectors || ""}
                onChange={handleChange}
              >
                <option value="">Select option</option>
                <option value="none">None</option>
                <option value="some">Some</option>
                <option value="all">All rooms</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Security system</label>
              <select
                name="securitySystem"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.securitySystem || ""}
                onChange={handleChange}
              >
                <option value="">Select option</option>
                <option value="none">None</option>
                <option value="basic">Basic</option>
                <option value="monitored">Professionally monitored</option>
                <option value="smart">Smart home security</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Fire extinguisher</label>
              <select
                name="fireExtinguisher"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.fireExtinguisher || ""}
                onChange={handleChange}
              >
                <option value="">Select option</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
          </div>
        )
      default:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Installation year (if applicable)</label>
              <input
                type="text"
                name="installationYear"
                placeholder="Enter year"
                className="w-full p-3 border rounded-lg"
                value={formData.installationYear || ""}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Condition</label>
              <select
                name="condition"
                className="w-full p-3 border rounded-lg bg-white"
                value={formData.condition || ""}
                onChange={handleChange}
              >
                <option value="">Select condition</option>
                <option value="excellent">Excellent</option>
                <option value="good">Good</option>
                <option value="fair">Fair</option>
                <option value="poor">Poor</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Last maintenance (if applicable)</label>
              <input
                type="text"
                name="lastMaintenance"
                placeholder="Month and year"
                className="w-full p-3 border rounded-lg"
                value={formData.lastMaintenance || ""}
                onChange={handleChange}
              />
            </div>
          </div>
        )
    }
  }

  return (
    <div className="flex-1 p-4 max-w-2xl mx-auto w-full">
      <div className="flex items-center mb-6">
        <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-100 mr-3">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold">{getFormTitle()}</h1>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">{renderFormContent()}</div>

      <div className="flex flex-col gap-3">
        <button className="w-full py-3 bg-orange-500 text-white rounded-lg font-medium" onClick={onClose}>
          Save Changes
        </button>
        <button className="w-full py-3 border border-gray-300 rounded-lg font-medium" onClick={onClose}>
          Cancel
        </button>
      </div>
    </div>
  )
}

function getCategoryTitle(category) {
  switch (category) {
    case "basic-info":
      return "Basic Information"
    case "protection":
      return "Protection Systems"
    case "plumbing":
      return "Plumbing System"
    case "hvac":
      return "HVAC System"
    case "appliances":
      return "Appliances"
    case "exterior":
      return "Exterior"
    case "interior":
      return "Interior"
    default:
      return "Category"
  }
}

