"use client"

import { useState } from "react"
import { ArrowLeft, Camera, Upload } from "lucide-react"
import Link from "next/link"

export default function RoofPage() {
  const [formData, setFormData] = useState({
    roofCondition: "good",
    leaks: "no",
    roofNotes: "",
  })
  const [photos, setPhotos] = useState([])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handlePhotoUpload = (e) => {
    if (e.target.files) {
      const newPhotos = Array.from(e.target.files).map((file) => URL.createObjectURL(file))
      setPhotos((prev) => [...prev, ...newPhotos])
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <Link href="/property-profile/exterior" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-xl font-bold">Roof Condition</h1>
        <div className="w-10"></div>
      </header>

      <div className="flex-1 p-4">
        <div className="bg-white rounded-lg p-4 sm:p-6 space-y-4 sm:space-y-6">
          <div className="space-y-2">
            <p className="font-medium text-sm sm:text-base">What is the overall condition of your roof?</p>
            <div className="space-y-2">
              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="roofCondition"
                  value="excellent"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.roofCondition === "excellent"}
                  onChange={handleChange}
                />
                <span>Excellent - Like new, no visible issues</span>
              </label>

              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="roofCondition"
                  value="good"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.roofCondition === "good"}
                  onChange={handleChange}
                />
                <span>Good - Minor wear, no apparent issues</span>
              </label>

              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="roofCondition"
                  value="fair"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.roofCondition === "fair"}
                  onChange={handleChange}
                />
                <span>Fair - Some visible wear, may need attention soon</span>
              </label>

              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="roofCondition"
                  value="poor"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.roofCondition === "poor"}
                  onChange={handleChange}
                />
                <span>Poor - Significant wear or damage, needs attention</span>
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-sm sm:text-base">Have you noticed any leaks or water damage?</p>
            <div className="space-y-2">
              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="leaks"
                  value="yes"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.leaks === "yes"}
                  onChange={handleChange}
                />
                <span>Yes</span>
              </label>

              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="leaks"
                  value="no"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.leaks === "no"}
                  onChange={handleChange}
                />
                <span>No</span>
              </label>

              <label className="flex items-center p-2 py-2.5">
                <input
                  type="radio"
                  name="leaks"
                  value="notSure"
                  className="mr-3 w-5 h-5 accent-orange-500"
                  checked={formData.leaks === "notSure"}
                  onChange={handleChange}
                />
                <span>Not sure</span>
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-sm sm:text-base">Additional notes about your roof</p>
            <textarea
              name="roofNotes"
              placeholder="Enter any additional information about your roof..."
              className="w-full p-2 sm:p-3 text-sm sm:text-base border rounded-lg min-h-[80px] sm:min-h-[100px]"
              value={formData.roofNotes}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <p className="font-medium text-sm sm:text-base">Upload photos of your roof</p>
              <button className="p-2 rounded-full bg-gray-100">
                <Camera size={20} className="text-gray-600" />
              </button>
            </div>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              {photos.length > 0 ? (
                <div className="grid grid-cols-2 gap-2">
                  {photos.map((photo, index) => (
                    <div key={index} className="relative">
                      <img
                        src={photo || "/placeholder.svg"}
                        alt={`Roof photo ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                    </div>
                  ))}
                  <label className="flex flex-col items-center justify-center border rounded-lg h-32 cursor-pointer">
                    <Upload className="h-8 w-8 text-gray-400 mb-1" />
                    <span className="text-sm text-gray-500">Add more</span>
                    <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                  </label>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center cursor-pointer">
                  <Upload className="h-12 w-12 text-gray-400 mb-2" />
                  <p className="text-gray-500 mb-1">Upload photos of your roof</p>
                  <p className="text-gray-400 text-sm">Drag and drop or click to browse</p>
                  <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                </label>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <button className="w-full py-2.5 sm:py-3 bg-orange-500 text-white rounded-lg font-medium text-sm sm:text-base">
            Save
          </button>
        </div>
      </div>
    </div>
  )
}

