"use client"

import { useState } from "react"
import { ArrowLeft, Plus, ChevronRight, Trash2 } from "lucide-react"
import Link from "next/link"

export default function RemodelsPage() {
  const [remodels, setRemodels] = useState([
    {
      id: 1,
      title: "Kitchen Renovation",
      date: "September 2022",
      cost: "$25,000",
      contractor: "Smith Remodeling Co.",
      description: "Complete kitchen remodel with new cabinets, countertops, and appliances",
    },
    {
      id: 2,
      title: "Bathroom Update",
      date: "January 2023",
      cost: "$12,000",
      contractor: "Bathroom Experts Inc.",
      description: "Master bathroom renovation with new tile, fixtures, and vanity",
    },
  ])

  const [showAddForm, setShowAddForm] = useState(false)
  const [newRemodel, setNewRemodel] = useState({
    title: "",
    date: "",
    cost: "",
    contractor: "",
    description: "",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setNewRemodel((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleAddRemodel = () => {
    if (newRemodel.title) {
      setRemodels((prev) => [
        ...prev,
        {
          id: Date.now(),
          ...newRemodel,
        },
      ])

      setNewRemodel({
        title: "",
        date: "",
        cost: "",
        contractor: "",
        description: "",
      })

      setShowAddForm(false)
    }
  }

  const handleDeleteRemodel = (id) => {
    setRemodels((prev) => prev.filter((remodel) => remodel.id !== id))
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <Link href="/property-profile" className="p-2 rounded-full hover:bg-gray-100">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-xl font-bold">Remodels</h1>
        <div className="w-10"></div>
      </header>

      <div className="flex-1 p-4 max-w-2xl mx-auto w-full">
        {showAddForm ? (
          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <h2 className="text-xl font-bold mb-4">Add New Remodel</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Project Title</label>
                <input
                  type="text"
                  name="title"
                  value={newRemodel.title}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., Kitchen Renovation"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date Completed</label>
                <input
                  type="text"
                  name="date"
                  value={newRemodel.date}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., June 2023"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Project Cost (optional)</label>
                <input
                  type="text"
                  name="cost"
                  value={newRemodel.cost}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., $10,000"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor (optional)</label>
                <input
                  type="text"
                  name="contractor"
                  value={newRemodel.contractor}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="e.g., ABC Remodeling"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  name="description"
                  value={newRemodel.description}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md min-h-[100px]"
                  placeholder="Describe the remodeling project..."
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleAddRemodel}
                  className="flex-1 py-2 bg-orange-500 text-white rounded-md font-medium"
                >
                  Save
                </button>
                <button onClick={() => setShowAddForm(false)} className="flex-1 py-2 border border-gray-300 rounded-md">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Your Remodeling Projects</h2>
              <button onClick={() => setShowAddForm(true)} className="p-2 rounded-full bg-orange-100 text-orange-500">
                <Plus size={20} />
              </button>
            </div>

            {remodels.length > 0 ? (
              <div className="space-y-3">
                {remodels.map((remodel) => (
                  <div key={remodel.id} className="bg-white rounded-lg shadow p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-bold text-lg">{remodel.title}</h3>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <span>{remodel.date}</span>
                          {remodel.cost && (
                            <>
                              <span className="mx-2">•</span>
                              <span>{remodel.cost}</span>
                            </>
                          )}
                        </div>
                        {remodel.contractor && (
                          <div className="text-sm text-gray-500 mt-1">Contractor: {remodel.contractor}</div>
                        )}
                      </div>
                      <button
                        onClick={() => handleDeleteRemodel(remodel.id)}
                        className="p-1 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>

                    {remodel.description && <p className="mt-2 text-gray-700">{remodel.description}</p>}

                    <div className="mt-3 pt-3 border-t flex justify-end">
                      <Link
                        href={`/property-profile/remodels/${remodel.id}`}
                        className="text-orange-500 flex items-center text-sm"
                      >
                        View Details <ChevronRight size={16} />
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <div className="text-gray-400 mb-3">
                  <svg
                    width="48"
                    height="48"
                    className="mx-auto"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V21L17 19L15 21L12 18L9 21L7 19L3 21Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line x1="8" y1="10" x2="16" y2="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    <line x1="8" y1="14" x2="16" y2="14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium mb-2">No remodeling projects yet</h3>
                <p className="text-gray-500 mb-4">Track major renovations and remodeling projects</p>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="px-4 py-2 bg-orange-500 text-white rounded-md font-medium"
                >
                  Add Your First Project
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

