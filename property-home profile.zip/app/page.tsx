"use client"

import Image from "next/image"
import Link from "next/link"
import { Bell, CircleUser, ChevronDown, Home, Wrench, CheckSquare, ChevronRight, Search } from "lucide-react"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between border-b">
        <div className="flex items-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Property%20Sherlock%20Transparent%20Background-asxB50UIkvEQxQ4zfseSeArQ5QK9y9.png"
            alt="Property Sherlock Logo"
            width={40}
            height={40}
            className="mr-2"
          />
          <h1 className="text-xl font-bold text-gray-800">Property Sherlock</h1>
        </div>
        <div className="hidden md:flex items-center space-x-8">
          <Link href="/" className="text-gray-900 hover:text-gray-600">
            Home
          </Link>
          <Link href="/about" className="text-gray-900 hover:text-gray-600">
            About Us
          </Link>
          <Link href="/contact" className="text-gray-900 hover:text-gray-600">
            Contact Us
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <button className="p-2">
            <Bell className="h-6 w-6 text-gray-700" />
          </button>
          <button className="p-2">
            <CircleUser className="h-6 w-6 text-gray-700" />
          </button>
        </div>
      </header>

      {/* Address Bar */}
      <div className="bg-white py-4 px-6 flex items-center border-b">
        <button className="text-xl sm:text-2xl font-bold flex items-center">
          39600 Fremont Blvd, Fremont, California
          <ChevronDown className="ml-2 flex-shrink-0" size={24} />
        </button>
      </div>

      {/* Main Content */}
      <div className="p-4 sm:p-6 max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Score Circle */}
          <div className="bg-white rounded-lg p-6 flex justify-center items-center">
            <div className="relative">
              <svg className="w-32 h-32" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="54" fill="none" stroke="#E5E7EB" strokeWidth="12" />
                <circle
                  cx="60"
                  cy="60"
                  r="54"
                  fill="none"
                  stroke="#F97316"
                  strokeWidth="4"
                  strokeDasharray="0 339.292"
                  transform="rotate(-90 60 60)"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-5xl font-bold">0</span>
                <span className="text-gray-500 text-sm">of 100</span>
              </div>
            </div>
          </div>

          {/* Status Cards */}
          <div className="bg-white rounded-lg p-4 flex items-start space-x-4">
            <div className="p-2 rounded-lg bg-gray-100">
              <Wrench className="h-6 w-6 text-gray-700" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Maintenance</h3>
              <p className="text-gray-600">Needs attention</p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 flex items-start space-x-4">
            <div className="p-2 rounded-lg bg-gray-100">
              <CheckSquare className="h-6 w-6 text-gray-700" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Completed (Mar)</h3>
              <p className="text-gray-600">0 to-do's</p>
            </div>
          </div>
        </div>

        {/* Home Profile Card */}
        <div className="mb-8">
          <Link
            href="/property-profile"
            className="bg-white rounded-lg p-4 flex items-center space-x-4 hover:shadow-md transition-shadow"
          >
            <div className="p-3 rounded-full bg-orange-100">
              <Home className="h-6 w-6 text-orange-500" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">Home Profile</h3>
              <p className="text-gray-600">View and update your home details</p>
            </div>
            <ChevronRight className="h-6 w-6 text-gray-400" />
          </Link>
        </div>

        {/* HomeScan Section */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Search className="h-5 w-5 text-orange-500" />
            <h2 className="text-xl font-bold">HomeScan</h2>
          </div>
          <p className="text-gray-600 mb-4">Complete your home profile</p>
          <p className="text-gray-600 mb-4">
            Get a comprehensive scan of your home to identify potential issues and customize your maintenance plan.
          </p>
          <div className="mb-4">
            <p className="text-gray-600 mb-2">Completion</p>
            <div className="h-2 bg-gray-200 rounded-full">
              <div className="h-full bg-gray-400 rounded-full w-0"></div>
            </div>
            <div className="flex justify-end mt-1">
              <span className="text-gray-600">0%</span>
            </div>
          </div>
          <button className="w-full bg-orange-500 text-white rounded-lg py-3 px-4 font-medium flex items-center justify-center">
            Start HomeScan Now
            <ChevronRight className="ml-2" size={20} />
          </button>
        </div>

        {/* To-do Section */}
        <div>
          <h2 className="text-xl font-bold mb-4">To-do's</h2>
          <div className="flex mb-4 border-b">
            <button className="py-2 px-4 text-orange-500 border-b-2 border-orange-500 flex items-center">
              Due soon <span className="ml-2 bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">22</span>
            </button>
            <button className="py-2 px-4 text-gray-500">Past due</button>
          </div>

          <div className="space-y-4">
            <TodoItem date="MAR 27" title="Replace your air filter" difficulty="Easy" duration="10 minutes" />
            <TodoItem date="MAR 29" title="Clean your cooktop" difficulty="Easy" duration="15 minutes" />
          </div>
        </div>
      </div>
    </div>
  )
}

function TodoItem({ date, title, difficulty, duration }) {
  return (
    <div className="flex items-start gap-4 bg-white p-4 rounded-lg">
      <input type="checkbox" className="mt-1 h-5 w-5 rounded border-gray-300" />
      <div className="flex-1">
        <div className="text-gray-500 text-sm">DUE {date}</div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="flex gap-2 mt-2">
          <span className="bg-gray-100 text-gray-700 text-sm px-3 py-1 rounded-full">{difficulty}</span>
          <span className="bg-gray-100 text-gray-700 text-sm px-3 py-1 rounded-full">{duration}</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button className="border border-orange-500 text-orange-500 px-3 py-1.5 rounded-lg flex items-center">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mr-1"
          >
            <path
              d="M17 20H6C4.89543 20 4 19.1046 4 18V9C4 7.89543 4.89543 7 6 7H6.5M17 20C18.1046 20 19 19.1046 19 18V9C19 7.89543 18.1046 7 17 7H17.5M17 20H7M17.5 7L16.7031 5.50656C16.4567 5.01434 15.9467 4.7 15.3905 4.7H8.60947C8.05334 4.7 7.54327 5.01434 7.29691 5.50656L6.5 7M17.5 7H6.5"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Get Help
        </button>
        <button className="text-orange-500 flex items-center">
          Details <ChevronRight size={16} className="ml-1" />
        </button>
      </div>
    </div>
  )
}

